import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { cn } from '../lib/cn';
/** A label/value read-out: the field list of a record, a stats block, a table
 *  of fixed controls. Rows are data, so the caller keeps its own components
 *  (a Kbd, a Badge, a link) in `value`. */
export function PropertyList({ rows, layout = 'fixed', labelWidth = 128, numeric = false, divided = false, className = '', }) {
    return (_jsx("dl", { className: cn('m-0 flex flex-col text-xs', className), children: rows.map((r) => (_jsxs("div", { className: cn('flex items-center gap-2 py-1', divided && 'border-slate-800 border-b px-2'), children: [r.leading != null && _jsx("span", { className: "flex shrink-0 items-center", children: r.leading }), _jsx("dt", { className: cn('truncate text-slate-400', layout === 'fill' ? 'min-w-0 flex-1' : 'shrink-0'), style: layout === 'fixed' ? { width: labelWidth } : undefined, "data-tooltip": r.tooltip, children: r.label }), _jsx("dd", { className: cn('m-0 break-words text-slate-200', layout === 'fill' ? 'shrink-0' : 'min-w-0 flex-1', numeric && 'select-text text-right font-mono'), children: r.value })] }, r.key))) }));
}
