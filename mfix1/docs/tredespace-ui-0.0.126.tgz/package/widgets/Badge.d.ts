import type { ReactNode } from 'react';
import { type Tone } from './tone';
export interface BadgeProps {
    children: ReactNode;
    /** Semantic colour — see {@link Tone}. */
    tone?: Tone;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    className?: string;
}
/** A small status chip: a row count, a license name, a "modified" marker.
 *  Square like everything else, sized to sit inside a 22px row without
 *  changing its height. */
export declare function Badge({ children, tone, tooltip, className }: BadgeProps): import("react").JSX.Element;
