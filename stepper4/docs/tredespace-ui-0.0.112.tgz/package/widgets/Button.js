import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { cn } from '../lib/cn';
// Square by design — the whole app avoids rounded corners for one visual
// language. Matches the .btn / NumberInput stepper palette.
const BASE = 'inline-flex shrink-0 items-center justify-center gap-1.5 border text-xs leading-none transition-colors';
/** The app's button. Read-only mode renders a non-interactive chip that keeps
 *  the same box so buttons and displayed values line up. */
export function Button({ children, icon, onClick, disabled = false, active = false, readOnly = false, iconOnly = false, title, tooltip, shortcut, className = '', }) {
    // Default height matches the inputs (h-6 / 24px) so buttons and fields line
    // up outside the ribbon. In the ribbon, RibbonButton/RibbonNumber size
    // themselves — this widget is for the rest of the app.
    return (_jsxs("button", { type: "button", disabled: disabled || readOnly, tabIndex: readOnly ? -1 : undefined, title: title, "data-tooltip": tooltip, "data-shortcut": shortcut, className: cn(BASE, iconOnly ? 'h-6 w-6 p-0' : 'h-6 px-2', readOnly
            ? 'cursor-default border-slate-700 bg-slate-800 text-slate-300'
            : active
                ? 'cursor-pointer border-blue-400 bg-blue-950 text-blue-100 hover:border-blue-300'
                : 'cursor-pointer border-slate-700 bg-slate-800 text-slate-200 hover:border-slate-600 hover:bg-slate-700 hover:text-slate-100', 'disabled:cursor-not-allowed', !readOnly && 'disabled:opacity-40', className), onClick: readOnly ? undefined : onClick, children: [icon != null && (_jsx("span", { className: "flex h-3.5 w-3.5 shrink-0 items-center justify-center [&>svg]:h-3.5 [&>svg]:w-3.5", children: icon })), children] }));
}
