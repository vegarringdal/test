import type { MouseEvent as ReactMouseEvent, PointerEvent as ReactPointerEvent } from 'react';
import type { TimelineItem, TimelinePoint, TimelineRow, TimelineView } from './timelineTypes';
type Props = Readonly<{
    row: TimelineRow;
    items: readonly TimelineItem[];
    points: readonly TimelinePoint[];
    view: TimelineView;
    height: number;
    hint: string | null;
    format: (t: number) => string;
    onItemDown: (e: ReactPointerEvent<HTMLElement>, item: TimelineItem) => void;
    onEdgeDown: (e: ReactPointerEvent<HTMLElement>, item: TimelineItem, edge: 'start' | 'end') => void;
    onPointDown: (e: ReactPointerEvent<HTMLElement>, point: TimelinePoint) => void;
    onItemOpen: (id: string) => void;
    onItemMenu: (e: ReactMouseEvent, kind: 'item' | 'point', id: string) => void;
}>;
/** One lane: span bars / clip blocks with resize edges, and key points. */
export declare function TimelineLane({ row, items, points, view, height, hint, format, onItemDown, onEdgeDown, onPointDown, onItemOpen, onItemMenu, }: Props): import("react").JSX.Element;
export {};
