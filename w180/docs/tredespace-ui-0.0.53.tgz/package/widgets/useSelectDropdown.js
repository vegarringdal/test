import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
/** Open/filter/anchor state for the Select popover: debounced async search,
 *  local filtering, outside-close, and viewport-anchored placement. */
export function useSelectDropdown(options, loadOptions, searchable, selected) {
    const [open, setOpen] = useState(false);
    const [query, setQuery] = useState('');
    const [hot, setHot] = useState(0); // index into `filtered`
    const [asyncState, setAsyncState] = useState({
        options: [],
        loading: false,
        error: null,
    });
    const seq = useRef(0); // discards stale async responses
    const rootRef = useRef(null);
    const popRef = useRef(null);
    const searchRef = useRef(null);
    const listRef = useRef(null);
    const [pos, setPos] = useState({ left: 0, top: 0, width: 0, up: false });
    // Chips and the summary need labels for values whose options are no longer
    // in the (async) result list — remember every option we have ever seen.
    const labels = useRef(new Map());
    for (const o of [...options, ...asyncState.options]) {
        labels.current.set(o.value, o);
    }
    const known = (v) => labels.current.get(v) ?? { value: v, label: v };
    const filtered = useMemo(() => {
        if (loadOptions) {
            return asyncState.options;
        }
        const q = query.trim().toLowerCase();
        return q ? options.filter((o) => o.label.toLowerCase().includes(q)) : options;
    }, [options, query, loadOptions, asyncState.options]);
    // Async search: debounce the query, keep only the newest response.
    useEffect(() => {
        if (!open || !loadOptions) {
            return;
        }
        const id = ++seq.current;
        setAsyncState((s) => ({ ...s, loading: true, error: null }));
        const t = setTimeout(() => {
            loadOptions(query.trim()).then((opts) => id === seq.current && setAsyncState({ options: opts, loading: false, error: null }), (err) => id === seq.current &&
                setAsyncState({ options: [], loading: false, error: err instanceof Error ? err.message : String(err) }));
        }, 250);
        return () => clearTimeout(t);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [open, query, loadOptions]);
    useEffect(() => setHot(0), []);
    useEffect(() => {
        if (!open) {
            return;
        }
        setQuery('');
        const first = options.findIndex((o) => selected.has(o.value));
        setHot(Math.max(0, first));
        searchRef.current?.focus();
        const away = (e) => {
            const t = e.target;
            if (!rootRef.current?.contains(t) && !popRef.current?.contains(t)) {
                setOpen(false);
            }
        };
        document.addEventListener('pointerdown', away);
        return () => document.removeEventListener('pointerdown', away);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [open, options.findIndex, selected.has]);
    // The list portals to <body> so it can overlap panels; anchor it to the
    // trigger and keep it anchored while anything scrolls or resizes.
    useLayoutEffect(() => {
        if (!open) {
            return;
        }
        const place = () => {
            const r = rootRef.current?.getBoundingClientRect();
            if (!r) {
                return;
            }
            const estimate = Math.min(52 * 4 + (searchable ? 40 : 0) + 10, 260);
            const up = r.bottom + estimate > window.innerHeight && r.top > window.innerHeight - r.bottom;
            setPos({ left: r.left, width: r.width, top: up ? r.top : r.bottom, up });
        };
        place();
        window.addEventListener('resize', place);
        document.addEventListener('scroll', place, true);
        return () => {
            window.removeEventListener('resize', place);
            document.removeEventListener('scroll', place, true);
        };
    }, [open, searchable]);
    useEffect(() => {
        listRef.current?.querySelector('[data-hot="1"]')?.scrollIntoView({ block: 'nearest' });
    }, []);
    return {
        open,
        setOpen,
        query,
        setQuery,
        hot,
        setHot,
        filtered,
        asyncState,
        pos,
        rootRef,
        popRef,
        searchRef,
        listRef,
        known,
    };
}
