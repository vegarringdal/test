import type { MouseEvent as ReactMouseEvent, ReactNode } from 'react';
import { type ButtonSize, type ButtonVariant } from './buttonStyles';
export interface ButtonProps {
    children?: ReactNode;
    /** Optional leading icon (locked to 14×14). */
    icon?: ReactNode;
    /** The click event is passed so handlers can read modifiers (e.g. Alt). */
    onClick?: (e: ReactMouseEvent) => void;
    disabled?: boolean;
    /** Highlighted / selected look — a state, so it wins over `variant`. */
    active?: boolean;
    /** Emphasis: the confirming action, a destructive one, or borderless. */
    variant?: ButtonVariant;
    /** Height/padding scale — `md` (24px) lines up with the inputs. */
    size?: ButtonSize;
    /** Static display chip — no hover, no pointer, not focusable. Use for
     *  read-only values that share the button look (e.g. a shortcut combo). */
    readOnly?: boolean;
    /** Square icon-only button (h=w), for compact actions like a reset ✕. */
    iconOnly?: boolean;
    /** Let a long label run to a second line instead of overflowing — the
     *  height grows from the size's floor. */
    wrap?: boolean;
    /** Take the free space of a flex row (`flex-1`) instead of hugging the label. */
    grow?: boolean;
    /** Swap the icon for a spinner and block clicks while the action runs. */
    loading?: boolean;
    /** Count / status chip after the label (see {@link Badge}). */
    badge?: ReactNode;
    title?: string;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    className?: string;
}
/** The app's button. Read-only mode renders a non-interactive chip that keeps
 *  the same box so buttons and displayed values line up. */
export declare function Button({ children, icon, onClick, disabled, active, variant, size, readOnly, iconOnly, wrap, grow, loading, badge, title, tooltip, shortcut, className, }: ButtonProps): import("react").JSX.Element;
