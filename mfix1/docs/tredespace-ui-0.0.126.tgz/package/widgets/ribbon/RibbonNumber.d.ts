import type { ReactNode } from 'react';
import { type NumberInputProps } from '../number/NumberInput';
import type { RibbonSize } from './ribbonSizes';
export interface RibbonNumberProps extends Omit<NumberInputProps, 'className'> {
    /** Caption in the label column, left of the field. */
    label?: ReactNode;
    /** Width of the input field in px (default 116 — fits “1000.00 m” plus steppers). */
    fieldWidth?: number;
    /**
     * Width of the label column in px (default 34). Stacked RibbonNumbers share
     * it, so their inputs line up; widen it when your labels are longer.
     */
    labelWidth?: number;
    size?: RibbonSize;
    className?: string;
}
/** A NumberInput in a ribbon slot — onChange fires on step, wheel, drag, and commit (Enter/blur). */
export declare function RibbonNumber({ label, labelWidth, fieldWidth, size, className, ...input }: RibbonNumberProps): import("react").JSX.Element;
