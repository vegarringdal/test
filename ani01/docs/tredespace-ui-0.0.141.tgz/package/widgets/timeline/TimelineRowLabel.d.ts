import type { MouseEvent as ReactMouseEvent } from 'react';
import type { TimelineRow } from './timelineTypes';
type Props = Readonly<{
    row: TimelineRow;
    width: number;
    height: number;
    onToggle?: (id: string) => void;
    onOpen: (id: string) => void;
    onMenu: (e: ReactMouseEvent, id: string) => void;
}>;
/** The label cell of a row: twisty, tint swatch, name. */
export declare function TimelineRowLabel({ row, width, height, onToggle, onOpen, onMenu }: Props): import("react").JSX.Element;
export {};
