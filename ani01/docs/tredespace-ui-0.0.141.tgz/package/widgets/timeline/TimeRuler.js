import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useRef } from 'react';
import { cn } from '../../lib/cn';
import { useElementWidth } from '../../lib/useElementWidth';
import { ticks, timeToX, xToTime, zoomAt } from './timelineMath';
/** Default label: seconds below a minute, m:ss above. */
export function defaultTimeFormat(t) {
    if (t < 60) {
        return `${Number(t.toFixed(2))}s`;
    }
    const m = Math.floor(t / 60);
    const s = Math.round(t - m * 60);
    return `${m}:${String(s).padStart(2, '0')}`;
}
/**
 * A time ruler: ticks and labels that adapt to the zoom, the playhead, an
 * optional in/out range. Scrub by dragging; wheel pans, Ctrl+wheel zooms.
 */
export function TimeRuler({ view, duration, playhead, format = defaultTimeFormat, range, onSeek, onViewChange, onRangeChange, className = '', }) {
    const ref = useRef(null);
    const width = useElementWidth(ref);
    const to = xToTime(width, view);
    const marks = width > 0 ? ticks(Math.max(0, view.offset), to, view.pxPerSec) : [];
    const timeAt = (e) => {
        const r = ref.current?.getBoundingClientRect();
        return Math.max(0, xToTime(e.clientX - (r?.left ?? 0), view));
    };
    const handlePointerDown = (e) => {
        const el = e.currentTarget;
        el.setPointerCapture(e.pointerId);
        const t0 = timeAt(e);
        const ranging = e.shiftKey && onRangeChange;
        let moved = false;
        if (!ranging) {
            onSeek(t0);
        }
        const move = (ev) => {
            moved = true;
            const t = timeAt(ev);
            if (ranging) {
                onRangeChange({ from: Math.min(t0, t), to: Math.max(t0, t) });
            }
            else {
                onSeek(t);
            }
        };
        const up = () => {
            el.removeEventListener('pointermove', move);
            el.removeEventListener('pointerup', up);
            if (ranging && !moved) {
                onRangeChange(null);
            }
        };
        el.addEventListener('pointermove', move);
        el.addEventListener('pointerup', up);
    };
    const handleWheel = (e) => {
        const r = ref.current?.getBoundingClientRect();
        if (e.ctrlKey) {
            onViewChange(zoomAt(view, e.deltaY < 0 ? 1.2 : 1 / 1.2, e.clientX - (r?.left ?? 0)));
            return;
        }
        const d = (e.deltaX || e.deltaY) / view.pxPerSec;
        onViewChange({ ...view, offset: Math.max(0, view.offset + d) });
    };
    return (_jsxs("div", { ref: ref, role: "slider", "aria-label": "Time ruler", "aria-valuenow": playhead, tabIndex: -1, className: cn('relative h-6 cursor-ew-resize select-none overflow-hidden border-slate-700 border-b bg-slate-900 text-[10px] text-slate-400', className), onPointerDown: handlePointerDown, onWheel: handleWheel, children: [duration < to && (_jsx("div", { className: "absolute top-0 bottom-0 bg-slate-950/60", style: { left: Math.max(0, timeToX(duration, view)), right: 0 } })), range && (_jsx("div", { className: "absolute top-0 bottom-0 border-sky-400 border-x bg-sky-500/20", style: { left: timeToX(range.from, view), width: Math.max(1, (range.to - range.from) * view.pxPerSec) } })), marks.map((m) => (_jsxs("div", { className: "absolute bottom-0", style: { left: timeToX(m.t, view) }, children: [_jsx("div", { className: cn('w-px bg-slate-600', m.major ? 'h-2.5' : 'h-1') }), m.major && _jsx("span", { className: "absolute bottom-2.5 left-1 whitespace-nowrap", children: format(m.t) })] }, m.t))), _jsx("div", { className: "pointer-events-none absolute top-0 bottom-0 w-px bg-red-400", style: { left: timeToX(playhead, view) }, children: _jsx("div", { className: "absolute top-0 -left-1 h-0 w-0 border-x-4 border-x-transparent border-t-[6px] border-t-red-400" }) })] }));
}
