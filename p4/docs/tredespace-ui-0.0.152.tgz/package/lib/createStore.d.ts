/**
 * A tiny global store — the pattern every *.state.ts file builds on.
 * No external lib: React's useSyncExternalStore does all the heavy lifting.
 *
 *   const ui = createStore({ sidebarOpen: false });
 *   ui.set({ sidebarOpen: !ui.get().sidebarOpen });   // flip a bool → every user re-renders
 *   const { sidebarOpen } = ui.use();                 // inside any component
 *   const open = ui.useSelect((s) => s.sidebarOpen);  // re-renders only when it changes
 *
 * Works outside React too (plain DOM, three.js, timers): subscribe() directly.
 */
export declare function createStore<T extends object>(initial: T): {
    get: () => T;
    subscribe: (fn: () => void) => () => undefined;
    set(patch: Partial<T> | ((prev: T) => Partial<T>)): void;
    use(): T;
    /** One derived value: the component re-renders only when it changes
     *  (Object.is). The selector must return a primitive or a reference that
     *  stays the same while its inputs do — never a fresh object or array. */
    useSelect<S>(selector: (state: T) => S): S;
};
/** The store handle createStore returns — for code parameterized over a store
 *  instance (e.g. the Set Color editor bound to global vs viewpoint rules). */
export type Store<T extends object> = ReturnType<typeof createStore<T>>;
