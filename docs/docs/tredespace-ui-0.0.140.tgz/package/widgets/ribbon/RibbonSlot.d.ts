import type { ReactNode } from 'react';
import { type RibbonSize } from './ribbonSizes';
/**
 * Puts any content into the ribbon's sizing system — the escape hatch for
 * inputs, selects, whatever. The content is vertically centred in its slot.
 * `className` is merged with `cn()`, so e.g. `min-w-0` overrides the default
 * minimum width for a narrow legend.
 */
export declare function RibbonSlot({ size, children, className, }: {
    size?: RibbonSize;
    children?: ReactNode;
    className?: string;
}): import("react").JSX.Element;
