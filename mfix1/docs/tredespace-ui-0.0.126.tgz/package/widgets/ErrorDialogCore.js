import { jsx as _jsx } from "react/jsx-runtime";
import { IconAlertTriangle } from '@tabler/icons-react';
import { Button } from './Button';
import { DialogFrame } from './DialogFrame';
/** Pure error dialog — props only, no store coupling. */
export function ErrorDialogCore({ title, message, onDismiss, z = 2010 }) {
    return (_jsx(DialogFrame, { role: "alertdialog", z: z, icon: _jsx(IconAlertTriangle, { size: 16, className: "shrink-0 text-amber-400" }), title: title, onClose: onDismiss, footer: _jsx(Button, { className: "px-4", onClick: onDismiss, children: "OK" }), children: message }));
}
