import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useCallback } from 'react';
import { cn } from '../lib/cn';
import { InfoButton } from './InfoButton';
/** A single on/off checkbox in the settings-panel visual language — the
 *  standalone sibling of a RadioGroup row. */
export function Checkbox({ checked, onChange, label, hint, info, indeterminate = false, disabled = false, tooltip, shortcut, className = '', }) {
    // `indeterminate` is a DOM property with no attribute, so it has to be set
    // on the element itself.
    const setTriState = useCallback((el) => {
        if (el != null) {
            el.indeterminate = indeterminate;
        }
    }, [indeterminate]);
    return (_jsxs("div", { className: cn('flex items-center gap-2', className), children: [_jsxs("label", { className: cn('flex items-center gap-2 text-slate-300 text-xs', disabled ? 'opacity-50' : 'cursor-pointer'), "data-tooltip": tooltip, "data-shortcut": shortcut, children: [_jsx("input", { ref: setTriState, type: "checkbox", checked: checked, disabled: disabled, onChange: (e) => onChange(e.target.checked) }), label, info == null && hint && _jsxs("span", { className: "text-slate-500", children: ["\u2014 ", hint] })] }), info != null && _jsx(InfoButton, { children: info })] }));
}
