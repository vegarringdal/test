import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { IconChevronDown, IconChevronRight } from '@tabler/icons-react';
import { cn } from '../../lib/cn';
const BAND_CLS = 'border-slate-800 border-t bg-slate-900/70 text-slate-500';
const TWISTY_SLOT = 'flex h-3.5 w-3.5 shrink-0 items-center justify-center';
/** One tree line: partial bar, twisty, icon, label, trailing node. The twisty
 *  toggles expansion ONLY — it never touches the selection. */
export function TreeRow({ row, style, extras, onToggle, onRowClick, onRowContextMenu }) {
    const content = (_jsxs(_Fragment, { children: [row.partial && !row.selected && (_jsx("span", { "data-tooltip": row.partialTooltip, className: "absolute top-0.5 bottom-0.5 left-0 w-2 bg-[linear-gradient(to_right,var(--color-blue-600)_3px,transparent_3px)]" })), _jsx("span", { className: TWISTY_SLOT, children: row.expandable && (_jsx("span", { className: "-m-1 cursor-pointer p-1 text-slate-400 hover:text-blue-300", onClick: (e) => {
                        e.stopPropagation();
                        onToggle?.(row);
                    }, onKeyDown: (e) => {
                        if (e.key === 'Enter') {
                            e.stopPropagation();
                            onToggle?.(row);
                        }
                    }, children: row.expanded ? _jsx(IconChevronDown, { size: 12 }) : _jsx(IconChevronRight, { size: 12 }) })) }), row.icon, _jsx("span", { className: cn('min-w-0 truncate', row.muted && 'text-slate-500 italic', row.band && 'text-[10px] uppercase tracking-wider'), children: row.label }), row.trailing != null && _jsx("span", { className: "ml-auto flex shrink-0 items-center pl-1", children: row.trailing })] }));
    // selection wins over the band look — a fully selected section highlights
    // like any other row, and only its label keeps the band typography
    const cls = cn('relative flex w-full min-w-0 select-none items-center gap-1.5 text-left text-xs', row.selected ? 'bg-blue-950 text-blue-100' : row.band ? BAND_CLS : 'text-slate-200', !row.disabled && !row.selected && 'hover:bg-slate-800', extras?.className);
    if (row.disabled) {
        return (_jsx("div", { className: cls, style: style, "data-tooltip": row.tooltip, ...extras?.data, children: content }));
    }
    return (_jsx("button", { type: "button", "data-key": row.key, "data-tooltip": row.tooltip, className: cn(cls, 'cursor-pointer'), style: style, draggable: extras?.draggable, onDragStart: extras?.onDragStart, onDragOver: extras?.onDragOver, onDrop: extras?.onDrop, onClick: (e) => onRowClick?.(row, e), onContextMenu: (e) => {
            if (onRowContextMenu) {
                e.preventDefault();
                onRowContextMenu(row, e);
            }
        }, ...extras?.data, children: content }));
}
