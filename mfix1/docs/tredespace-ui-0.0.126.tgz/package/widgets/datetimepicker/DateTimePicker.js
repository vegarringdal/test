import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconCalendarClock } from '@tabler/icons-react';
import { useState } from 'react';
import { cn } from '../../lib/cn';
import { CalendarGrid } from '../datepicker/CalendarGrid';
import { formatIsoDate, parseIsoDate, todayParts } from '../datepicker/dateMath';
import { PickerField, PickerPopover } from '../PickerField';
import { ClockDial } from '../timepicker/clockFace';
import { formatTime, nowTime, parseTime } from '../timepicker/timeMath';
import { usePopoverAnchor } from '../usePopoverAnchor';
const POP_WIDTH = 220;
const POP_HEIGHT = 260;
// -----------------------------------------------------------------------------
// helpers
// -----------------------------------------------------------------------------
function parseDateTime(value) {
    if (value == null) {
        return null;
    }
    const [d, t] = value.split('T');
    const date = parseIsoDate(d);
    const time = parseTime(t ?? null);
    return date != null && time != null ? { date: formatIsoDate(date), time } : null;
}
function freshDraft(value) {
    return parseDateTime(value) ?? { date: formatIsoDate(todayParts()), time: nowTime() };
}
// -----------------------------------------------------------------------------
// render
// -----------------------------------------------------------------------------
/**
 * Date + time in one field: the calendar picks the day, then the popover
 * advances to the clock (hour → minute → done); the header re-enters either
 * part. Composed from DatePicker's CalendarGrid and TimePicker's ClockDial,
 * value as ISO local `"yyyy-mm-ddTHH:MM"`.
 */
export function DateTimePicker({ value, onChange, min, max, minuteStep = 1, placeholder = 'Pick date & time…', disabled = false, className = '', tooltip, shortcut, }) {
    const anchor = usePopoverAnchor(POP_HEIGHT);
    const [stage, setStage] = useState('date');
    const [draft, setDraft] = useState(() => freshDraft(value));
    const [view, setView] = useState(() => {
        const base = parseIsoDate(freshDraft(value).date) ?? todayParts();
        return { y: base.y, m: base.m };
    });
    const handleToggle = () => {
        if (!anchor.open) {
            const d = freshDraft(value);
            const base = parseIsoDate(d.date) ?? todayParts();
            setDraft(d);
            setView({ y: base.y, m: base.m });
            setStage('date');
        }
        anchor.setOpen((o) => !o);
    };
    const handleKeyDown = (e) => {
        if (!anchor.open && (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown')) {
            e.preventDefault();
            handleToggle();
        }
        else if (anchor.open && e.key === 'Escape') {
            e.preventDefault();
            anchor.setOpen(false);
        }
    };
    const emit = (d) => {
        setDraft(d);
        onChange(`${d.date}T${formatTime(d.time)}`);
    };
    const handlePickDay = (iso) => {
        emit({ ...draft, date: iso });
        setStage('hour');
    };
    const handleDialPick = (mode, v) => {
        emit({ ...draft, time: mode === 'hour' ? { ...draft.time, h: v } : { ...draft.time, m: v } });
    };
    const handleDialCommit = () => {
        if (stage === 'hour') {
            setStage('minute');
        }
        else {
            anchor.setOpen(false);
        }
    };
    const headerBtn = (active) => cn('cursor-pointer px-1.5 py-0.5 font-mono leading-none', active ? 'bg-blue-950 text-blue-100' : 'text-slate-400 hover:text-slate-200');
    return (_jsxs("div", { ref: anchor.rootRef, className: `relative text-xs ${className}`, onKeyDown: handleKeyDown, children: [_jsx(PickerField, { open: anchor.open, icon: _jsx(IconCalendarClock, { size: 14, className: "shrink-0 text-slate-400" }), value: value != null ? value.replace('T', ' ') : null, placeholder: placeholder, clearLabel: "Clear date & time", disabled: disabled, tooltip: tooltip, shortcut: shortcut, onToggle: handleToggle, onClear: () => onChange(null) }), anchor.open && (_jsxs(PickerPopover, { anchor: anchor, width: POP_WIDTH, children: [_jsxs("div", { className: "flex items-center justify-center gap-1 border-slate-700 border-b p-1.5", children: [_jsx("button", { type: "button", "data-tooltip": "Pick day", className: headerBtn(stage === 'date'), onClick: () => setStage('date'), children: draft.date }), _jsx("button", { type: "button", "data-tooltip": "Pick hour", className: headerBtn(stage === 'hour'), onClick: () => setStage('hour'), children: String(draft.time.h).padStart(2, '0') }), _jsx("span", { className: "-mx-1 font-mono text-slate-500 leading-none", children: ":" }), _jsx("button", { type: "button", "data-tooltip": "Pick minute", className: headerBtn(stage === 'minute'), onClick: () => setStage('minute'), children: String(draft.time.m).padStart(2, '0') })] }), stage === 'date' ? (_jsx(CalendarGrid, { view: view, selected: draft.date, min: min, max: max, onPickDay: handlePickDay, onViewChange: setView })) : (_jsx("div", { className: "flex justify-center p-2", children: _jsx(ClockDial, { mode: stage, hour: draft.time.h, minute: draft.time.m, minuteStep: minuteStep, onPick: handleDialPick, onCommit: handleDialCommit }) }))] }))] }));
}
