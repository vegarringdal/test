import { type RefObject } from 'react';
export type PopoverPos = Readonly<{
    left: number;
    top: number;
    width: number;
    up: boolean;
}>;
export type PopoverAnchor = Readonly<{
    open: boolean;
    setOpen: (o: boolean | ((o: boolean) => boolean)) => void;
    /** Trigger-anchored placement: `top` is the popover's top edge (or, with
     *  `up`, the trigger's top edge to place the popover above). */
    pos: PopoverPos;
    rootRef: RefObject<HTMLDivElement | null>;
    popRef: RefObject<HTMLDivElement | null>;
}>;
/**
 * Shared open/anchor state for body-portaled popovers (Select, DatePicker,
 * TimePicker): closes on outside pointerdown, anchors to the trigger while
 * anything scrolls or resizes, and flips upward when the estimated popover
 * height does not fit below and there is more room above.
 */
export declare function usePopoverAnchor(estimateHeight: number): PopoverAnchor;
