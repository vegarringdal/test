import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconPlayerPauseFilled, IconPlayerPlayFilled, IconPlayerSkipBackFilled, IconPlayerSkipForwardFilled, IconPlayerStopFilled, } from '@tabler/icons-react';
import { cn } from '../../lib/cn';
import { Button } from '../Button';
import { SplitButton } from './SplitButton';
const LABEL = {
    stopped: 'Play',
    playing: 'Pause',
    paused: 'Continue',
    waiting: 'Continue',
};
/**
 * Media transport: previous · play/pause/continue · next · stop. Pure
 * presentation — the caller owns the status and the actions. The main
 * button's label follows `status`, and `playMenu` turns it into a
 * SplitButton for "continue how?" choices.
 */
export function TransportControls({ status, onPlayPause, onStop, onPrev, onNext, shortcuts = {}, playMenu, tooltips = {}, size = 'md', disabled = false, children, className = '', }) {
    const playIcon = status === 'playing' ? _jsx(IconPlayerPauseFilled, {}) : _jsx(IconPlayerPlayFilled, {});
    const playTip = tooltips.playPause ?? `${LABEL[status]} playback`;
    return (_jsxs("div", { className: cn('flex min-w-0 flex-wrap items-center gap-1', className), children: [onPrev && (_jsx(Button, { iconOnly: true, size: size, icon: _jsx(IconPlayerSkipBackFilled, {}), disabled: disabled, tooltip: tooltips.prev ?? 'Previous', shortcut: shortcuts.prev, onClick: onPrev })), playMenu ? (_jsx(SplitButton, { label: LABEL[status], icon: playIcon, size: size, disabled: disabled, tooltip: playTip, shortcut: shortcuts.playPause, menuTooltip: "Continue options", menu: playMenu, onClick: onPlayPause })) : (_jsx(Button, { size: size, className: "min-w-20", icon: playIcon, disabled: disabled, tooltip: playTip, shortcut: shortcuts.playPause, onClick: onPlayPause, children: LABEL[status] })), onNext && (_jsx(Button, { iconOnly: true, size: size, icon: _jsx(IconPlayerSkipForwardFilled, {}), disabled: disabled, tooltip: tooltips.next ?? 'Next', shortcut: shortcuts.next, onClick: onNext })), onStop && (_jsx(Button, { iconOnly: true, size: size, icon: _jsx(IconPlayerStopFilled, {}), disabled: disabled || status === 'stopped', tooltip: tooltips.stop ?? 'Stop and go to the start', shortcut: shortcuts.stop, onClick: onStop })), children] }));
}
