/**
 * Attribute-driven tooltips: put `data-tooltip="text"` on any element and it
 * gets a styled tooltip — no wrapper component, works in React and plain DOM
 * alike. Multi-line via real newlines or a literal "\n" in the attribute.
 *
 * One document-level listener drives everything; call initTooltips() once
 * (App does) and forget about it. The bubble sits below the element, flips
 * above when there is no room, and clamps to the viewport; inside a menu or
 * listbox it moves beside the whole list instead — see `tooltipPlacement.ts`.
 * It draws above every other floating layer.
 */
export declare function initTooltips(): () => void;
