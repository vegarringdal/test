import { type LabelledProps } from '../fieldChrome';
export { type ColorSelectSwatchesStore, DEFAULT_PICKER_SWATCHES, setColorSelectSwatchesStore, } from './colorSelectSwatches';
export interface ColorSelectProps extends LabelledProps {
    value: string;
    onChange: (color: string) => void;
    /** Quick-pick row at the bottom of the popover. */
    swatches?: string[];
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    /** Fill the parent height exactly (ribbon slots) instead of the h-6 floor. */
    flush?: boolean;
}
/**
 * The one colour picker: saturation/value area + hue bar, with hex and RGB
 * entry, quick swatches, popover portaled to body. HSV lives locally while
 * open so hue survives passing through black/white/grey.
 */
export declare function ColorSelect({ value, onChange, swatches, tooltip, shortcut, disabled, className, flush, ...labelled }: ColorSelectProps): import("react").JSX.Element;
