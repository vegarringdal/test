import { type ReactNode } from 'react';
export interface InfoButtonProps {
    /** The explanation shown in the popover — the old InfoBox content. */
    children: ReactNode;
    /** Accessible label / hover tooltip for the trigger. */
    label?: string;
    className?: string;
}
/** A small info icon that reveals its note in a click-popover — the compact
 *  replacement for an always-on {@link InfoBox}. Sits in panel/section headers
 *  so the hint is one click away instead of taking permanent vertical space. */
export declare function InfoButton({ children, label, className }: InfoButtonProps): import("react").JSX.Element;
