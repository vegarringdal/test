import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { createPortal } from 'react-dom';
/** Right-click folder menu, body-portaled so tree scroll clipping can't cut
 *  it off. */
export function FileTreeMenu({ menu, onClose, onAddFolder, onRenameFolder, onDeleteFolder, }) {
    return createPortal(_jsxs("div", { className: "fixed z-[3000] flex min-w-36 flex-col border border-slate-700 bg-slate-800 shadow-black/50 shadow-lg", style: { left: Math.min(menu.x, window.innerWidth - 160), top: Math.min(menu.y, window.innerHeight - 90) }, onMouseLeave: onClose, children: [_jsx("button", { type: "button", className: "px-3 py-1 text-left text-slate-200 text-xs hover:bg-slate-700", onClick: () => {
                    onAddFolder(menu.dirPath);
                    onClose();
                }, children: menu.dirPath != null ? 'New folder inside…' : 'New folder…' }), menu.dirPath != null && !menu.section && onRenameFolder && (_jsx("button", { type: "button", className: "px-3 py-1 text-left text-slate-200 text-xs hover:bg-slate-700", onClick: () => {
                    const d = menu.dirPath;
                    onClose();
                    if (d != null) {
                        onRenameFolder(d);
                    }
                }, children: "Rename folder\u2026" })), menu.dirPath != null && !menu.section && onDeleteFolder && (_jsx("button", { type: "button", className: "px-3 py-1 text-left text-red-300 text-xs hover:bg-slate-700", onClick: () => {
                    const d = menu.dirPath;
                    onClose();
                    if (d != null) {
                        onDeleteFolder(d);
                    }
                }, children: "Delete folder\u2026" }))] }), document.body);
}
