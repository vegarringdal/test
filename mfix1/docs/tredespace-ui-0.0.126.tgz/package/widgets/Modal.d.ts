import { type ReactNode } from 'react';
export interface ModalProps {
    z: number;
    children: ReactNode;
    /** Escape and a backdrop press close the modal. Without it the shell is
     *  purely visual and the caller owns dismissal (a blocking progress overlay). */
    onClose?: () => void;
    /** Keep the backdrop inert and close on Escape only (default true closes on
     *  both) — for a dialog whose work would be lost by a stray click. */
    closeOnBackdrop?: boolean;
    onKeyDown?: (e: React.KeyboardEvent) => void;
}
/** Shared modal shell: dimmed backdrop + centred window at the given layer. */
export declare function Modal({ z, children, onClose, closeOnBackdrop, onKeyDown }: ModalProps): import("react").ReactPortal;
export interface TitleBarProps {
    icon: ReactNode;
    children: ReactNode;
    /** Renders a ✕ at the right end. */
    onClose?: () => void;
    className?: string;
}
/** A dialog's title strip: icon, title, optional close ✕. */
export declare function TitleBar({ icon, children, onClose, className }: TitleBarProps): import("react").JSX.Element;
