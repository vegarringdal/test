import type { ReactNode } from 'react';
export interface PanelHeaderProps {
    /** Left-hand title — truncates when the panel narrows. */
    title: ReactNode;
    /** Dim notes between the title and the actions (counts, status). */
    aside?: ReactNode;
    /** Buttons / InfoButton at the right end. */
    actions?: ReactNode;
    /**
     * `label` — a dim section caption over a form (the default);
     * `title` — the panel's own name, in full contrast over content;
     * `band` — a tinted strip, for a mode bar that is not the panel title.
     */
    variant?: 'label' | 'title' | 'band';
    className?: string;
}
/** The fixed top strip of a panel: title, dim asides, actions. Pinned by the
 *  caller (`shrink-0` is built in), so only the content below it scrolls. */
export declare function PanelHeader({ title, aside, actions, variant, className }: PanelHeaderProps): import("react").JSX.Element;
