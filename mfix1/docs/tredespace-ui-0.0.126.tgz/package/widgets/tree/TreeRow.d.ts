import type { CSSProperties, MouseEvent as ReactMouseEvent } from 'react';
import type { TreeRowExtras, TreeViewRow } from './treeViewTypes';
type Props = Readonly<{
    row: TreeViewRow;
    style: CSSProperties;
    extras: TreeRowExtras | undefined;
    onToggle?: (row: TreeViewRow) => void;
    onRowClick?: (row: TreeViewRow, e: ReactMouseEvent) => void;
    onRowContextMenu?: (row: TreeViewRow, e: ReactMouseEvent) => void;
}>;
/** One tree line: partial bar, twisty, icon, label, trailing node. The twisty
 *  toggles expansion ONLY — it never touches the selection. */
export declare function TreeRow({ row, style, extras, onToggle, onRowClick, onRowContextMenu }: Props): import("react").JSX.Element;
export {};
