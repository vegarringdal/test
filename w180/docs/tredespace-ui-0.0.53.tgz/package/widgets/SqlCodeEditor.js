import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useLayoutEffect, useRef } from 'react';
import { cn } from '../lib/cn';
import { EDITOR_TEXT, highlightSql } from './sqlHighlight';
/** The editor. Scroll position is mirrored from the textarea onto the
 *  highlight layer and the gutter, so all three stay glued together. */
export function SqlCodeEditor({ value, onChange, onRun, onSelect, resizable, className }) {
    const taRef = useRef(null);
    const preRef = useRef(null);
    const gutterRef = useRef(null);
    const lines = value.split('\n').length;
    const syncScroll = () => {
        const ta = taRef.current;
        if (!ta) {
            return;
        }
        if (preRef.current) {
            preRef.current.scrollTop = ta.scrollTop;
            preRef.current.scrollLeft = ta.scrollLeft;
        }
        if (gutterRef.current) {
            gutterRef.current.scrollTop = ta.scrollTop;
        }
    };
    useLayoutEffect(syncScroll, []);
    return (_jsxs("div", { className: cn('flex min-h-0 border border-slate-800 bg-slate-950', resizable && 'resize-y overflow-hidden', className), children: [_jsx("div", { ref: gutterRef, className: cn(EDITOR_TEXT, 'select-none overflow-hidden border-slate-800 border-r bg-slate-900/60 px-1.5 py-1 text-right text-slate-600'), children: Array.from({ length: lines }, (_, i) => (_jsx("div", { children: i + 1 }, i))) }), _jsxs("div", { className: "relative min-w-0 flex-1", children: [_jsxs("pre", { ref: preRef, "aria-hidden": true, className: cn(EDITOR_TEXT, 'absolute inset-0 overflow-hidden p-1 text-slate-200'), children: [highlightSql(value), '\n'] }), _jsx("textarea", { ref: taRef, value: value, spellCheck: false, onChange: (e) => onChange(e.target.value), onScroll: syncScroll, onSelect: (e) => onSelect?.(e.currentTarget.selectionStart, e.currentTarget.selectionEnd), onKeyDown: (e) => {
                            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                                e.preventDefault();
                                onRun?.();
                            }
                            if (e.key === 'Tab') {
                                e.preventDefault();
                                const ta = e.currentTarget;
                                const { selectionStart: a, selectionEnd: b } = ta;
                                onChange(`${value.slice(0, a)}  ${value.slice(b)}`);
                                requestAnimationFrame(() => ta.setSelectionRange(a + 2, a + 2));
                            }
                        }, className: cn(EDITOR_TEXT, 'absolute inset-0 h-full w-full resize-none bg-transparent p-1 text-transparent caret-slate-100 outline-none') })] })] }));
}
