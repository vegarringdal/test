import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { timeToX } from './timelineMath';
/** Over the lanes: the dimmed outside of a focus window, the playhead line
 *  and the rubber-band box. */
export function TimelineOverlays({ view, labelWidth, playhead, minHeight, dimOutside, box }) {
    return (_jsxs(_Fragment, { children: [dimOutside && (_jsxs(_Fragment, { children: [_jsx("div", { className: "pointer-events-none absolute top-0 bottom-0 bg-slate-950/60", style: { left: labelWidth, width: Math.max(0, timeToX(dimOutside.from, view)) } }), _jsx("div", { className: "pointer-events-none absolute top-0 right-0 bottom-0 bg-slate-950/60", style: { left: labelWidth + Math.max(0, timeToX(dimOutside.to, view)) } })] })), _jsx("div", { className: "pointer-events-none absolute top-0 bottom-0 w-px bg-red-400/80", style: { left: labelWidth + timeToX(playhead, view), minHeight } }), box && (_jsx("div", { className: "pointer-events-none absolute border border-sky-300 bg-sky-400/10", style: {
                    left: Math.min(box.x0, box.x1),
                    top: Math.min(box.y0, box.y1),
                    width: Math.abs(box.x1 - box.x0),
                    height: Math.abs(box.y1 - box.y0),
                } }))] }));
}
