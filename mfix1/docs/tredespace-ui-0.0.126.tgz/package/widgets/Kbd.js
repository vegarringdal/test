import { jsx as _jsx } from "react/jsx-runtime";
import { cn } from '../lib/cn';
/** A key-cap chip for a shortcut combo — the read-only sibling of a Button,
 *  sized for a property row rather than a toolbar. */
export function Kbd({ children, className = '' }) {
    return (_jsx("kbd", { className: cn('inline-flex shrink-0 items-center border border-slate-700 bg-slate-800 px-1.5 py-px font-mono text-[10px] text-slate-300 leading-4', className), children: children }));
}
