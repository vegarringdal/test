export interface SwatchProps {
    /** Any CSS colour — rendered as-is, never converted (display values only). */
    color: string;
    onClick?: () => void;
    /** Ring the swatch as the current pick. */
    active?: boolean;
    /** Edge length in px (default 16). */
    size?: number;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    disabled?: boolean;
    className?: string;
}
/** A single colour chip — click-to-apply in a palette row, or a static
 *  read-out of a rule's colour when no `onClick` is given. */
export declare function Swatch({ color, onClick, active, size, tooltip, shortcut, disabled, className, }: SwatchProps): import("react").JSX.Element;
