import type { ReactNode } from 'react';
export interface DialogFrameProps {
    /** Title-bar icon (locked to 16×16 by the caller's choice of icon). */
    icon: ReactNode;
    /** Title-bar text. */
    title: ReactNode;
    /** The body. */
    children: ReactNode;
    /** Footer buttons, right-aligned above the bottom rule. */
    footer?: ReactNode;
    /** CSS width — a number is px (default 320). */
    width?: number | string;
    /** CSS height — omit to hug the content. */
    height?: number | string;
    /** CSS max height (default '80vh'); the body scrolls inside it. */
    maxHeight?: number | string;
    /** Escape, the backdrop and the title-bar ✕ all call this. Without it the
     *  dialog cannot be dismissed by the user (a blocking progress overlay). */
    onClose?: () => void;
    /** `alertdialog` for a message that interrupts (default `dialog`). */
    role?: 'dialog' | 'alertdialog';
    /** Stacking layer (default 2000, the dialog floor). */
    z?: number;
    /** Replaces the default body padding and text style (`px-3 py-4 text-xs
     *  leading-relaxed`) — for a dialog that composes its own strips (a filter
     *  bar over a scrolling list). The flex column and scrolling stay. */
    bodyClassName?: string;
    /** Extra classes on the dialog box. */
    className?: string;
}
/** The one dialog window: backdrop, bordered box, title bar with ✕, a body
 *  that scrolls within `maxHeight`, and a footer rule for the buttons. Every
 *  dialog in the app is this frame plus its content. */
export declare function DialogFrame({ icon, title, children, footer, width, height, maxHeight, onClose, role, z, bodyClassName, className, }: DialogFrameProps): import("react").JSX.Element;
