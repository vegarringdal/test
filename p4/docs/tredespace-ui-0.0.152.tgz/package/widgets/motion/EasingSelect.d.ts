import type { LabelledProps } from '../fieldChrome';
export interface EasingOption<E extends string> {
    /** The easing this segment picks. */
    value: E;
    /** Name of the easing — the segment's tooltip, and its text with `showLabels`. */
    label: string;
    /** The curve for the preview glyph: progress 0..1 → eased 0..1. */
    curve: (u: number) => number;
    /** Hotkey id (data-shortcut) of this choice — its tooltip gets a combo
     *  footer. */
    shortcut?: string;
}
export interface EasingSelectProps<E extends string> extends Pick<LabelledProps, 'disabled' | 'className'> {
    /** The selected easing. */
    value: E;
    /** The choices, left to right — you supply each curve. */
    options: readonly EasingOption<E>[];
    /** Receives the clicked easing. */
    onChange: (value: E) => void;
    /** Show the label next to each glyph (default: glyph only + tooltip). */
    showLabels?: boolean;
}
/**
 * Pick an easing curve: a segmented row of curve glyphs (linear, ease in, …)
 * so the choice is visible, not just named. Generic over the value union —
 * the caller supplies the curves.
 */
export declare function EasingSelect<E extends string>({ value, options, onChange, showLabels, disabled, className, }: EasingSelectProps<E>): import("react").JSX.Element;
