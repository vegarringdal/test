import { type RefObject } from 'react';
export type VirtualRows = Readonly<{
    /** the [first, last) row window to mount — includes the overscan */
    first: number;
    last: number;
    /** full content height: give the spacer the rows sit in this height */
    totalH: number;
    /** attach to the scroller's onScroll (or call after setting scrollTop) */
    onScroll: () => void;
}>;
/** Fixed-height row virtualization: which rows of `count` are in view in the
 *  `scroller` (a scrolling element the caller renders), plus the height of
 *  the spacer to lay them out in. Rows must all be `rowH` tall, so the window
 *  is pure arithmetic — no measuring. Mount only [first, last), each row
 *  absolutely positioned at `index * rowH` inside a `position: relative`
 *  spacer of `totalH`. The viewport height follows the element (ResizeObserver). */
export declare function useVirtualRows(scroller: RefObject<HTMLElement | null>, count: number, rowH: number, overscan?: number): VirtualRows;
