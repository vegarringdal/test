import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { IconHelpCircle } from '@tabler/icons-react';
import { Button } from './Button';
import { DialogFrame } from './DialogFrame';
/** Pure OK/Cancel dialog — props only, no store coupling. */
export function ConfirmDialogCore({ title, message, okLabel, cancelLabel, onResult, z = 2000, }) {
    return (_jsx(DialogFrame, { role: "alertdialog", z: z, icon: _jsx(IconHelpCircle, { size: 16, className: "shrink-0 text-blue-400" }), title: title, onClose: () => onResult(false), footer: _jsxs(_Fragment, { children: [_jsx(Button, { variant: "ghost", className: "px-4", onClick: () => onResult(false), children: cancelLabel }), _jsx(Button, { variant: "primary", className: "px-4", onClick: () => onResult(true), children: okLabel })] }), children: _jsx("span", { className: "whitespace-pre-line", children: message }) }));
}
