import { type ReactNode } from 'react';
export type BoxSides = [number, number, number, number];
export interface BoxSidesInputProps {
    /** top, right, bottom, left (CSS order) */
    value: BoxSides;
    /** Receives all four sides (CSS order). */
    onChange: (value: BoxSides) => void;
    /** Row caption before the linked field. */
    label?: ReactNode;
    /** Label width in px (default 48). */
    labelWidth?: number;
    /** Lower bound per side (default 0). */
    min?: number;
    /** Upper bound per side (default 400). */
    max?: number;
    /** Stepper step (default 1). */
    step?: number;
    /** Suffix on each field (default "px"). */
    unit?: string;
    /** Grey out the fields and the link toggle. */
    disabled?: boolean;
    /** Extra classes on the outer element. */
    className?: string;
}
/** Four sides of a box (padding, margin): linked = one value for all, or
 *  each side on its own. */
export declare function BoxSidesInput({ value, onChange, label, labelWidth, min, max, step, unit, disabled, className, }: BoxSidesInputProps): import("react").JSX.Element;
