import type { ReactNode } from 'react';
export interface EmptyStateProps {
    children: ReactNode;
    /** Icon shown above the text — `center` layout only. */
    icon?: ReactNode;
    /** `note` (default) is a dim line in the flow, for "no matches" under a
     *  list; `center` fills the remaining space, for an empty panel body. */
    layout?: 'note' | 'center';
    className?: string;
}
/** The one way a list or panel says it has nothing to show. Replaces the
 *  hand-rolled dim paragraphs so the wording sits in one visual language. */
export declare function EmptyState({ children, icon, layout, className }: EmptyStateProps): import("react").JSX.Element;
