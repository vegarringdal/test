import type { PointerEvent as ReactPointerEvent } from 'react';
import type { TimelineItem, TimelinePoint, TimelineProps } from './timelineTypes';
type Deps = Pick<TimelineProps, 'view' | 'snap' | 'items' | 'points' | 'onItemsMove' | 'onItemResize' | 'onPointsMove' | 'onSelect'>;
/** The item / edge / point drag gestures of the Timeline. */
export declare function useTimelineDrag(d: Deps): {
    dragItem: (e: ReactPointerEvent<HTMLElement>, item: TimelineItem) => void;
    dragEdge: (e: ReactPointerEvent<HTMLElement>, item: TimelineItem, edge: 'start' | 'end') => void;
    dragPoint: (e: ReactPointerEvent<HTMLElement>, point: TimelinePoint) => void;
};
export {};
