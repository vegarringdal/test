import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { cn } from '../lib/cn';
import { Modal, TitleBar } from './Modal';
/** The one dialog window: backdrop, bordered box, title bar with ✕, a body
 *  that scrolls within `maxHeight`, and a footer rule for the buttons. Every
 *  dialog in the app is this frame plus its content. */
export function DialogFrame({ icon, title, children, footer, width = 320, height, maxHeight = '80vh', onClose, role = 'dialog', z = 2000, bodyClassName, className = '', }) {
    return (_jsx(Modal, { z: z, onClose: onClose, children: _jsxs("div", { role: role, "aria-modal": "true", style: { width, height, maxHeight }, className: cn('flex flex-col border border-slate-600 bg-slate-900 shadow-black/50 shadow-xl', className), children: [_jsx(TitleBar, { icon: icon, onClose: onClose, children: title }), _jsx("div", { className: cn('flex min-h-0 flex-1 flex-col overflow-y-auto', bodyClassName ?? 'px-3 py-4 text-xs leading-relaxed'), children: children }), footer != null && (_jsx("div", { className: "flex shrink-0 justify-end gap-1.5 border-slate-800 border-t px-3 py-2", children: footer }))] }) }));
}
