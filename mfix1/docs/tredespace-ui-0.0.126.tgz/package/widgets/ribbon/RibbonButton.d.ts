import type { ReactNode, PointerEvent as ReactPointerEvent } from 'react';
import { type RibbonSize } from './ribbonSizes';
export interface RibbonButtonProps {
    /** Pass a Tabler/Heroicons element — it is locked to 18×18 regardless of size. Omit for text-only buttons. */
    icon?: ReactNode;
    label?: ReactNode;
    /** big = 1 per column, medium = 2 stacked, mini = 3 stacked. */
    size?: RibbonSize;
    selected?: boolean;
    /** Optional icon/label colour override while selected (default: theme blue). */
    selectedColor?: string;
    /** Fixed background — for swatch-style buttons; hover brightens it. */
    background?: string;
    /** Small counter/annotation shown above a big button. */
    badge?: ReactNode;
    disabled?: boolean;
    title?: string;
    /** Styled tooltip (data-tooltip); supports "\n" for multiple lines. */
    tooltip?: string;
    /** Hotkey id (see hotkeys/bindings.ts). Renders data-shortcut; the tooltip
     *  gets a footer line showing the current combo. */
    shortcut?: string;
    onClick?: () => void;
    /** Raw pointer-down — used to start a drag (e.g. dragging a panel out of the
     *  Panels ribbon into the dock). */
    onPointerDown?: (e: ReactPointerEvent) => void;
    className?: string;
}
/** The ribbon's button: big icon-over-label, or medium/mini stacked rows. */
export declare function RibbonButton({ icon, label, size, selected, selectedColor, background, badge, disabled, title, tooltip, shortcut, onClick, onPointerDown, className, }: RibbonButtonProps): import("react").JSX.Element;
