import type { TimelineProps } from './timelineTypes';
export type { DropHint, TimelineItem, TimelinePoint, TimelineProps, TimelineRow, TimelineSnap, TimelineView, } from './timelineTypes';
/**
 * A multi-lane timeline: rows (groups and lanes) with a label column, items
 * (span bars, clip blocks) that drag with snapping and propose magnetic links
 * (after / with / ends with — Alt drops without one), edge resize, key points
 * (filled or hollow diamonds, markers), a playhead, an end mark, an optional
 * dimmed outside and an in/out range. Pure
 * presentation: every edit is reported through the callbacks.
 *
 * Mouse: drag the ruler to scrub, Shift+drag it for a range; Ctrl+wheel
 * zooms, Shift+wheel pans; drag empty lane space to box-select. A scrub or a
 * clip / edge / key drag held at or past an edge pans the view and rides
 * along.
 * Keys: ←/→ move the playhead (Shift = 1 s) and keep it in view, +/− zoom.
 *
 * Rows are virtualized (all `rowHeight` tall), so thousands of lanes cost
 * only the ones in view.
 */
export declare function Timeline(p: TimelineProps): import("react").JSX.Element;
