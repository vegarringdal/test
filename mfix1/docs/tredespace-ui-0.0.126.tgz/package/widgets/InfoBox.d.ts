import type { ReactNode } from 'react';
import { type Tone } from './tone';
export interface InfoBoxProps {
    children: ReactNode;
    /** Semantic colour — `warning` (the default) is the hint/caution note,
     *  `danger` a failure the user must act on. */
    tone?: Tone;
    /** Replaces the tone's default icon; null drops the icon entirely. */
    icon?: ReactNode | null;
    className?: string;
}
/** A padded, tinted note — for hints, warnings and inline failures. */
export declare function InfoBox({ children, tone, icon, className }: InfoBoxProps): import("react").JSX.Element;
