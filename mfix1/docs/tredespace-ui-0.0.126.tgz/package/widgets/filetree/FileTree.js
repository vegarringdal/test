import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// A file-tree picker. Multi-select like a desktop file manager: click =
// select one, Ctrl+click = toggle, Shift+click = range over the VISIBLE rows,
// folder chevron = toggle expansion, folder Ctrl/plain click selects/deselects
// everything under it. Optional drag-and-drop moves and a right-click folder
// menu — see FileTreeProps.
import { IconFile3d } from '@tabler/icons-react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { cn } from '../../lib/cn';
import { Menu } from '../menu/Menu';
import { TreeView } from '../tree/TreeView';
import { dirPaths, visibleRows } from './fileTreeModel';
import { toTreeRows } from './fileTreeRows';
import { useFileTreeSelection } from './useFileTreeSelection';
/** Controlled tree: `selected` is a set of file paths owned by the parent.
 *  Optional extras: `onMove` enables dragging the selected files onto a folder
 *  (or the root gap) and `onAddFolder` adds a right-click → New folder menu. */
export function FileTree({ root, selected, onSelect, onMove, onAddFolder, onRenameFolder, onDeleteFolder, onMoveFolder, emptyText = 'No files found.', fileIcon = _jsx(IconFile3d, { size: 13, className: "shrink-0 text-slate-400" }), defaultCollapsed, expandAll = false, collapseAllSignal, expandAllSignal, className, }) {
    const [collapsed, setCollapsed] = useState(() => new Set(defaultCollapsed));
    // the signals are edge-triggered: only a CHANGE acts, so a remount with the
    // same counter value (e.g. a `key` change) keeps `defaultCollapsed`
    const lastSignal = useRef({ collapse: collapseAllSignal, expand: expandAllSignal });
    useEffect(() => {
        if (collapseAllSignal !== lastSignal.current.collapse) {
            lastSignal.current.collapse = collapseAllSignal;
            setCollapsed(new Set(dirPaths(root)));
        }
    }, [collapseAllSignal, root]);
    useEffect(() => {
        if (expandAllSignal !== lastSignal.current.expand) {
            lastSignal.current.expand = expandAllSignal;
            setCollapsed(new Set());
        }
    }, [expandAllSignal]);
    const [dropDir, setDropDir] = useState(null);
    const [menu, setMenu] = useState(null);
    /** Paths that travel in a drag: the whole selection when dragging a selected
     *  row, else just the dragged row. */
    const dragPaths = (path) => (selected.has(path) ? [...selected] : [path]);
    const rows = useMemo(() => visibleRows(root, collapsed, expandAll), [root, collapsed, expandAll]);
    const byKey = useMemo(() => new Map(rows.map((r) => [r.node.path || r.node.name, r])), [rows]);
    const visibleFiles = rows.filter((r) => r.node.kind === 'file').map((r) => r.node.path);
    const { click } = useFileTreeSelection(selected, onSelect, visibleFiles);
    const treeRows = useMemo(() => toTreeRows(rows, selected, collapsed, expandAll, fileIcon), [rows, selected, collapsed, expandAll, fileIcon]);
    const toggleExpand = (path) => {
        setCollapsed((c) => {
            const next = new Set(c);
            if (next.has(path)) {
                next.delete(path);
            }
            else {
                next.add(path);
            }
            return next;
        });
    };
    const nodeOf = (row) => byKey.get(row.key);
    /** Drag-and-drop and the data-dir markers the container's menu handler reads. */
    const rowExtras = (row) => {
        const r = nodeOf(row);
        if (!r) {
            return undefined;
        }
        const n = r.node;
        const isSection = n.kind === 'dir' && n.variant === 'section';
        return {
            draggable: (onMove != null && n.kind === 'file') || (onMoveFolder != null && n.kind === 'dir' && !isSection),
            className: cn(onMove && n.kind === 'dir' && dropDir === n.path && 'bg-blue-900 text-blue-100'),
            data: { 'data-dir': n.kind === 'dir' ? n.path : undefined, 'data-section': isSection ? '1' : undefined },
            onDragStart: (e) => {
                if (n.kind === 'file') {
                    e.dataTransfer.setData('text/x-asset-paths', JSON.stringify(dragPaths(n.path)));
                }
                else {
                    e.dataTransfer.setData('text/x-asset-dir', n.path);
                }
            },
            onDragOver: (e) => {
                if ((onMove || onMoveFolder) && n.kind === 'dir') {
                    e.preventDefault();
                    e.stopPropagation();
                    setDropDir(n.path);
                }
            },
            onDrop: (e) => {
                if (n.kind !== 'dir') {
                    return;
                }
                e.preventDefault();
                e.stopPropagation();
                const paths = e.dataTransfer.getData('text/x-asset-paths');
                const dir = e.dataTransfer.getData('text/x-asset-dir');
                if (paths && onMove) {
                    onMove(JSON.parse(paths), n.path);
                }
                else if (dir && onMoveFolder && dir !== n.path) {
                    onMoveFolder(dir, n.path);
                }
                setDropDir(null);
            },
        };
    };
    const menuItems = (m) => {
        const dir = m.dirPath;
        const editable = dir != null && !m.section;
        return [
            {
                id: 'add',
                label: dir != null ? 'New folder inside…' : 'New folder…',
                onSelect: () => onAddFolder?.(dir),
            },
            editable &&
                onRenameFolder != null && { id: 'rename', label: 'Rename folder…', onSelect: () => onRenameFolder(dir) },
            editable &&
                onDeleteFolder != null && {
                id: 'delete',
                label: 'Delete folder…',
                danger: true,
                onSelect: () => onDeleteFolder(dir),
            },
        ];
    };
    return (_jsxs("div", { className: cn('relative flex select-none flex-col border border-slate-800', className ?? 'max-h-64'), onContextMenu: (e) => {
            if (!onAddFolder) {
                return;
            }
            e.preventDefault();
            // Element, not HTMLElement: a right-click on a row's icon targets an
            // SVGElement, which would otherwise lose the row it came from
            const rowEl = e.target instanceof Element ? e.target.closest('[data-dir]') : null;
            setMenu({
                x: e.clientX,
                y: e.clientY,
                dirPath: rowEl?.getAttribute('data-dir') ?? null,
                section: rowEl?.getAttribute('data-section') != null,
            });
        }, onDragOver: (e) => {
            if (onMove || onMoveFolder) {
                e.preventDefault();
                setDropDir('');
            }
        }, onDrop: (e) => {
            e.preventDefault();
            const paths = e.dataTransfer.getData('text/x-asset-paths');
            const dir = e.dataTransfer.getData('text/x-asset-dir');
            if (paths && onMove && dropDir != null) {
                onMove(JSON.parse(paths), dropDir === '' ? '' : dropDir);
            }
            else if (dir && onMoveFolder) {
                onMoveFolder(dir, '');
            }
            setDropDir(null);
        }, onDragLeave: () => setDropDir(null), children: [menu && onAddFolder && (_jsx(Menu, { anchor: menu, items: menuItems(menu), minWidth: 144, onClose: () => setMenu(null) })), _jsx(TreeView, { rows: treeRows, className: "min-h-0 flex-1", emptyText: emptyText, rowProps: rowExtras, onToggle: (row) => toggleExpand(row.key), onRowClick: (row, e) => {
                    setMenu(null);
                    const r = nodeOf(row);
                    if (r) {
                        click(r, e);
                    }
                } })] }));
}
