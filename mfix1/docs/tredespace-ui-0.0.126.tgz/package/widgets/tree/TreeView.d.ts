import { type MouseEvent as ReactMouseEvent, type ReactNode, type RefObject } from 'react';
import type { TreeRowExtras, TreeViewRow } from './treeViewTypes';
export type { TreeRowExtras, TreeViewRow } from './treeViewTypes';
export interface TreeViewProps {
    /** The rows that are VISIBLE right now, already flattened by the caller —
     *  the tree draws, it does not own the model. Collapsed subtrees are simply
     *  absent, so a lazily-loaded tree costs nothing until it is expanded. */
    rows: readonly TreeViewRow[];
    onToggle?: (row: TreeViewRow) => void;
    onRowClick?: (row: TreeViewRow, e: ReactMouseEvent) => void;
    onRowContextMenu?: (row: TreeViewRow, e: ReactMouseEvent) => void;
    /** Fixed row height in px — turns on virtualization (only the rows in view
     *  are mounted). Omit for a short tree that can render whole. */
    rowHeight?: number;
    /** px of indent per depth level (default 14). */
    indent?: number;
    /** px of padding before a depth-0 row (default 6). */
    padLeft?: number;
    /** Own the scroller ref to scroll a row into view (a reveal). */
    scrollerRef?: RefObject<HTMLDivElement | null>;
    /** Drag-and-drop and `data-*` markers, per row. */
    rowProps?: (row: TreeViewRow) => TreeRowExtras | undefined;
    /** Shown instead of the rows when there are none. */
    emptyText?: ReactNode;
    className?: string;
}
/**
 * The app's tree list: indent, twisty, selection and partial-selection
 * highlighting over a flat list of visible rows. Virtualized when `rowHeight`
 * is given — rows are then absolutely positioned inside a full-height spacer,
 * so a tree with thousands of open rows still re-renders a screenful.
 */
export declare function TreeView({ rows, onToggle, onRowClick, onRowContextMenu, rowHeight, indent, padLeft, scrollerRef, rowProps, emptyText, className, }: TreeViewProps): import("react").JSX.Element;
