import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconInfoCircle } from '@tabler/icons-react';
/** A padded, tinted note with a circled info icon — for hints/explanations. */
export function InfoBox({ children, className = '' }) {
    return (_jsxs("div", { className: `flex items-start gap-2 border border-amber-500/30 bg-amber-500/10 px-2 py-1.5 text-[11px] text-slate-300 leading-relaxed ${className}`, children: [_jsx(IconInfoCircle, { size: 15, className: "mt-px shrink-0 text-amber-400" }), _jsx("div", { children: children })] }));
}
