export type HSV = {
    h: number;
    s: number;
    v: number;
};
export type RGB = {
    r: number;
    g: number;
    b: number;
};
export declare const isHex: (s: string) => boolean;
export declare function hexToRgb(hex: string): RGB;
export declare function rgbToHex({ r, g, b }: RGB): string;
export declare function rgbToHsv({ r, g, b }: RGB): HSV;
export declare function hsvToRgb({ h, s, v }: HSV): RGB;
