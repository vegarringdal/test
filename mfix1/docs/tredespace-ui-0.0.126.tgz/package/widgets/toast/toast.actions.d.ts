export interface ToastOptions {
    /** Bold first line above the message. */
    title?: string;
    /** ms before it auto-dismisses (default 4000); 0 keeps it until closed. */
    duration?: number;
}
declare function dismiss(id: string): void;
/**
 * Non-blocking notifications — the alternative to stopping the user with a
 * confirm() they can only acknowledge. Callable from anywhere, React or not;
 * render {@link Toaster} once at the app root to show them.
 */
export declare const toast: {
    info: (message: string, opts?: ToastOptions) => string;
    success: (message: string, opts?: ToastOptions) => string;
    warning: (message: string, opts?: ToastOptions) => string;
    /** Errors stay until dismissed — the user must be able to read them. */
    error: (message: string, opts?: ToastOptions) => string;
    dismiss: typeof dismiss;
    /** Pause the countdown (pointer over the stack) and resume it on leave. */
    hold: (id: string) => void;
    resume: (id: string, duration: number) => void;
    clear: () => void;
};
export {};
