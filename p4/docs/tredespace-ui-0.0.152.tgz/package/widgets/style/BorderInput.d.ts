import type { ReactNode } from 'react';
export interface BorderValue {
    /** Line width in px (the field allows 0–40). */
    width: number;
    /** #rrggbb, or a token / {{key}} reference (then shown as text, not edited). */
    color: string;
    /** Line style. */
    style: 'solid' | 'dashed';
}
export interface BorderInputProps {
    /** null = no border */
    value: BorderValue | null;
    /** Receives the new border, or null when unticked; ticking starts from 1 px solid #94a3b8. */
    onChange: (value: BorderValue | null) => void;
    /** The on/off checkbox's caption (default "Border"). */
    label?: ReactNode;
    /** Grey out every control. */
    disabled?: boolean;
    /** Extra classes on the outer element. */
    className?: string;
}
/** A border: on/off, width, colour, solid or dashed. A colour that is not a
 *  hex (a theme token like "$accent", a "{{value}}" reference) is shown as
 *  text — the caller edits it with its own field. */
export declare function BorderInput({ value, onChange, label, disabled, className }: BorderInputProps): import("react").JSX.Element;
