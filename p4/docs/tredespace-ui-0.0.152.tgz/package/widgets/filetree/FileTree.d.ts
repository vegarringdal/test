import { type ReactNode } from 'react';
import { type TreeDir } from './fileTreeModel';
export type { TreeDir, TreeFile, TreeNode } from './fileTreeModel';
export interface FileTreeProps {
    /** The root dir; only its children are drawn. */
    root: TreeDir;
    /** Selected FILE paths (a folder row shows selected when every file under it is). */
    selected: Set<string>;
    /** Next selection — click / Ctrl+click / Shift+click range; a folder row selects its subtree. */
    onSelect: (next: Set<string>) => void;
    /** Enables dragging files (the selection, when a selected row is dragged) onto a folder; `dirPath` '' = root. */
    onMove?: (paths: string[], dirPath: string) => void;
    /** Right-click → New folder (`null` = the root). Also what turns the right-click menu on. */
    onAddFolder?: (parentDirPath: string | null) => void;
    /** Right-click a folder → Rename (dirPath is the row's path; needs `onAddFolder` for the menu). */
    onRenameFolder?: (dirPath: string) => void;
    /** Right-click a folder → Delete (empty folders vanish; files get ungrouped; needs `onAddFolder`). */
    onDeleteFolder?: (dirPath: string) => void;
    /** Drag a folder row onto another folder (or the root gap — `targetDirPath` ''). */
    onMoveFolder?: (dirPath: string, targetDirPath: string) => void;
    /** Shown when the tree has no rows. */
    emptyText?: string;
    /** Per-row file icon (locked to 13px by the caller's choice of icon). */
    fileIcon?: ReactNode;
    /** Dir paths that start collapsed (initial state only — re-applied when the
     *  component remounts, e.g. via a `key` change). */
    defaultCollapsed?: readonly string[];
    /** Render every dir expanded regardless of collapse state (e.g. while a
     *  search filter is active); the stored state returns when turned off. */
    expandAll?: boolean;
    /** Bump to collapse every directory (a counter the parent increments — a
     *  toolbar button or hotkey; the tree keeps owning the per-dir state). */
    collapseAllSignal?: number;
    /** Bump to expand every directory. */
    expandAllSignal?: number;
    /** Overrides the default max-h-64 scroll box (e.g. `min-h-0 flex-1` to fill). */
    className?: string;
}
/** Controlled tree: `selected` is a set of file paths owned by the parent.
 *  Optional extras: `onMove` enables dragging the selected files onto a folder
 *  (or the root gap) and `onAddFolder` adds a right-click → New folder menu. */
export declare function FileTree({ root, selected, onSelect, onMove, onAddFolder, onRenameFolder, onDeleteFolder, onMoveFolder, emptyText, fileIcon, defaultCollapsed, expandAll, collapseAllSignal, expandAllSignal, className, }: FileTreeProps): import("react").JSX.Element;
