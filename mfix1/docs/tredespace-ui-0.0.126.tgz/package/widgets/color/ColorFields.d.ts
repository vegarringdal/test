import { type HSV, type RGB } from './colorConversions';
/** Hex + R/G/B entry row; text state stays local while a field is edited so
 *  half-typed values don't fight the live color. */
export declare function ColorFields({ hex, rgb, apply }: {
    hex: string;
    rgb: RGB;
    apply: (next: HSV) => void;
}): import("react").JSX.Element;
