type Props = Readonly<{
    label: string;
    branch: boolean;
    onClick: (at: {
        x: number;
        y: number;
    }) => void;
    onInsert: () => void;
}>;
/** The chip between two cards ("then", "together", …) with the + that
 *  inserts a card there (shown on hover). */
export declare function CardFlowLink({ label, branch, onClick, onInsert }: Props): import("react").JSX.Element;
export {};
