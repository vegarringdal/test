import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconX } from '@tabler/icons-react';
import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { cn } from '../lib/cn';
// Escape belongs to the TOP dialog only: a document listener would close a
// stack of them at once, and a React onKeyDown only fires while focus happens
// to be inside. Every open Modal with an onClose registers here in mount order
// and the last one wins.
const escapeStack = [];
function useEscapeToClose(onClose) {
    const latest = useRef(onClose);
    latest.current = onClose;
    const dismissable = onClose != null;
    useEffect(() => {
        if (!dismissable) {
            return;
        }
        const close = () => latest.current?.();
        escapeStack.push(close);
        const onKey = (e) => {
            if (e.key === 'Escape' && escapeStack[escapeStack.length - 1] === close) {
                e.stopPropagation();
                close();
            }
        };
        window.addEventListener('keydown', onKey, true);
        return () => {
            window.removeEventListener('keydown', onKey, true);
            const i = escapeStack.indexOf(close);
            if (i !== -1) {
                escapeStack.splice(i, 1);
            }
        };
        // Only whether the modal is dismissable matters here; the callback itself
        // is read through the ref, so a fresh closure never re-binds the listener.
    }, [dismissable]);
}
/** Shared modal shell: dimmed backdrop + centred window at the given layer. */
export function Modal({ z, children, onClose, closeOnBackdrop = true, onKeyDown }) {
    useEscapeToClose(onClose);
    return createPortal(_jsx("div", { className: "fixed inset-0 flex items-center justify-center bg-black/40 text-slate-200", style: { zIndex: z }, onKeyDown: onKeyDown, onPointerDown: (e) => {
            if (onClose && closeOnBackdrop && e.target === e.currentTarget) {
                onClose();
            }
        }, children: children }), document.body);
}
/** A dialog's title strip: icon, title, optional close ✕. */
export function TitleBar({ icon, children, onClose, className = '' }) {
    return (_jsxs("div", { className: cn('flex shrink-0 items-center gap-2 border-slate-800 border-b bg-slate-800 px-3 py-2 font-semibold text-xs', className), children: [icon, children, onClose != null && (_jsx("button", { type: "button", "aria-label": "Close", "data-tooltip": "Close", className: "ml-auto shrink-0 cursor-pointer text-slate-400 hover:text-slate-200", onClick: onClose, children: _jsx(IconX, { size: 15 }) }))] }));
}
