import { dropHintFor, snapSpanDelta, snapTime } from './timelineMath';
/** px of travel before a press on an item becomes a drag (else a click). */
const DRAG_THRESHOLD = 3;
/** One pointer gesture on capture: calls `move(dxPx, ev)` past the
 *  threshold, then `end(moved, ev)`. */
function gesture(e, move, end) {
    const el = e.currentTarget;
    const x0 = e.clientX;
    let moved = false;
    el.setPointerCapture(e.pointerId);
    const onMove = (ev) => {
        if (!moved && Math.abs(ev.clientX - x0) < DRAG_THRESHOLD) {
            return;
        }
        moved = true;
        move(ev.clientX - x0, ev);
    };
    const onUp = (ev) => {
        el.removeEventListener('pointermove', onMove);
        el.removeEventListener('pointerup', onUp);
        el.removeEventListener('pointercancel', onUp);
        end(moved, ev);
    };
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerup', onUp);
    el.addEventListener('pointercancel', onUp);
}
/** The item / edge / point drag gestures of the Timeline. */
export function useTimelineDrag(d) {
    const additive = (e) => e.shiftKey || e.ctrlKey || e.metaKey;
    const dragItem = (e, item) => {
        e.stopPropagation();
        if (item.locked) {
            return;
        }
        if (!item.selected || additive(e)) {
            d.onSelect({ items: [item.id], points: [] }, additive(e));
        }
        if (item.fixed) {
            return;
        }
        const ids = item.selected ? d.items.filter((i) => i.selected && !i.locked && !i.fixed).map((i) => i.id) : [item.id];
        const moving = new Set(ids);
        const others = d.items.filter((i) => !moving.has(i.id));
        let last = { dt: 0, hint: null };
        gesture(e, (dx, ev) => {
            const dt = snapSpanDelta(item.start, item.end, dx / d.view.pxPerSec, d.snap, d.view);
            const hint = ev.altKey
                ? null
                : dropHintFor({ id: item.id, start: item.start + dt, end: item.end + dt }, others, d.view);
            last = { dt, hint };
            d.onItemsMove(ids, dt, hint, 'drag');
        }, (moved, ev) => {
            if (moved) {
                d.onItemsMove(ids, last.dt, ev.altKey ? null : last.hint, 'end');
            }
        });
    };
    const dragEdge = (e, item, edge) => {
        e.stopPropagation();
        if (item.locked || item.fixed) {
            return;
        }
        const base = edge === 'start' ? item.start : item.end;
        let lastT = base;
        gesture(e, (dx, ev) => {
            lastT = Math.max(0, snapTime(base + dx / d.view.pxPerSec, d.snap, d.view));
            d.onItemResize(item.id, edge, lastT, ev.shiftKey, 'drag');
        }, (moved, ev) => {
            if (moved) {
                d.onItemResize(item.id, edge, lastT, ev.shiftKey, 'end');
            }
        });
    };
    const dragPoint = (e, point) => {
        e.stopPropagation();
        if (!point.selected || additive(e)) {
            d.onSelect({ items: [], points: [point.id] }, additive(e));
        }
        const ids = point.selected ? d.points.filter((p) => p.selected).map((p) => p.id) : [point.id];
        let lastDt = 0;
        gesture(e, (dx) => {
            lastDt = snapTime(point.t + dx / d.view.pxPerSec, d.snap, d.view) - point.t;
            d.onPointsMove(ids, lastDt, 'drag');
        }, (moved) => {
            if (moved) {
                d.onPointsMove(ids, lastDt, 'end');
            }
        });
    };
    return { dragItem, dragEdge, dragPoint };
}
