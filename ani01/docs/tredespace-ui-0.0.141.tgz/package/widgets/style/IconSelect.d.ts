import type { ReactNode } from 'react';
export interface IconSelectProps {
    value: string;
    /** the fixed icon set to choose from */
    icons: readonly {
        name: string;
        label?: string;
        node: ReactNode;
    }[];
    onChange: (value: string) => void;
    disabled?: boolean;
    className?: string;
}
/** Pick one icon from a fixed set — a compact grid of glyph buttons. */
export declare function IconSelect({ value, icons, onChange, disabled, className }: IconSelectProps): import("react").JSX.Element;
