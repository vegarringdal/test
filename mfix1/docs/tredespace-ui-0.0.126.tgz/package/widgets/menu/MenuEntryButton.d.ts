import type { MenuItem } from './menuTypes';
/** One menu entry. Picking it closes the menu first, so a handler that opens
 *  a dialog never leaves the menu floating behind it. */
export declare function MenuEntryButton({ item, onClose }: {
    item: MenuItem;
    onClose: () => void;
}): import("react").JSX.Element;
