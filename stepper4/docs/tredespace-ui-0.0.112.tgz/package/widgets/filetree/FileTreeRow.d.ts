import type { ReactNode } from 'react';
import { type TreeRow } from './fileTreeModel';
/** One tree row: chevron (dirs), icon, name, note/count, selection highlight,
 *  and the drag-and-drop handlers for moving files/folders. */
export declare function FileTreeRow({ r, selected, collapsed, dropDir, setDropDir, toggleExpand, onRowClick, dragPaths, onMove, onMoveFolder, fileIcon, }: {
    r: TreeRow;
    selected: Set<string>;
    collapsed: Set<string>;
    dropDir: string | null;
    setDropDir: (d: string | null) => void;
    toggleExpand: (path: string) => void;
    onRowClick: (row: TreeRow, e: React.MouseEvent) => void;
    dragPaths: (path: string) => string[];
    onMove?: (paths: string[], dirPath: string) => void;
    onMoveFolder?: (dirPath: string, targetDirPath: string) => void;
    fileIcon: ReactNode;
}): import("react").JSX.Element;
