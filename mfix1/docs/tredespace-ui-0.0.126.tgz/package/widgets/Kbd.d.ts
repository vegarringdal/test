import type { ReactNode } from 'react';
export interface KbdProps {
    children: ReactNode;
    className?: string;
}
/** A key-cap chip for a shortcut combo — the read-only sibling of a Button,
 *  sized for a property row rather than a toolbar. */
export declare function Kbd({ children, className }: KbdProps): import("react").JSX.Element;
