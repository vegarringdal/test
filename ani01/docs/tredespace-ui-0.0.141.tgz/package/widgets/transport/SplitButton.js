import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconChevronDown } from '@tabler/icons-react';
import { useState } from 'react';
import { cn } from '../../lib/cn';
import { BUTTON_ACTIVE, BUTTON_BASE, BUTTON_ICON_BOX, BUTTON_ICON_SIZE, BUTTON_SIZE, BUTTON_VARIANT, } from '../buttonStyles';
import { Menu } from '../menu/Menu';
/**
 * A button with a default action and a chevron that opens a short menu of
 * alternatives (Play | ▾ Return / Keep my view / Back to my pause view). The
 * two halves share their edge like a SegmentedControl, so they read as one
 * control; the menu opens under the chevron.
 */
export function SplitButton({ label, icon, onClick, menu, tooltip, shortcut, menuTooltip = 'More options', variant = 'default', size = 'md', active = false, disabled = false, grow = false, className = '', }) {
    const [anchor, setAnchor] = useState(null);
    const tone = active ? BUTTON_ACTIVE : BUTTON_VARIANT[variant];
    const openMenu = (e) => {
        const r = e.currentTarget.getBoundingClientRect();
        setAnchor(anchor ? null : { x: r.left, y: r.bottom + 2 });
    };
    return (_jsxs("div", { role: "group", className: cn('inline-flex min-w-0 items-stretch', grow && 'flex flex-1', className), children: [_jsxs("button", { type: "button", disabled: disabled, "data-tooltip": tooltip, "data-shortcut": shortcut, className: cn(BUTTON_BASE, BUTTON_SIZE[size], tone, grow && 'min-w-0 flex-1', 'cursor-pointer disabled:cursor-not-allowed disabled:opacity-40'), onClick: onClick, children: [icon != null && (_jsx("span", { className: cn('flex shrink-0 items-center justify-center', BUTTON_ICON_BOX[size]), children: icon })), label] }), _jsx("button", { type: "button", "aria-haspopup": "menu", "aria-expanded": anchor !== null, disabled: disabled, "data-tooltip": menuTooltip, className: cn(BUTTON_BASE, BUTTON_ICON_SIZE[size], BUTTON_VARIANT[variant], '-ml-px cursor-pointer disabled:cursor-not-allowed disabled:opacity-40'), onClick: openMenu, children: _jsx(IconChevronDown, { size: 12 }) }), _jsx(Menu, { anchor: anchor, items: menu, onClose: () => setAnchor(null) })] }));
}
