import type { LabelledProps } from '../fieldChrome';
export interface ImagePickerProps extends LabelledProps {
    /** A `data:` URI, or null for no image. */
    value: string | null;
    onChange: (value: string | null) => void;
    /** Largest file accepted, in bytes (bigger files are refused with a note). */
    maxBytes: number;
    /** File-dialog filter (default PNG / JPEG / WebP / SVG). */
    accept?: string;
    tooltip?: string;
}
/**
 * Pick an image from disk into a `data:` URI (never a URL — the value stays
 * self-contained, so it can be saved in a file and drawn without network
 * access). Shows a thumbnail with a clear button; files over `maxBytes` are
 * refused with an inline note.
 */
export declare function ImagePicker({ value, onChange, maxBytes, accept, tooltip, disabled, className, ...labelled }: ImagePickerProps): import("react").JSX.Element;
