import { jsx as _jsx } from "react/jsx-runtime";
import { useRef } from 'react';
import { cn } from '../../lib/cn';
import { useVirtualRows } from '../../lib/useVirtualRows';
import { EmptyState } from '../EmptyState';
import { TreeRow } from './TreeRow';
/**
 * The app's tree list: indent, twisty, selection and partial-selection
 * highlighting over a flat list of visible rows. Virtualized when `rowHeight`
 * is given — rows are then absolutely positioned inside a full-height spacer,
 * so a tree with thousands of open rows still re-renders a screenful.
 */
export function TreeView({ rows, onToggle, onRowClick, onRowContextMenu, rowHeight, indent = 14, padLeft = 6, scrollerRef, rowProps, emptyText, className = '', }) {
    const ownRef = useRef(null);
    const scroller = scrollerRef ?? ownRef;
    // the hook is unconditional (rules of hooks); a rowHeight of 0 rows keeps it
    // inert when the caller renders the whole list
    const virtual = useVirtualRows(scroller, rowHeight ? rows.length : 0, rowHeight || 1);
    const virtualized = rowHeight != null;
    const shown = virtualized ? rows.slice(virtual.first, virtual.last) : rows;
    const styleOf = (i) => {
        const paddingLeft = padLeft + rows[i].depth * indent;
        if (virtualized) {
            return { paddingLeft, position: 'absolute', left: 0, top: i * (rowHeight ?? 0), height: rowHeight };
        }
        return { paddingLeft, paddingTop: 2, paddingBottom: 2 };
    };
    const body = shown.map((r, j) => {
        const i = virtualized ? virtual.first + j : j;
        return (_jsx(TreeRow, { row: r, style: styleOf(i), extras: rowProps?.(r), onToggle: onToggle, onRowClick: onRowClick, onRowContextMenu: onRowContextMenu }, r.key));
    });
    return (_jsx("div", { ref: scroller, className: cn('overflow-y-auto', className), onScroll: virtualized ? virtual.onScroll : undefined, children: rows.length === 0 && emptyText != null ? (_jsx(EmptyState, { className: "px-2", children: emptyText })) : virtualized ? (_jsx("div", { className: "relative", style: { height: virtual.totalH }, children: body })) : (body) }));
}
