export interface ErrorDialogCoreProps {
    title: string;
    message: string;
    onDismiss: () => void;
    z?: number;
}
/** Pure error dialog — props only, no store coupling. */
export declare function ErrorDialogCore({ title, message, onDismiss, z }: ErrorDialogCoreProps): import("react").JSX.Element;
