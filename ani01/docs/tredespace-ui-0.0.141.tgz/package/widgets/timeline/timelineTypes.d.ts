import type { ReactNode } from 'react';
/** The visible window: pixels per second and the time at the left edge. */
export interface TimelineView {
    pxPerSec: number;
    offset: number;
}
export interface TimelineRow {
    id: string;
    /** a group row (its items are span bars) or a plain lane */
    kind: 'group' | 'lane';
    depth: number;
    label: ReactNode;
    collapsed?: boolean;
    /** span bar / lane tint (CSS colour) */
    tint?: string;
    /** not editable (outside a focused range) */
    locked?: boolean;
    /** a collapsible row shows the twisty */
    collapsible?: boolean;
}
export interface TimelineItem {
    id: string;
    /** the row it is drawn in */
    row: string;
    start: number;
    end: number;
    label: string;
    tint?: string;
    selected?: boolean;
    /** reversed look (diagonal hatch) */
    hatched?: boolean;
    icon?: ReactNode;
    /** drawn as a thin span bar instead of a clip block (groups) */
    span?: boolean;
    /** linked to another item: a small connector is drawn from it */
    linkFrom?: {
        id: string;
        kind: string;
    };
    /** can't be moved or resized */
    locked?: boolean;
    /** selectable and openable, but its time follows something else: no
     *  drag, no resize edges, drawn at full strength (unlike `locked`) */
    fixed?: boolean;
}
export interface TimelinePoint {
    id: string;
    row: string;
    t: number;
    shape: 'diamond' | 'marker';
    selected?: boolean;
    label?: string;
}
/** Where a dragged item would link if dropped (magnetic linking). */
export type DropHint = {
    kind: 'after' | 'with' | 'endsWith';
    target: string;
};
export interface TimelineSnap {
    enabled: boolean;
    /** grid step in seconds (0 = no grid) */
    step: number;
    /** extra snap times (keys, markers, item edges) */
    targets: readonly number[];
}
export interface TimelineProps {
    rows: readonly TimelineRow[];
    items: readonly TimelineItem[];
    points: readonly TimelinePoint[];
    playhead: number;
    /** total length shown by the ruler (s) */
    duration: number;
    view: TimelineView;
    /** ad-hoc range (ruler handles), or null */
    range?: {
        from: number;
        to: number;
    } | null;
    /** everything outside this window is dimmed and not editable */
    dimOutside?: {
        from: number;
        to: number;
    } | null;
    snap?: TimelineSnap;
    /** width of the label column, px (default 150) */
    labelWidth?: number;
    /** given: the label column's edge can be dragged; called with the new
     *  width while dragging (clamped 80–600 px) */
    onLabelWidthChange?: (px: number) => void;
    /** row height, px (default 22) */
    rowHeight?: number;
    /** time read-out format for the ruler / tooltips */
    format?: (t: number) => string;
    onViewChange: (view: TimelineView) => void;
    onSeek: (t: number) => void;
    /** items dragged by dt (s); dropHint when released near a link target */
    onItemsMove: (ids: readonly string[], dt: number, dropHint: DropHint | null, phase: 'drag' | 'end') => void;
    /** an item edge dragged to time t; shift = the alternative edit */
    onItemResize: (id: string, edge: 'start' | 'end', t: number, shift: boolean, phase: 'drag' | 'end') => void;
    onPointsMove: (ids: readonly string[], dt: number, phase: 'drag' | 'end') => void;
    onSelect: (sel: {
        items: string[];
        points: string[];
    }, additive: boolean) => void;
    onToggleRow?: (id: string) => void;
    onOpen: (target: {
        kind: 'item' | 'row';
        id: string;
    }) => void;
    onContextMenu: (target: {
        kind: 'item' | 'row' | 'point' | 'empty';
        id?: string;
        t: number;
    }, at: {
        x: number;
        y: number;
    }) => void;
    onRangeChange?: (range: {
        from: number;
        to: number;
    } | null) => void;
    className?: string;
}
