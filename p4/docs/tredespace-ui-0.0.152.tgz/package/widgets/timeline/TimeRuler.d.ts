import type { TimelineView } from './timelineTypes';
export interface TimeRulerProps {
    /** the visible window (as Timeline's `view`) */
    view: TimelineView;
    /** total length (s) — the ruler is dimmed past it */
    duration: number;
    /** playhead time (s), the red marker */
    playhead: number;
    /** label format for major ticks (default "12.5s" / "1:05") */
    format?: (t: number) => string;
    /** ad-hoc in/out range, or null */
    range?: {
        from: number;
        to: number;
    } | null;
    /** click / drag = seek */
    onSeek: (t: number) => void;
    /** wheel: Ctrl = zoom about the pointer, otherwise pan; a scrub held at or
     *  past an edge pans too */
    onViewChange: (view: TimelineView) => void;
    /** Shift+drag reports an in/out range, a Shift+click clears it (null); without it Shift+drag just scrubs */
    onRangeChange?: (range: {
        from: number;
        to: number;
    } | null) => void;
    className?: string;
}
/** Default label: seconds below a minute, m:ss above. */
export declare function defaultTimeFormat(t: number): string;
/**
 * A time ruler: ticks and labels that adapt to the zoom, the playhead, an
 * optional in/out range. Scrub by dragging — held at or past an edge, the view
 * pans and the playhead rides along; wheel pans, Ctrl+wheel zooms.
 */
export declare function TimeRuler({ view, duration, playhead, format, range, onSeek, onViewChange, onRangeChange, className, }: TimeRulerProps): import("react").JSX.Element;
