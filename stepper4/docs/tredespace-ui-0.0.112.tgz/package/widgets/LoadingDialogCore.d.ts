export interface LoadingDialogCoreProps {
    title: string;
    label: string;
    /** 0..1 renders a determinate progress bar; null/undefined hides it. */
    progress?: number | null;
    z?: number;
}
/** Pure blocking loading overlay — props only, no store coupling. */
export declare function LoadingDialogCore({ title, label, progress, z }: LoadingDialogCoreProps): import("react").JSX.Element;
