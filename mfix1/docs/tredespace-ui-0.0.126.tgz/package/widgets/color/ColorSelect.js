import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import { createPortal } from 'react-dom';
import { cn } from '../../lib/cn';
import { Labelled } from '../fieldChrome';
import { ColorSelectPopover } from './ColorSelectPopover';
import { hexToRgb, hsvToRgb, isHex, rgbToHex, rgbToHsv } from './colorConversions';
import { getSwatches, subscribeSwatches } from './colorSelectSwatches';
import { useColorPopover } from './useColorPopover';
export { DEFAULT_PICKER_SWATCHES, setColorSelectSwatchesStore, } from './colorSelectSwatches';
/**
 * The one colour picker: saturation/value area + hue bar, with hex and RGB
 * entry, quick swatches, popover portaled to body. HSV lives locally while
 * open so hue survives passing through black/white/grey.
 */
export function ColorSelect({ value, onChange, swatches, tooltip, shortcut, disabled = false, className = '', flush = false, ...labelled }) {
    // default swatch grid comes from the injected store, if any (in this app:
    // user-editable via Settings → Editor)
    const storeSwatches = useSyncExternalStore(subscribeSwatches, getSwatches);
    const quickSwatches = swatches ?? storeSwatches;
    const [open, setOpen] = useState(false);
    const [hsv, setHsv] = useState(() => rgbToHsv(hexToRgb(isHex(value) ? value : '#000000')));
    const rootRef = useRef(null);
    const popRef = useRef(null);
    const svRef = useRef(null);
    const hueRef = useRef(null);
    const pos = useColorPopover(open, setOpen, rootRef, popRef);
    const rgb = hsvToRgb(hsv);
    const hex = rgbToHex(rgb);
    // Adopt outside changes (swatches elsewhere, store resets) without losing hue.
    useEffect(() => {
        if (isHex(value) && value.toLowerCase() !== hex.toLowerCase()) {
            const next = rgbToHsv(hexToRgb(value));
            setHsv((cur) => (next.s === 0 ? { ...next, h: cur.h } : next));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [value, hex.toLowerCase]);
    const apply = (next) => {
        setHsv(next);
        onChange(rgbToHex(hsvToRgb(next)));
    };
    return (_jsx(Labelled, { ...labelled, disabled: disabled, className: className, children: _jsxs("div", { ref: rootRef, className: cn('relative text-xs', flush && 'h-full'), children: [_jsxs("button", { type: "button", disabled: disabled, "aria-haspopup": "dialog", "aria-expanded": open, "data-tooltip": tooltip, "data-shortcut": shortcut, className: cn('flex h-full w-full cursor-pointer items-center gap-2 border px-2 py-0 text-left text-slate-200', !flush && 'min-h-6', open ? 'border-blue-400 bg-slate-900' : 'border-slate-700 bg-slate-900 hover:border-slate-600', disabled && 'cursor-not-allowed opacity-50'), onClick: () => setOpen((o) => !o), children: [_jsx("span", { className: "h-3.5 w-6 shrink-0 border border-black/40", style: { background: value } }), _jsx("span", { className: "flex-1 truncate font-mono", children: value }), _jsx("svg", { viewBox: "0 0 8 8", className: cn('h-2 w-2 shrink-0 fill-slate-500 transition-transform', open && 'rotate-180'), children: _jsx("path", { d: "M0 2l4 4 4-4z" }) })] }), open &&
                    createPortal(_jsx(ColorSelectPopover, { hsv: hsv, rgb: rgb, hex: hex, apply: apply, quickSwatches: quickSwatches, pos: pos, popRef: popRef, svRef: svRef, hueRef: hueRef }), document.body)] }) }));
}
