import { type RefObject } from 'react';
/** The live content width of an element (ResizeObserver). */
export declare function useElementWidth(ref: RefObject<HTMLElement | null>): number;
