import { type KeyboardEvent as ReactKeyboardEvent } from 'react';
import { type LabelledProps } from '../fieldChrome';
export interface TextInputProps extends LabelledProps {
    value: string;
    onChange: (value: string) => void;
    /** Fires on Enter and blur — for commit-style handling on top of onChange. */
    onCommit?: (value: string) => void;
    /** Runs before the field's own Enter handling — for Escape, arrows, Tab. */
    onKeyDown?: (e: ReactKeyboardEvent<HTMLInputElement>) => void;
    placeholder?: string;
    type?: 'text' | 'password' | 'email' | 'url' | 'search';
    maxLength?: number;
    spellCheck?: boolean;
    /** Take focus on mount — for the single field of a dialog. */
    autoFocus?: boolean;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    /** Show the in-field clear (✕) button (default true). */
    clearable?: boolean;
    /** What ✕ does. Default clears the content; provide this to override (e.g.
     *  reset-to-default). When given, the button shows even when empty. */
    onClear?: () => void;
}
/** Single-line text field in the studio look, label on top or to the left. */
export declare function TextInput({ value, onChange, onCommit, onKeyDown, placeholder, type, maxLength, spellCheck, autoFocus, tooltip, shortcut, clearable, onClear, disabled, ...labelled }: TextInputProps): import("react").JSX.Element;
