import { type ReactNode } from 'react';
import { type ButtonSize, type ButtonVariant } from '../buttonStyles';
import { type MenuEntry } from '../menu/Menu';
export interface SplitButtonProps {
    /** The main action's label (an icon may be passed as part of it). */
    label: ReactNode;
    /** Optional leading icon of the main part (locked to 14×14; 20×20 at size lg). */
    icon?: ReactNode;
    /** The main action. */
    onClick: () => void;
    /** The dropdown's entries — the same shape as {@link Menu}. */
    menu: readonly MenuEntry[];
    /** Styled tooltip of the main part. */
    tooltip?: string;
    /** Hotkey id of the main action (tooltip combo footer). */
    shortcut?: string;
    /** Tooltip of the chevron (default "More options"). */
    menuTooltip?: string;
    /** Emphasis of both halves, as on {@link Button} (default 'default'). */
    variant?: ButtonVariant;
    /** Height/padding scale of both halves, as on {@link Button} (default 'md'). */
    size?: ButtonSize;
    /** Highlighted look on the main part (a state, like {@link Button}). */
    active?: boolean;
    /** Disables both halves. */
    disabled?: boolean;
    /** Take the free space of a flex row. */
    grow?: boolean;
    className?: string;
}
/**
 * A button with a default action and a chevron that opens a short menu of
 * alternatives (Play | ▾ Return / Keep my view / Back to my pause view). The
 * two halves share their edge like a SegmentedControl, so they read as one
 * control; the menu opens under the chevron.
 */
export declare function SplitButton({ label, icon, onClick, menu, tooltip, shortcut, menuTooltip, variant, size, active, disabled, grow, className, }: SplitButtonProps): import("react").JSX.Element;
