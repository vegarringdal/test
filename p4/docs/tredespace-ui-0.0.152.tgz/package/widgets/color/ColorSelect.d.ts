import { type LabelledProps } from '../fieldChrome';
export { type ColorSelectSwatchesStore, DEFAULT_PICKER_SWATCHES, setColorSelectSwatchesStore, } from './colorSelectSwatches';
export interface ColorSelectProps extends LabelledProps {
    /** The colour as #rrggbb. Any other CSS colour still paints the swatch, but the picker opens at black. */
    value: string;
    /** Receives the picked colour as lowercase #rrggbb. */
    onChange: (color: string) => void;
    /** Quick-pick swatches (8 per row) at the bottom of the popover — replaces the default / store grid. */
    swatches?: string[];
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    /** Fill the parent height exactly (ribbon slots) instead of the h-6 floor. */
    flush?: boolean;
    /** Swatch only, no hex text — a small trigger for toolbars (put the colour
     *  in the tooltip if it matters). */
    compact?: boolean;
}
/**
 * The one colour picker: saturation/value area + hue bar, with hex and RGB
 * entry, quick swatches, popover portaled to body. HSV lives locally while
 * open so hue survives passing through black/white/grey.
 */
export declare function ColorSelect({ value, onChange, swatches, tooltip, shortcut, disabled, className, flush, compact, ...labelled }: ColorSelectProps): import("react").JSX.Element;
