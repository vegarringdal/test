import { type ReactNode } from 'react';
export type BoxSides = [number, number, number, number];
export interface BoxSidesInputProps {
    /** top, right, bottom, left (CSS order) */
    value: BoxSides;
    onChange: (value: BoxSides) => void;
    label?: ReactNode;
    labelWidth?: number;
    min?: number;
    max?: number;
    step?: number;
    unit?: string;
    disabled?: boolean;
    className?: string;
}
/** Four sides of a box (padding, margin): linked = one value for all, or
 *  each side on its own. */
export declare function BoxSidesInput({ value, onChange, label, labelWidth, min, max, step, unit, disabled, className, }: BoxSidesInputProps): import("react").JSX.Element;
