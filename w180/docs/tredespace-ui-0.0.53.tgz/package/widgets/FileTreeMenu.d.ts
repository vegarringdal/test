export type FileTreeMenuState = {
    x: number;
    y: number;
    dirPath: string | null;
};
/** Right-click folder menu, body-portaled so tree scroll clipping can't cut
 *  it off. */
export declare function FileTreeMenu({ menu, onClose, onAddFolder, onRenameFolder, onDeleteFolder, }: {
    menu: FileTreeMenuState;
    onClose: () => void;
    onAddFolder: (parentDirPath: string | null) => void;
    onRenameFolder?: (dirPath: string) => void;
    onDeleteFolder?: (dirPath: string) => void;
}): import("react").ReactPortal;
