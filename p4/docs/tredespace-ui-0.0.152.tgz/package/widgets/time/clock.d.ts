/** "m:ss.s" → seconds. Accepts "75", "1:15", "1:15.5"; anything else is null. */
export declare function parseClock(text: string): number | null;
/** Seconds → "m:ss.s" (negatives clamp to 0). */
export declare function formatClock(seconds: number): string;
/**
 * The seconds a typed clock commits, or null for none: text that does not
 * parse, or the text the field already shows for `value` — focus passing
 * through (Tab, a click elsewhere) must not round the value to the clock's
 * 0.1 s.
 */
export declare function clockCommit(text: string, value: number): number | null;
