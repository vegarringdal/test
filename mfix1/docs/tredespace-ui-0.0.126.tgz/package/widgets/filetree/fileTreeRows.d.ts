import type { ReactNode } from 'react';
import type { TreeViewRow } from '../tree/TreeView';
import { type TreeRow } from './fileTreeModel';
/** Map the file model's visible rows onto the generic tree's row shape. The
 *  tree owns indent, twisty and highlighting; this decides what a file row
 *  looks like (icon, note, folder count) and when a folder counts as selected
 *  — when every file under it is. */
export declare function toTreeRows(rows: readonly TreeRow[], selected: ReadonlySet<string>, collapsed: ReadonlySet<string>, expandAll: boolean, fileIcon: ReactNode): TreeViewRow[];
