import { type LabelledProps } from '../fieldChrome';
export interface TextAreaProps extends LabelledProps {
    /** The text. */
    value: string;
    /** Receives the text on every keystroke. */
    onChange: (value: string) => void;
    /** Fires on blur — for commit-style handling on top of onChange. */
    onCommit?: (value: string) => void;
    /** Dimmed text while empty. */
    placeholder?: string;
    /** Visible rows (default 3). */
    rows?: number;
    /** Character limit (native maxLength). */
    maxLength?: number;
    /** Browser spell-check (default false). */
    spellCheck?: boolean;
    /** Native read-only: the text scrolls, selects and copies but cannot be
     *  typed in. The ✕ clear still works (through onChange / onClear) — add
     *  `clearable={false}` for a field that cannot change at all. */
    readOnly?: boolean;
    /** Allow the user to resize vertically (default true). */
    resizable?: boolean;
    /** Lower bound for the field height in px — also the floor while resizing. */
    minHeight?: number;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    /** Show the in-field clear (✕) button (default true). */
    clearable?: boolean;
    /** What ✕ does. Default clears the content; provide this to override. */
    onClear?: () => void;
}
/** Multi-line text field in the studio look; label on top, to the left, or split (see LabelledProps). */
export declare function TextArea({ value, onChange, onCommit, placeholder, rows, maxLength, spellCheck, readOnly, resizable, minHeight, tooltip, shortcut, clearable, onClear, disabled, ...labelled }: TextAreaProps): import("react").JSX.Element;
