import { type ReactNode } from 'react';
export interface TemplateTextInputProps {
    /** text with {{placeholders}} */
    value: string;
    /** Receives the text on every edit and after an insert from the {} menu. */
    onChange: (value: string) => void;
    /** placeholders offered by the {} menu and highlighted when known */
    placeholders: readonly {
        key: string;
        label: string;
    }[];
    /** a textarea instead of one line */
    multiline?: boolean;
    /** Caption above the field. */
    label?: ReactNode;
    /** Dimmed text while empty. */
    placeholder?: string;
    /** Grey out the field and its {} button. */
    disabled?: boolean;
    /** Extra classes on the outermost element (the labelled block). */
    className?: string;
}
/**
 * A text field for templates: {{key}} placeholders are highlighted (known
 * ones blue, unknown ones red) under a transparent editor, and the {} button
 * inserts one at the caret (replacing any selection).
 */
export declare function TemplateTextInput({ value, onChange, placeholders, multiline, label, placeholder, disabled, className, }: TemplateTextInputProps): import("react").JSX.Element;
