import type { ReactNode } from 'react';
export interface PropertyRow {
    /** Stable identity of the row. */
    key: string;
    label: ReactNode;
    value: ReactNode;
    /** Styled tooltip on the label cell — for a truncated or renamed key. */
    tooltip?: string;
    /** Cell before the label (a checkbox, a swatch). */
    leading?: ReactNode;
}
export interface PropertyListProps {
    rows: readonly PropertyRow[];
    /**
     * `fixed` (default) gives the label a fixed column and lets the value fill —
     * a record's fields; `fill` lets the LABEL fill and keeps the value at its
     * natural width — a description with a key cap after it.
     */
    layout?: 'fixed' | 'fill';
    /** Label column width in px when `layout` is 'fixed'. */
    labelWidth?: number;
    /** Monospace, right-aligned values — for numeric read-outs. */
    numeric?: boolean;
    /** Rule under every row (a scrolling field list). */
    divided?: boolean;
    className?: string;
}
/** A label/value read-out: the field list of a record, a stats block, a table
 *  of fixed controls. Rows are data, so the caller keeps its own components
 *  (a Kbd, a Badge, a link) in `value`. */
export declare function PropertyList({ rows, layout, labelWidth, numeric, divided, className, }: PropertyListProps): import("react").JSX.Element;
