export interface CalendarGridProps {
    /** Displayed month. */
    view: {
        y: number;
        m: number;
    };
    /** Selected day (ISO) — rendered highlighted when visible. */
    selected: string | null;
    /** Range mode: paint the endpoints and the span between them (start set,
     *  end open → hovering previews the span); `selected` is ignored. */
    range?: Readonly<{
        start: string | null;
        end: string | null;
    }>;
    /** Earliest / latest pickable day (ISO, inclusive). */
    min?: string;
    max?: string;
    onPickDay: (iso: string) => void;
    onViewChange: (view: {
        y: number;
        m: number;
    }) => void;
}
/** Monday-first month grid with an ISO week-number column, plus a month/year
 *  quick-jump panel behind the header label. */
export declare function CalendarGrid({ view, selected, range, min, max, onPickDay, onViewChange }: CalendarGridProps): import("react").JSX.Element;
