import type { ReactNode } from 'react';
import type { ChapterListRow } from './ChapterList';
type Props = Readonly<{
    row: ChapterListRow;
    /** 1-based number among rows of the same depth */
    number: number;
    expanded: boolean;
    actions: ReactNode;
    detail: ReactNode;
    onActivate: (id: string) => void;
    drag?: {
        start: () => void;
        drop: () => void;
    };
}>;
/** One chapter: number/check, title, duration, hover actions, and — when
 *  expanded — the subtitle, progress and detail underneath. */
export declare function ChapterRow({ row, number, expanded, actions, detail, onActivate, drag }: Props): import("react").JSX.Element;
export {};
