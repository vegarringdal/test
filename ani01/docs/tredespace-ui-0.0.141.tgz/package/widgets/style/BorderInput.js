import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Checkbox } from '../Checkbox';
import { ColorSelect } from '../color/ColorSelect';
import { NumberInput } from '../number/NumberInput';
import { SegmentedControl } from '../SegmentedControl';
const STYLES = [
    { value: 'solid', label: 'Solid' },
    { value: 'dashed', label: 'Dashed' },
];
const DEFAULT = { width: 1, color: '#94a3b8', style: 'solid' };
/** A border: on/off, width, colour, solid or dashed. */
export function BorderInput({ value, onChange, label = 'Border', disabled = false, className = '' }) {
    const isToken = value?.color.startsWith('$');
    return (_jsxs("div", { className: className, children: [_jsx(Checkbox, { label: label, checked: value !== null, disabled: disabled, onChange: (on) => onChange(on ? DEFAULT : null) }), value && (_jsxs("div", { className: "mt-1 grid grid-cols-[1fr_auto] items-center gap-1", children: [_jsx(NumberInput, { value: value.width, min: 0, max: 40, step: 1, unit: "px", disabled: disabled, tooltip: "Border width", onChange: (width) => onChange({ ...value, width }) }), _jsx(SegmentedControl, { size: "sm", value: value.style, options: STYLES, disabled: disabled, onChange: (style) => onChange({ ...value, style }) }), isToken ? (_jsx("span", { className: "text-[11px] text-slate-400", "data-tooltip": "A theme colour \u2014 change it in the theme", children: value.color })) : (_jsx(ColorSelect, { value: value.color, disabled: disabled, tooltip: "Border colour", onChange: (color) => onChange({ ...value, color }) }))] }))] }));
}
