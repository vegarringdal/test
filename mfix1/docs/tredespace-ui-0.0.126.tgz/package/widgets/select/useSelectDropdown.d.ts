import { type RefObject } from 'react';
import { type PopoverPos } from '../usePopoverAnchor';
import type { SelectOption } from './Select';
export type SelectDropdown<T extends string = string> = Readonly<{
    open: boolean;
    setOpen: (o: boolean | ((o: boolean) => boolean)) => void;
    query: string;
    setQuery: (q: string) => void;
    hot: number;
    setHot: (h: number | ((h: number) => number)) => void;
    filtered: readonly SelectOption<T>[];
    asyncState: {
        options: SelectOption<T>[];
        loading: boolean;
        error: string | null;
    };
    pos: PopoverPos;
    rootRef: RefObject<HTMLDivElement | null>;
    popRef: RefObject<HTMLDivElement | null>;
    searchRef: RefObject<HTMLInputElement | null>;
    listRef: RefObject<HTMLDivElement | null>;
    known: (v: T) => SelectOption<T>;
}>;
/** Open/filter/anchor state for the Select popover: debounced async search,
 *  local filtering, outside-close, and viewport-anchored placement (the
 *  anchoring itself lives in the shared usePopoverAnchor). */
export declare function useSelectDropdown<T extends string = string>(options: readonly SelectOption<T>[], loadOptions: ((query: string) => Promise<SelectOption<T>[]>) | undefined, searchable: boolean, selected: ReadonlySet<string>): SelectDropdown<T>;
