import type { KeyboardEvent as ReactKeyboardEvent } from 'react';
import type { SelectOption } from './Select';
import type { SelectDropdown } from './useSelectDropdown';
/** The portaled listbox: optional search box, async states, option rows. */
export declare function SelectList({ dd, multiple, searchable, hasAsync, selected, pick, onKeyDown, }: {
    dd: SelectDropdown;
    multiple: boolean;
    searchable: boolean;
    hasAsync: boolean;
    selected: ReadonlySet<string>;
    pick: (opt: SelectOption) => void;
    onKeyDown: (e: ReactKeyboardEvent) => void;
}): import("react").JSX.Element;
