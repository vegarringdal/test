export interface TreeFile {
    kind: 'file';
    name: string;
    path: string;
    /** Present for scanned directories; virtual trees carry ids instead. */
    handle?: FileSystemFileHandle;
    /** Optional dim suffix (file size etc). */
    note?: string;
}
export interface TreeDir {
    kind: 'dir';
    name: string;
    path: string;
    children: TreeNode[];
}
export type TreeNode = TreeFile | TreeDir;
export interface TreeRow {
    node: TreeNode;
    depth: number;
}
/** All files in a subtree, depth-first. */
export declare function filesUnder(node: TreeNode): TreeFile[];
/** Flatten the visible rows (children of `root`, skipping collapsed dirs). */
export declare function visibleRows(root: TreeDir, collapsed: ReadonlySet<string>): TreeRow[];
