import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconLoader2 } from '@tabler/icons-react';
import { DialogFrame } from './DialogFrame';
import { ProgressBar } from './Spinner';
/** Pure blocking loading overlay — props only, no store coupling. It has no
 *  close path on purpose: the work owns the dialog's lifetime. */
export function LoadingDialogCore({ title, label, progress, z = 2020 }) {
    return (_jsxs(DialogFrame, { z: z, width: 256, icon: _jsx(IconLoader2, { size: 16, className: "shrink-0 animate-spin text-blue-400" }), title: title, bodyClassName: "flex min-h-0 flex-1 flex-col gap-2 overflow-y-auto px-3 py-5", children: [_jsx("span", { className: "whitespace-pre-line text-xs", children: label }), progress != null && _jsx(ProgressBar, { value: progress })] }));
}
