import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconLink, IconLinkOff } from '@tabler/icons-react';
import { useState } from 'react';
import { Button } from '../Button';
import { NumberInput } from '../number/NumberInput';
const SIDES = ['Top', 'Right', 'Bottom', 'Left'];
/** Four sides of a box (padding, margin): linked = one value for all, or
 *  each side on its own. */
export function BoxSidesInput({ value, onChange, label, labelWidth = 48, min = 0, max = 400, step = 1, unit = 'px', disabled = false, className = '', }) {
    const [linked, setLinked] = useState(value.every((v) => v === value[0]));
    return (_jsxs("div", { className: className, children: [_jsxs("div", { className: "flex items-center gap-1 text-[11px] text-slate-400", children: [label != null && (_jsx("span", { className: "truncate", style: { width: labelWidth }, children: label })), linked ? (_jsx(NumberInput, { className: "min-w-0 flex-1", value: value[0], min: min, max: max, step: step, unit: unit, disabled: disabled, tooltip: "All four sides", onChange: (v) => onChange([v, v, v, v]) })) : (_jsx("span", { className: "min-w-0 flex-1 text-slate-500", children: "per side" })), _jsx(Button, { iconOnly: true, size: "sm", variant: "ghost", icon: linked ? _jsx(IconLink, {}) : _jsx(IconLinkOff, {}), tooltip: linked ? 'Edit each side on its own' : 'One value for all sides', disabled: disabled, onClick: () => setLinked((l) => !l) })] }), !linked && (_jsx("div", { className: "mt-1 grid grid-cols-2 gap-1", children: SIDES.map((s, i) => (_jsx(NumberInput, { label: s[0], labelPosition: "left", labelWidth: 14, value: value[i], min: min, max: max, step: step, unit: unit, disabled: disabled, tooltip: s, onChange: (v) => onChange([
                        i === 0 ? v : value[0],
                        i === 1 ? v : value[1],
                        i === 2 ? v : value[2],
                        i === 3 ? v : value[3],
                    ]) }, s))) }))] }));
}
