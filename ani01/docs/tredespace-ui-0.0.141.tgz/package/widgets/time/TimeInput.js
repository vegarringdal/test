import { jsx as _jsx } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { NumberInput } from '../number/NumberInput';
import { TextInput } from '../text/TextInput';
/** "m:ss.s" ↔ seconds. Accepts "75", "1:15", "1:15.5". */
export function parseClock(text) {
    const t = text.trim();
    const m = /^(\d+):(\d{1,2}(?:\.\d*)?)$/.exec(t);
    if (m) {
        return Number(m[1]) * 60 + Number(m[2]);
    }
    const n = Number(t);
    return t !== '' && Number.isFinite(n) ? n : null;
}
export function formatClock(seconds) {
    const s = Math.max(0, seconds);
    const m = Math.floor(s / 60);
    const rest = s - m * 60;
    return `${m}:${rest < 10 ? '0' : ''}${rest.toFixed(1)}`;
}
/**
 * A time field: seconds or frames on a stepper (wheel / drag / type), or a
 * typed m:ss.s clock. The value is always seconds, clamped to [min, max].
 */
export function TimeInput({ value, onChange, min = 0, max, format = 'seconds', fps = 30, step = 0.1, tooltip, shortcut, ...labelled }) {
    const [text, setText] = useState(formatClock(value));
    useEffect(() => setText(formatClock(value)), [value]);
    const clamp = (v) => Math.min(max ?? Infinity, Math.max(min, v));
    if (format === 'frames') {
        return (_jsx(NumberInput, { ...labelled, value: Math.round(value * fps), step: 1, min: Math.round(min * fps), max: max !== undefined ? Math.round(max * fps) : undefined, unit: "f", tooltip: tooltip, shortcut: shortcut, onChange: (f) => onChange(clamp(f / fps)) }));
    }
    if (format === 'mmss') {
        const commit = (t) => {
            const v = parseClock(t);
            if (v === null) {
                setText(formatClock(value));
                return;
            }
            onChange(clamp(v));
        };
        return (_jsx(TextInput, { ...labelled, value: text, clearable: false, tooltip: tooltip, shortcut: shortcut, onChange: setText, onCommit: commit }));
    }
    return (_jsx(NumberInput, { ...labelled, value: value, step: step, min: min, max: max, unit: "s", tooltip: tooltip, shortcut: shortcut, onChange: (v) => onChange(clamp(v)) }));
}
