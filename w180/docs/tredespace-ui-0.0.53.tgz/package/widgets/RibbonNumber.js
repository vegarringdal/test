import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { NumberInput } from './NumberInput';
import { RibbonSlot } from './RibbonSlot';
/** A NumberInput in a ribbon slot — onChange fires on step, wheel, drag, and commit (Enter/blur). */
export function RibbonNumber({ label, labelWidth = 34, fieldWidth = 116, size = 'medium', className = '', ...input }) {
    return (_jsx(RibbonSlot, { size: size, className: className, children: _jsxs("div", { className: "grid h-full w-full items-center gap-x-1.5", style: { gridTemplateColumns: label != null ? `${labelWidth}px ${fieldWidth}px` : `${fieldWidth}px` }, children: [label != null && _jsx("span", { className: "truncate text-slate-400 text-xs leading-4", children: label }), _jsx(NumberInput, { ...input, className: `w-full min-w-0 ${size === 'mini' ? 'h-full' : ''}` })] }) }));
}
