import type { SelectOption } from './Select';
/** Multi-select trigger summary: one chip per selected option with remove ×. */
export declare function SelectChips({ values, known, onRemove, }: {
    values: string[];
    known: (v: string) => SelectOption;
    onRemove: (v: string) => void;
}): import("react").JSX.Element;
