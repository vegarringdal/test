import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { cn } from '../lib/cn';
/**
 * A collapsible section for stacking inside panels — the inline cousin of a
 * dock panel. The body animates shut via the grid-rows trick, so no measuring.
 */
export function InlinePanel({ title, defaultOpen = true, open, onToggle, actions, titleUppercase = true, titleClassName, children, className = '', }) {
    const [own, setOwn] = useState(defaultOpen);
    const isOpen = open ?? own;
    const toggle = () => {
        onToggle?.(!isOpen);
        if (open == null) {
            setOwn(!isOpen);
        }
    };
    return (_jsxs("section", { className: `overflow-hidden border border-slate-800 bg-slate-900 ${className}`, children: [_jsxs("header", { className: "flex select-none items-center gap-1.5 bg-slate-800/60 px-2 py-1.5", children: [_jsxs("button", { type: "button", className: "flex min-w-0 flex-1 cursor-pointer items-center gap-1.5 border-0 bg-transparent p-0 text-left font-semibold text-slate-200", "aria-expanded": isOpen, onClick: toggle, children: [_jsx("svg", { viewBox: "0 0 8 8", className: `h-2 w-2 shrink-0 fill-slate-500 transition-transform ${isOpen ? 'rotate-90' : ''}`, children: _jsx("path", { d: "M2 0l4 4-4 4z" }) }), _jsx("span", { className: cn('truncate font-medium text-xs leading-4 tracking-wide', titleUppercase && 'uppercase', titleClassName), children: title })] }), actions && _jsx("span", { className: "flex shrink-0 items-center gap-1", children: actions })] }), _jsx("div", { className: `grid transition-[grid-template-rows] duration-200 ${isOpen ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]'}`, children: _jsx("div", { className: "min-h-0 overflow-hidden", children: _jsx("div", { className: "px-2.5 py-2", children: children }) }) })] }));
}
