import { jsx as _jsx } from "react/jsx-runtime";
import { IconFolder } from '@tabler/icons-react';
import { filesUnder } from './fileTreeModel';
/** Map the file model's visible rows onto the generic tree's row shape. The
 *  tree owns indent, twisty and highlighting; this decides what a file row
 *  looks like (icon, note, folder count) and when a folder counts as selected
 *  — when every file under it is. */
export function toTreeRows(rows, selected, collapsed, expandAll, fileIcon) {
    return rows.map((r) => {
        const n = r.node;
        if (n.kind === 'file') {
            return {
                key: n.path || n.name,
                depth: r.depth,
                label: n.name,
                icon: _jsx("span", { className: "flex shrink-0", children: fileIcon }),
                selected: selected.has(n.path),
                trailing: n.note != null ? _jsx("span", { className: "text-[10px] text-slate-500", children: n.note }) : undefined,
            };
        }
        const files = filesUnder(n);
        return {
            key: n.path || n.name,
            depth: r.depth,
            label: n.name,
            icon: n.icon ?? _jsx(IconFolder, { size: 13, className: "shrink-0 text-slate-400" }),
            expandable: true,
            expanded: expandAll || !collapsed.has(n.path),
            selected: files.length > 0 && files.every((f) => selected.has(f.path)),
            band: n.variant === 'section',
            trailing: _jsx("span", { className: "text-[10px] text-slate-500", children: files.length }),
        };
    });
}
