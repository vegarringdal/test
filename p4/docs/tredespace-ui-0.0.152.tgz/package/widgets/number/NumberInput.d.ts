import { type LabelledProps } from '../fieldChrome';
export interface NumberInputProps extends LabelledProps {
    /** Current value; shown rounded to `precision`. */
    value: number;
    /** Receives every change, clamped to [min, max] and rounded to `precision`. */
    onChange: (value: number) => void;
    /** Lower bound (default: none). */
    min?: number;
    /** Upper bound (default: none). */
    max?: number;
    /** Increment of − / +, ↑ / ↓, a wheel notch and each 4 px of drag (default 1). */
    step?: number;
    /** Decimals shown/kept; derived from step when omitted. */
    precision?: number;
    /** Suffix rendered after the value, e.g. "px", "×" — hidden while typing. */
    unit?: string;
    /** Styled tooltip (data-tooltip) for the field as a whole. */
    tooltip?: string;
    /** Hotkey id (data-shortcut) for the field — the tooltip gets a combo footer. */
    shortcut?: string;
    /** Hotkey id for the − stepper (data-shortcut — its tooltip shows the combo). */
    decShortcut?: string;
    /** Hotkey id for the + stepper (data-shortcut — its tooltip shows the combo). */
    incShortcut?: string;
}
/**
 * A stepper in the studio look: − and + on either side, and a "rolling"
 * middle — scroll the wheel over it, or press and drag horizontally like a
 * Blender field. A plain click still focuses it for typing: Enter or blur
 * commits, Escape reverts, ↑ / ↓ step.
 */
export declare function NumberInput({ value, onChange, min, max, step, precision, unit, tooltip, shortcut, decShortcut, incShortcut, disabled, className, ...labelled }: NumberInputProps): import("react").JSX.Element;
