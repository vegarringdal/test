/** All files in a subtree, depth-first. */
export function filesUnder(node) {
    if (node.kind === 'file') {
        return [node];
    }
    return node.children.flatMap(filesUnder);
}
/** Flatten the visible rows (children of `root`, skipping collapsed dirs
 *  unless `expandAll` overrides — e.g. while a search filter is active). */
/** Every directory path under `root` (root itself excluded) — the set that
 *  "collapse all" stores. */
export function dirPaths(root) {
    const out = [];
    const walk = (n) => {
        if (n.kind !== 'dir') {
            return;
        }
        if (n !== root) {
            out.push(n.path);
        }
        for (const c of n.children) {
            walk(c);
        }
    };
    walk(root);
    return out;
}
export function visibleRows(root, collapsed, expandAll = false) {
    const out = [];
    const walk = (n, depth) => {
        out.push({ node: n, depth });
        if (n.kind === 'dir' && (expandAll || !collapsed.has(n.path))) {
            for (const c of n.children) {
                walk(c, depth + 1);
            }
        }
    };
    for (const c of root.children) {
        walk(c, 0);
    }
    return out;
}
