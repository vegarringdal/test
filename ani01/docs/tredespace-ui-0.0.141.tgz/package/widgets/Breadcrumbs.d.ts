export interface BreadcrumbsProps {
    /** Path from the root to the current place; the last one is current. */
    items: readonly {
        id: string;
        label: string;
    }[];
    /** A crumb was clicked (never fired for the current one). */
    onSelect: (id: string) => void;
    className?: string;
}
/** A clickable path — Assembly › Step 3 › Motor. The last crumb is where you
 *  are; the others go up. */
export declare function Breadcrumbs({ items, onSelect, className }: BreadcrumbsProps): import("react").JSX.Element;
