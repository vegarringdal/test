import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { cn } from '../../lib/cn';
import { timeToX } from './timelineMath';
const HATCH = 'repeating-linear-gradient(135deg, rgba(255,255,255,0.12) 0 4px, transparent 4px 8px)';
/** One lane: span bars / clip blocks with resize edges, and key points. */
export function TimelineLane({ row, items, points, view, height, hint, format, onItemDown, onEdgeDown, onPointDown, onItemOpen, onItemMenu, }) {
    return (_jsxs("div", { className: "relative min-w-0 flex-1 overflow-hidden", style: { height }, children: [items.map((it) => {
                const left = timeToX(it.start, view);
                const width = Math.max(3, (it.end - it.start) * view.pxPerSec);
                const tint = it.tint ?? row.tint ?? '#3b82f6';
                return (_jsx("div", { role: "button", tabIndex: -1, "aria-label": `${it.label}, ${format(it.start)} to ${format(it.end)}`, "data-tooltip": `${it.label}\n${format(it.start)} → ${format(it.end)}`, className: cn('absolute flex items-center overflow-hidden whitespace-nowrap text-[10px] text-slate-50', it.span ? 'top-0.5 h-1.5' : 'top-1 bottom-1 px-1', it.selected && 'outline outline-2 outline-sky-300', hint === it.id && 'outline outline-2 outline-amber-300', it.locked && 'cursor-default opacity-40', it.fixed && 'cursor-pointer', !it.locked && !it.fixed && 'cursor-grab'), style: { left, width, background: it.hatched ? `${HATCH}, ${tint}` : tint, opacity: it.span ? 0.8 : 0.9 }, onPointerDown: (e) => onItemDown(e, it), onDoubleClick: () => onItemOpen(it.id), onContextMenu: (e) => onItemMenu(e, 'item', it.id), children: !it.span && (_jsxs(_Fragment, { children: [it.linkFrom && _jsx("span", { className: "mr-0.5 text-amber-200", children: "\u21E2" }), it.icon, _jsx("span", { className: "truncate", children: it.label }), !it.locked && !it.fixed && (_jsxs(_Fragment, { children: [_jsx("span", { className: "absolute top-0 bottom-0 left-0 w-1.5 cursor-ew-resize", onPointerDown: (e) => onEdgeDown(e, it, 'start') }), _jsx("span", { className: "absolute top-0 right-0 bottom-0 w-1.5 cursor-ew-resize", onPointerDown: (e) => onEdgeDown(e, it, 'end') })] }))] })) }, it.id));
            }), points.map((p) => (_jsx("div", { role: "button", tabIndex: -1, "aria-label": `${p.label ?? 'Key'} at ${format(p.t)}`, "data-tooltip": `${p.label ?? 'Key'} · ${format(p.t)}`, className: cn('absolute top-1/2 cursor-grab', p.shape === 'diamond'
                    ? cn('h-2.5 w-2.5 rotate-45 border', p.selected ? 'border-sky-200 bg-sky-400' : 'border-slate-300 bg-slate-600')
                    : cn('h-0 w-0 border-x-[5px] border-x-transparent border-t-[9px]', p.selected ? 'border-t-sky-300' : 'border-t-amber-400')), style: { left: timeToX(p.t, view) - 5, marginTop: p.shape === 'diamond' ? -5 : -4 }, onPointerDown: (e) => onPointDown(e, p), onContextMenu: (e) => onItemMenu(e, 'point', p.id) }, p.id)))] }));
}
