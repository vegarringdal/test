import { jsx as _jsx } from "react/jsx-runtime";
import { cn } from '../../lib/cn';
import { SegmentedControl } from '../SegmentedControl';
const GLYPH = 14;
/** A tiny polyline of the curve, drawn in the segment's text colour. */
function CurveGlyph({ curve }) {
    const n = 12;
    const pts = Array.from({ length: n + 1 }, (_, i) => {
        const u = i / n;
        const v = Math.min(1, Math.max(0, curve(u)));
        return `${(1 + u * (GLYPH - 2)).toFixed(2)},${(GLYPH - 1 - v * (GLYPH - 2)).toFixed(2)}`;
    }).join(' ');
    return (_jsx("svg", { width: GLYPH, height: GLYPH, viewBox: `0 0 ${GLYPH} ${GLYPH}`, "aria-hidden": "true", children: _jsx("polyline", { points: pts, fill: "none", stroke: "currentColor", strokeWidth: 1.5, strokeLinejoin: "round" }) }));
}
/**
 * Pick an easing curve: a segmented row of curve glyphs (linear, ease in, …)
 * so the choice is visible, not just named. Generic over the value union —
 * the caller supplies the curves.
 */
export function EasingSelect({ value, options, onChange, showLabels = false, disabled = false, className = '', }) {
    return (_jsx(SegmentedControl, { className: cn(className), value: value, disabled: disabled, onChange: onChange, options: options.map((o) => ({
            value: o.value,
            icon: _jsx(CurveGlyph, { curve: o.curve }),
            label: showLabels ? o.label : undefined,
            tooltip: o.label,
            shortcut: o.shortcut,
        })) }));
}
