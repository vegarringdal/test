/** Height/padding scale. `md` (24px) lines up with the inputs. */
export type ButtonSize = 'xs' | 'sm' | 'md';
/** Emphasis. `primary` is the confirming action of a dialog or form, `danger`
 *  a destructive one, `ghost` a borderless action inside dense chrome. */
export type ButtonVariant = 'default' | 'primary' | 'danger' | 'ghost';
export declare const BUTTON_BASE = "inline-flex shrink-0 items-center justify-center gap-1.5 border text-xs leading-none transition-colors";
export declare const BUTTON_SIZE: Readonly<Record<ButtonSize, string>>;
export declare const BUTTON_ICON_SIZE: Readonly<Record<ButtonSize, string>>;
/** Height floor a wrapping button keeps once its label runs to two lines. */
export declare const BUTTON_MIN_H: Readonly<Record<ButtonSize, string>>;
export declare const BUTTON_VARIANT: Readonly<Record<ButtonVariant, string>>;
/** The `active` look wins over the variant — it is a state, not an emphasis. */
export declare const BUTTON_ACTIVE = "border-blue-400 bg-blue-950 text-blue-100 hover:border-blue-300";
