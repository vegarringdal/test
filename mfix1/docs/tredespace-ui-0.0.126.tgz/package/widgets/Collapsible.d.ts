import { type ReactNode } from 'react';
export interface CollapsibleProps {
    title: ReactNode;
    /** Optional right-aligned note in the header (count, badge…). */
    aside?: ReactNode;
    /** Explanation shown behind an info icon in the header — the compact
     *  replacement for an always-visible InfoBox inside the section. */
    info?: ReactNode;
    /** Header action buttons (icon-only Buttons, e.g. a section reset), placed
     *  between the aside and the info icon. They sit outside the toggle, so a
     *  click never collapses the section. */
    actions?: ReactNode;
    /** Uncontrolled initial state. */
    defaultOpen?: boolean;
    /** Controlled state — pair with onToggle (e.g. a search that must open every
     *  matching group). */
    open?: boolean;
    onToggle?: (open: boolean) => void;
    children: ReactNode;
    className?: string;
    /** Classes merged over the body's default `flex flex-col gap-2 p-2` — for a
     *  section whose content brings its own padding (a divided list). */
    bodyClassName?: string;
    /** Fill the remaining panel height while open; the BODY scrolls, not the panel. */
    fill?: boolean;
    /** Height floor for a `fill` section (Tailwind class, e.g. "min-h-64").
     *  Without it a filled section shrinks to nothing when several of them share
     *  a panel; with it the section stops shrinking and the PANEL scrolls. */
    fillMinClass?: string;
}
/** A titled section that collapses. Same header look as the Shortcuts panel
 *  groups; used to organise long settings tabs. */
export declare function Collapsible({ title, aside, info, actions, defaultOpen, open, onToggle, children, className, bodyClassName, fill, fillMinClass, }: CollapsibleProps): import("react").JSX.Element;
