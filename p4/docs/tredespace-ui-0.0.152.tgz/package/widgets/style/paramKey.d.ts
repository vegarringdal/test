/** `base` as a parameter key — anything but letters, digits and `_` becomes
 *  `_` (nothing left → "param") — numbered past the keys in `taken` it would
 *  clash with ("a b" next to "a_b" → "a_b2"). */
export declare function uniqueParamKey(base: string, taken: readonly string[]): string;
