import type { KeyboardEvent as ReactKeyboardEvent } from 'react';
import type { SelectOption } from './Select';
import type { SelectDropdown } from './useSelectDropdown';
/** The portaled listbox: optional search box, async states, option rows. */
export declare function SelectList<T extends string = string>({ dd, multiple, searchable, hasAsync, selected, pick, onKeyDown, }: {
    dd: SelectDropdown<T>;
    multiple: boolean;
    searchable: boolean;
    hasAsync: boolean;
    selected: ReadonlySet<string>;
    pick: (opt: SelectOption<T>) => void;
    onKeyDown: (e: ReactKeyboardEvent) => void;
}): import("react").JSX.Element;
