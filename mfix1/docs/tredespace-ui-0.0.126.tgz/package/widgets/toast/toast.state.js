import { createStore } from '../../lib/createStore';
export const toastState = createStore({ items: [] });
