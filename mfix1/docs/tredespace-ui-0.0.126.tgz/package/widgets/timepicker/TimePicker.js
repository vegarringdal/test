import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconClock } from '@tabler/icons-react';
import { useState } from 'react';
import { PickerField, PickerPopover } from '../PickerField';
import { usePopoverAnchor } from '../usePopoverAnchor';
import { ClockDial } from './clockFace';
import { TimeDigits } from './TimeDigits';
import { formatTime, nowTime, parseTime } from './timeMath';
const POP_WIDTH = 216;
const POP_HEIGHT = 252;
// -----------------------------------------------------------------------------
// helpers
// -----------------------------------------------------------------------------
/** Popover drafts from the current value; unset parts start at "now". */
function readDrafts(props) {
    const now = nowTime();
    if (props.range) {
        return { start: parseTime(props.value.start) ?? now, end: parseTime(props.value.end) ?? now };
    }
    return { start: parseTime(props.value) ?? now, end: now };
}
// -----------------------------------------------------------------------------
// render
// -----------------------------------------------------------------------------
/**
 * A compact 24-hour time field with an Android-style analog clock popover:
 * dual-ring hour dial (1–12 outer, 00/13–23 inner), auto-advancing to the
 * minute dial; range mode chains a second endpoint. Values cross the API as
 * `"HH:MM"` strings.
 */
export function TimePicker(props) {
    const { minuteStep = 1, placeholder = 'Pick a time…', disabled = false, className = '', tooltip, shortcut } = props;
    const anchor = usePopoverAnchor(POP_HEIGHT);
    const [stage, setStage] = useState({ endpoint: 'start', mode: 'hour' });
    const [drafts, setDrafts] = useState(() => readDrafts(props));
    const display = props.range
        ? props.value.start == null && props.value.end == null
            ? null
            : `${props.value.start ?? '…'} – ${props.value.end ?? '…'}`
        : props.value;
    const handleToggle = () => {
        if (!anchor.open) {
            setStage({ endpoint: 'start', mode: 'hour' });
            setDrafts(readDrafts(props));
        }
        anchor.setOpen((o) => !o);
    };
    const handleKeyDown = (e) => {
        if (!anchor.open && (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown')) {
            e.preventDefault();
            handleToggle();
        }
        else if (anchor.open && e.key === 'Escape') {
            e.preventDefault();
            anchor.setOpen(false);
        }
    };
    const handlePick = (mode, v) => {
        const cur = drafts[stage.endpoint];
        const next = { ...drafts, [stage.endpoint]: mode === 'hour' ? { ...cur, h: v } : { ...cur, m: v } };
        setDrafts(next);
        if (props.range) {
            props.onChange({
                start: stage.endpoint === 'start' ? formatTime(next.start) : props.value.start,
                end: stage.endpoint === 'end' ? formatTime(next.end) : props.value.end,
            });
        }
        else {
            props.onChange(formatTime(next.start));
        }
    };
    const handleCommit = () => {
        if (stage.mode === 'hour') {
            setStage({ ...stage, mode: 'minute' });
        }
        else if (props.range && stage.endpoint === 'start') {
            setStage({ endpoint: 'end', mode: 'hour' });
        }
        else {
            anchor.setOpen(false);
        }
    };
    return (_jsxs("div", { ref: anchor.rootRef, className: `relative text-xs ${className}`, onKeyDown: handleKeyDown, children: [_jsx(PickerField, { open: anchor.open, icon: _jsx(IconClock, { size: 14, className: "shrink-0 text-slate-400" }), value: display, placeholder: placeholder, clearLabel: "Clear time", disabled: disabled, tooltip: tooltip, shortcut: shortcut, onToggle: handleToggle, onClear: () => (props.range ? props.onChange({ start: null, end: null }) : props.onChange(null)) }), anchor.open && (_jsxs(PickerPopover, { anchor: anchor, width: POP_WIDTH, children: [_jsx(TimeDigits, { start: drafts.start, end: props.range ? drafts.end : null, stage: stage, onStage: setStage }), _jsx("div", { className: "p-2", children: _jsx(ClockDial, { mode: stage.mode, hour: drafts[stage.endpoint].h, minute: drafts[stage.endpoint].m, minuteStep: minuteStep, onPick: handlePick, onCommit: handleCommit }) })] }))] }));
}
