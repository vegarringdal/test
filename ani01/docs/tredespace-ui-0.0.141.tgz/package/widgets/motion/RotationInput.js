import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { NumberInput } from '../number/NumberInput';
import { Vec3Input } from '../Vec3Input';
const DEG = Math.PI / 180;
function axisAngle(axis, deg) {
    const l = Math.hypot(axis[0], axis[1], axis[2]) || 1;
    const s = Math.sin((deg * DEG) / 2) / l;
    return [axis[0] * s, axis[1] * s, axis[2] * s, Math.cos((deg * DEG) / 2)];
}
function mul(a, b) {
    return [
        a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1],
        a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0],
        a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3],
        a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2],
    ];
}
/** Quaternion ↔ XYZ Euler degrees (R = Rz·Ry·Rx). */
export function quatToEuler(q) {
    const l = Math.hypot(...q) || 1;
    const [x, y, z, w] = q.map((v) => v / l);
    const sinp = 2 * (w * y - z * x);
    const pitch = Math.abs(sinp) >= 1 ? (Math.sign(sinp) * Math.PI) / 2 : Math.asin(sinp);
    const round = (v) => Math.round((v / DEG) * 1000) / 1000;
    return [
        round(Math.atan2(2 * (w * x + y * z), 1 - 2 * (x * x + y * y))),
        round(pitch),
        round(Math.atan2(2 * (w * z + x * y), 1 - 2 * (y * y + z * z))),
    ];
}
export function eulerToQuat(e) {
    return mul(axisAngle([0, 0, 1], e[2]), mul(axisAngle([0, 1, 0], e[1]), axisAngle([1, 0, 0], e[0])));
}
/** Quaternion → unit axis + degrees (0..180; identity reads as +Z, 0°). */
export function quatToAxisAngle(q) {
    const l = Math.hypot(...q) || 1;
    const w = Math.min(1, Math.max(-1, q[3] / l));
    const s = Math.sqrt(1 - w * w);
    if (s < 1e-6) {
        return { axis: [0, 0, 1], degrees: 0 };
    }
    const sign = w < 0 ? -1 : 1;
    return {
        axis: [(sign * q[0]) / l / s, (sign * q[1]) / l / s, (sign * q[2]) / l / s],
        degrees: (2 * Math.acos(Math.abs(w))) / DEG,
    };
}
/**
 * A rotation editor over a quaternion value: three Euler-degree steppers, or
 * an axis + an angle. Storage stays a quaternion; the fields are a view.
 */
export function RotationInput({ value, onChange, mode = 'euler', label, labelWidth = 48, step = 5, disabled = false, className = '', }) {
    if (mode === 'axisAngle') {
        const aa = quatToAxisAngle(value);
        return (_jsxs("div", { className: className, children: [_jsx(Vec3Input, { label: label, labelWidth: labelWidth, value: aa.axis, step: 0.1, precision: 3, disabled: disabled, tooltips: ['Axis X', 'Axis Y', 'Axis Z'], onChange: (axis) => onChange(axisAngle(axis, aa.degrees)) }), _jsx(NumberInput, { className: "mt-1", label: "Angle", labelPosition: "left", labelWidth: labelWidth, value: aa.degrees, step: step, unit: "\u00B0", disabled: disabled, onChange: (deg) => onChange(axisAngle(aa.axis, deg)) })] }));
    }
    return (_jsx(Vec3Input, { className: className, label: label, labelWidth: labelWidth, value: quatToEuler(value), step: step, unit: "\u00B0", disabled: disabled, tooltips: ['Rotate about X (°)', 'Rotate about Y (°)', 'Rotate about Z (°)'], onChange: (e) => onChange(eulerToQuat(e)) }));
}
