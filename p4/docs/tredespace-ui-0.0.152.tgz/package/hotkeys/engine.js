// Framework-free hotkey engine. Zero app imports. See DESIGN.md for the
// full design. Display grammar over keys:
//   X         tap (press & release)
//   A+B       together (same instant — regular keys too, e.g. E+R); no spaces
//   A B / A,B then (release, press next) — space or comma, display uses space
//   [X]/[A+B] hold a key/group across the rest of the sequence
//   AA/101    runs expand to taps (A A, 1 0 1); F-keys & named keys stay whole
//   PLUS      the literal + key (COMMA: the comma key)
//
// A shortcut is a Sequence of Combos. A Combo is modifiers + a set of held
// keys, canonicalized (mods in fixed order, keys sorted) so E+R === R+E. The
// internal Combo string joins with "&" ("Alt&F1") — never shown, and what
// saved overrides store, so the display grammar can change without migration.
export const DEFAULT_TIMEOUT = 1500; // ms between sequence steps
/** A `trigger: 'tap'` key held longer than this is a hold, not a tap. */
export const DEFAULT_TAP_MAX_MS = 1000;
const MODS = {
    CTRL: 'Ctrl',
    CONTROL: 'Ctrl',
    ALT: 'Alt',
    SHIFT: 'Shift',
    META: 'Meta',
    CMD: 'Meta',
};
const NAMED = {
    ESC: 'Escape',
    ESCAPE: 'Escape',
    ENTER: 'Enter',
    SPACE: 'Space',
    TAB: 'Tab',
    UP: 'ArrowUp',
    DOWN: 'ArrowDown',
    LEFT: 'ArrowLeft',
    RIGHT: 'ArrowRight',
    PAGEUP: 'PageUp',
    PAGEDOWN: 'PageDown',
    HOME: 'Home',
    END: 'End',
    DELETE: 'Delete',
    BACKSPACE: 'Backspace',
    PLUS: 'Equal', // the physical +/= key
    COMMA: 'Comma',
};
const NAMED_CODE_TO_DISPLAY = {
    Escape: 'ESC',
    Enter: 'ENTER',
    Space: 'SPACE',
    Tab: 'TAB',
    ArrowUp: 'UP',
    ArrowDown: 'DOWN',
    ArrowLeft: 'LEFT',
    ArrowRight: 'RIGHT',
    PageUp: 'PAGEUP',
    PageDown: 'PAGEDOWN',
    Home: 'HOME',
    End: 'END',
    Delete: 'DELETE',
    Backspace: 'BACKSPACE',
    Equal: 'PLUS',
    Comma: 'COMMA',
};
const MOD_ORDER = ['Ctrl', 'Alt', 'Shift', 'Meta'];
const FKEY_RE = /^F([1-9]|1[0-2])$/;
// Modifiers that turn a key press into a command rather than typing (Shift
// still types — an uppercase letter).
const COMMAND_MODS = new Set(['Ctrl', 'Alt', 'Meta']);
export class HotkeyParseError extends Error {
}
function isBareModifier(code) {
    return code.startsWith('Control') || code.startsWith('Alt') || code.startsWith('Shift') || code.startsWith('Meta');
}
/** The canonical modifier name for a bare-modifier code (`AltLeft` → `Alt`). */
function modifierName(code) {
    if (code.startsWith('Control')) {
        return 'Ctrl';
    }
    if (code.startsWith('Alt')) {
        return 'Alt';
    }
    if (code.startsWith('Shift')) {
        return 'Shift';
    }
    if (code.startsWith('Meta')) {
        return 'Meta';
    }
    return null;
}
// While recording a shortcut, the live engine is suspended so the keys being
// captured don't also fire the actions they're bound to.
let suspendDepth = 0;
export function suspendHotkeys() {
    suspendDepth++;
}
export function resumeHotkeys() {
    suspendDepth = Math.max(0, suspendDepth - 1);
}
/** One display token -> { mod } or { key: code }. Throws on anything unknown. */
function classify(tok) {
    const up = tok.toUpperCase();
    if (MODS[up]) {
        return { mod: MODS[up] };
    }
    if (NAMED[up]) {
        return { key: NAMED[up] };
    }
    if (FKEY_RE.test(up)) {
        return { key: up }; // F1..F12
    }
    if (/^[0-9]$/.test(tok)) {
        return { key: `Digit${tok}` };
    }
    if (/^[A-Za-z]$/.test(tok)) {
        return { key: `Key${up}` };
    }
    throw new HotkeyParseError(`unknown key token "${tok}"`);
}
/** mods + keys -> canonical combo (mods fixed order, keys sorted). */
export function makeCombo(mods, keys) {
    const m = MOD_ORDER.filter((o) => mods.includes(o));
    const k = [...new Set(keys)].sort();
    return [...m, ...k].join('&');
}
/** Build the combo for the current keydown from the held-set (mods + keys). */
export function comboFromHeld(e, held) {
    if (isBareModifier(e.code)) {
        return null;
    }
    const mods = [];
    if (e.ctrlKey) {
        mods.push('Ctrl');
    }
    if (e.altKey) {
        mods.push('Alt');
    }
    if (e.shiftKey) {
        mods.push('Shift');
    }
    if (e.metaKey) {
        mods.push('Meta');
    }
    return makeCombo(mods, [...held, e.code]);
}
/** Prettify one combo: "Alt&F1" -> "ALT+F1", "Digit1" -> "1", "KeyZ" -> "Z".
 *  Display order: modifiers, then multi-char keys (F-keys/named — usually the
 *  held leader), then single chars — so "1&F1" reads "F1+1". */
export function formatCombo(c) {
    const disp = (p) => {
        if (p.startsWith('Digit')) {
            return p.slice(5);
        }
        if (p.startsWith('Key')) {
            return p.slice(3);
        }
        if (NAMED_CODE_TO_DISPLAY[p]) {
            return NAMED_CODE_TO_DISPLAY[p];
        }
        return p.toUpperCase(); // ALT, CTRL, SHIFT, F1…
    };
    const parts = c.split('&').map(disp);
    const mods = parts
        .filter((p) => MOD_DISPLAY.includes(p))
        .sort((a, b) => MOD_DISPLAY.indexOf(a) - MOD_DISPLAY.indexOf(b));
    const keys = parts
        .filter((p) => !MOD_DISPLAY.includes(p))
        .sort((a, b) => (b.length > 1 ? 1 : 0) - (a.length > 1 ? 1 : 0) || a.localeCompare(b));
    return [...mods, ...keys].join('+');
}
const MOD_DISPLAY = ['CTRL', 'ALT', 'SHIFT', 'META'];
/** Whole sequence for display. Steps join with a space; a run of bare lone
 *  digits is concatenated so ["Alt&F1","Digit1","Digit0","Digit1"] -> "ALT+F1 101". */
export function formatSequence(seq) {
    const out = [];
    let digits = '';
    const flush = () => {
        if (digits) {
            out.push(digits);
            digits = '';
        }
    };
    for (const c of seq) {
        const f = formatCombo(c);
        if (/^[0-9]$/.test(f)) {
            digits += f;
        }
        else {
            flush();
            out.push(f);
        }
    }
    flush();
    return out.join(' ');
}
/** Parse the display grammar into a Sequence. Steps are separated by
 *  whitespace or commas; "+" joins keys pressed together and must not be
 *  spaced ("CTRL + Z" is rejected — it reads like the old "then" notation).
 *  Brackets [X]/[A+B] mark held keys that persist into every following combo. */
export function parseSequence(str) {
    if (/\s\+|\+\s/.test(str)) {
        throw new HotkeyParseError(`spaces around "+" in "${str}" — write CTRL+Z; separate steps with a space`);
    }
    const seq = [];
    const heldMods = [];
    const heldKeys = [];
    for (const step of str.split(/[\s,]+/)) {
        if (!step) {
            continue;
        }
        // strip bracketed hold-groups: "[F1+ALT]" adds F1,ALT to the held set and
        // (on its own) emits no combo; anything left in the step is a tap step
        const holdMatches = [...step.matchAll(/\[([^\]]+)\]/g)];
        if (holdMatches.length > 0) {
            for (const m of holdMatches) {
                for (const t of m[1].split('+')) {
                    const c = classify(t);
                    if (c.mod) {
                        heldMods.push(c.mod);
                    }
                    else if (c.key) {
                        heldKeys.push(c.key);
                    }
                }
            }
            const rest = step.replace(/\[[^\]]+\]/g, '');
            if (rest) {
                parseTapStep(rest, seq, heldMods, heldKeys);
            }
            continue;
        }
        parseTapStep(step, seq, heldMods, heldKeys);
    }
    if (seq.length === 0) {
        throw new HotkeyParseError(`empty sequence "${str}"`);
    }
    return seq;
}
/** Parse one non-hold step (a combo or an expandable run) into `seq`,
 *  merging in any currently-held mods/keys. */
function parseTapStep(step, seq, heldMods, heldKeys) {
    if (step.includes('+')) {
        const mods = [...heldMods];
        const keys = [...heldKeys];
        for (const t of step.split('+')) {
            if (!t) {
                throw new HotkeyParseError(`empty key in "${step}" — the + key is written PLUS`);
            }
            const c = classify(t);
            if (c.mod) {
                mods.push(c.mod);
            }
            else if (c.key) {
                keys.push(c.key);
            }
        }
        // A modifiers-only chord (e.g. "ALT+SHIFT") is a valid leader step
        seq.push(makeCombo(mods, keys));
        return;
    }
    const up = step.toUpperCase();
    if (MODS[up]) {
        // bare modifier step ("ALT 101"): a modifiers-only leader combo — the
        // matcher emits these when the modifier is tapped and released alone
        seq.push(makeCombo([...heldMods, MODS[up]], heldKeys));
        return;
    }
    if (NAMED[up]) {
        seq.push(makeCombo(heldMods, [...heldKeys, NAMED[up]]));
        return;
    }
    if (FKEY_RE.test(up)) {
        seq.push(makeCombo(heldMods, [...heldKeys, up]));
        return;
    }
    if (/^[A-Za-z0-9]$/.test(step)) {
        seq.push(makeCombo(heldMods, [...heldKeys, classify(step).key]));
        return;
    }
    if (/^[A-Za-z0-9]{2,}$/.test(step)) {
        // run -> one tap per char (AA, FF, 101)
        for (const ch of step) {
            seq.push(makeCombo(heldMods, [...heldKeys, classify(ch).key]));
        }
        return;
    }
    throw new HotkeyParseError(`cannot parse step "${step}"`);
}
/** Does this string parse? (validation test + record guard.) */
export function isValidKeys(str) {
    try {
        parseSequence(str);
        return true;
    }
    catch {
        return false;
    }
}
function startsWith(seq, prefix) {
    return prefix.length <= seq.length && prefix.every((c, i) => seq[i] === c);
}
function isEditable(t) {
    const el = t;
    if (!el?.tagName) {
        return false;
    }
    return el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable;
}
/** Split a canonical combo into its modifier names and key codes. */
function comboParts(combo) {
    const parts = combo.split('&');
    return {
        mods: parts.filter((p) => MOD_ORDER.includes(p)),
        keys: parts.filter((p) => !MOD_ORDER.includes(p)),
    };
}
/** True when every step is F1–F12 (with any modifiers). Pressing such a
 *  sequence inside a text field types nothing, so the field has no claim on
 *  it — the registry uses this as the default for `allowInInput`. */
export function isFunctionKeySequence(seq) {
    return (seq.length > 0 &&
        seq.every((c) => {
            const { keys } = comboParts(c);
            return keys.length > 0 && keys.every((k) => FKEY_RE.test(k));
        }));
}
/** True when some step carries Ctrl, Alt or Meta, so the sequence cannot be
 *  ordinary typing. Bare letters and digits, Shift chords and the named
 *  editing keys (Tab, Escape, PageUp…) all mean something to a text field
 *  itself; a muted hit on those is the user typing, not a missed shortcut. */
export function hasCommandModifier(seq) {
    return seq.some((c) => comboParts(c).mods.some((m) => COMMAND_MODS.has(m)));
}
export class HotkeyEngine {
    registered = [];
    taps = [];
    tap = null;
    held = new Set(); // non-modifier codes currently down
    modCodes = new Set(); // bare-modifier codes currently down
    modChord = new Set(); // modifier NAMES seen during this hold (peak)
    pureModHold = true; // no non-modifier pressed since the modifiers went down
    progress = [];
    pending = null; // exact match awaiting a possible longer one
    pendingMuted = false; // the pending match was made inside a text field where it is muted
    timer = 0;
    onProgress = null;
    onMuted = null;
    running = false;
    setBindings(list) {
        // tap bindings never take part in sequence matching: they fire on key-up
        this.registered = list.filter((r) => r.trigger !== 'tap');
        this.taps = list.filter((r) => r.trigger === 'tap' && r.sequence.length === 1);
        this.tap = null;
        this.reset();
    }
    setProgressListener(fn) {
        this.onProgress = fn;
    }
    /** Hear about a shortcut the user completed inside a text field where it is
     *  muted (not `allowInInput`): the keys typed as usual and nothing ran. Only
     *  sequences with a command modifier ({@link hasCommandModifier}) are
     *  reported, so ordinary typing never triggers it. */
    setMutedListener(fn) {
        this.onMuted = fn;
    }
    start() {
        if (this.running) {
            return;
        }
        this.running = true;
        window.addEventListener('keydown', this.onKeyDown, true);
        window.addEventListener('keyup', this.onKeyUp, true);
        window.addEventListener('pointerdown', this.onPointerDown, true);
        window.addEventListener('wheel', this.onWheel, { capture: true, passive: true });
        window.addEventListener('blur', this.onBlur);
    }
    stop() {
        this.running = false;
        window.removeEventListener('keydown', this.onKeyDown, true);
        window.removeEventListener('keyup', this.onKeyUp, true);
        window.removeEventListener('pointerdown', this.onPointerDown, true);
        window.removeEventListener('wheel', this.onWheel, true);
        window.removeEventListener('blur', this.onBlur);
        this.reset();
        this.held.clear();
        this.tap = null;
    }
    /** A mouse press CONSUMES a pure modifier hold (alt+click camera pivot etc.)
     *  — releasing the modifier afterwards must not emit it as a leader step —
     *  and an armed tap (Space+click is fly-to, not play/pause). */
    onPointerDown = () => {
        this.pureModHold = false;
        if (this.tap) {
            this.tap.consumed = true;
        }
    };
    /** A wheel turn while a tap key is held makes it a hold gesture. */
    onWheel = () => {
        if (this.tap) {
            this.tap.consumed = true;
        }
    };
    /** Clear in-flight state WITHOUT firing a pending match (blur/stop/rebind). */
    reset() {
        this.progress = [];
        this.pending = null;
        this.pendingMuted = false;
        clearTimeout(this.timer);
        this.timer = 0;
        this.onProgress?.([]);
    }
    /** Timeout elapsed: a pending shorter match (a prefix of a longer binding,
     *  e.g. F when F+F also exists) now commits since no continuation arrived. */
    fireTimeout = () => {
        this.commitPending();
    };
    /** Commit the pending exact match (if any) and clear the in-flight state. */
    commitPending() {
        const p = this.pending;
        const muted = this.pendingMuted;
        this.reset();
        if (p) {
            this.fire(p, muted);
        }
    }
    /** Run a completed match — or, when it completed in shadow mode inside a
     *  text field, report it to the muted listener instead. */
    fire(r, muted) {
        if (!muted) {
            r.run();
            return;
        }
        if (hasCommandModifier(r.sequence)) {
            this.onMuted?.(r);
        }
    }
    arm(cand) {
        clearTimeout(this.timer);
        const ms = Math.min(...cand.map((r) => r.timeout ?? DEFAULT_TIMEOUT));
        this.timer = window.setTimeout(this.fireTimeout, Number.isFinite(ms) ? ms : DEFAULT_TIMEOUT);
    }
    onBlur = () => {
        this.tap = null;
        this.held.clear();
        this.modCodes.clear();
        this.modChord.clear();
        this.pureModHold = true;
        this.reset();
    };
    onKeyUp = (e) => {
        if (suspendDepth > 0) {
            return;
        }
        if (this.tap && e.code === this.tap.code) {
            this.releaseTap(e);
        }
        if (isBareModifier(e.code)) {
            this.modCodes.delete(e.code);
            // All modifiers released after a PURE modifier hold (no other key pressed)
            // → emit the modifier chord as a sequence step (a "Alt&Shift" leader).
            if (this.modCodes.size === 0) {
                if (this.pureModHold && this.held.size === 0 && this.modChord.size > 0) {
                    const combo = makeCombo([...this.modChord], []);
                    // only advance when the chord is actually part of some binding, so a
                    // stray Alt/Shift tap never disturbs an in-progress sequence
                    if (this.modChordUsable(combo)) {
                        this.feed(combo, e);
                    }
                }
                this.modChord.clear();
                this.pureModHold = true;
            }
            return;
        }
        this.held.delete(e.code);
    };
    onKeyDown = (e) => {
        if (suspendDepth > 0) {
            return; // recording a shortcut — stay out of the way
        }
        if (e.repeat) {
            return; // ignore auto-repeat
        }
        if (this.tap && e.code !== this.tap.code) {
            this.tap.consumed = true; // another key (W, Shift…) joined: not a tap
        }
        if (isBareModifier(e.code)) {
            if (this.modCodes.size === 0) {
                this.pureModHold = true;
            }
            this.modCodes.add(e.code);
            const name = modifierName(e.code);
            if (name) {
                this.modChord.add(name);
            }
            return; // modifiers alone don't advance until released (or a key joins)
        }
        // a real key joined — this hold is no longer a pure modifier chord
        this.pureModHold = false;
        const combo = comboFromHeld(e, this.held);
        if (combo === null) {
            return; // (shouldn't happen — not a bare modifier)
        }
        this.held.add(e.code);
        this.armTap(combo, e);
        this.feed(combo, e);
    };
    /** Arm a tap binding on its keydown. The keydown is NOT claimed: other
     *  listeners (the camera's held-Space for fly-to) still see it. */
    armTap(combo, e) {
        if (this.tap) {
            return;
        }
        const inInput = isEditable(e.target);
        const r = this.taps.find((t) => t.sequence[0] === combo && (t.context?.() ?? true) && (!inInput || t.allowInInput === true));
        if (r) {
            this.tap = { r, code: e.code, t0: performance.now(), consumed: false };
        }
    }
    /** Key-up of the armed tap key: fire when it stayed a clean, short tap,
     *  and claim the key-up so a focused button is not also activated. */
    releaseTap(e) {
        const t = this.tap;
        this.tap = null;
        if (!t || t.consumed || performance.now() - t.t0 > (t.r.tapMaxMs ?? DEFAULT_TAP_MAX_MS)) {
            return;
        }
        if (!(t.r.context?.() ?? true)) {
            return;
        }
        e.preventDefault();
        e.stopPropagation();
        t.r.run();
    }
    /** True if `combo` starts, or continues, some registered binding — used to
     *  gate modifier-chord emission so stray taps are ignored. */
    modChordUsable(combo) {
        const next = [...this.progress, combo];
        return this.registered.some((r) => startsWith(r.sequence, next) || startsWith(r.sequence, [combo]));
    }
    /** Advance the sequence with one committed combo (from a keydown or a released
     *  modifier chord): match, fire, or arm the pending timeout.
     *
     *  Inside a text field, bindings that are not `allowInInput` still take part
     *  in the matching — as a *shadow*: the key is never claimed (it types as
     *  usual) and a completed sequence goes to the muted listener instead of
     *  running, so the host can tell the user why nothing happened. When any
     *  candidate is live in the field, the step is handled exactly as outside
     *  one and the muted candidates drop out. */
    feed(combo, e) {
        const inInput = isEditable(e.target);
        const active = (r) => r.context?.() ?? true;
        const isLive = (r) => !inInput || r.allowInInput === true;
        let next = [...this.progress, combo];
        let cand = this.registered.filter((r) => active(r) && startsWith(r.sequence, next));
        if (cand.length === 0) {
            // this key doesn't continue the sequence — commit any pending shorter
            // match (the in-progress sequence just ended), then try a fresh start.
            this.commitPending();
            next = [combo];
            cand = this.registered.filter((r) => active(r) && startsWith(r.sequence, next));
            if (cand.length === 0) {
                return; // nothing matches — let the key through
            }
        }
        const live = cand.filter(isLive);
        const muted = live.length === 0;
        if (!muted) {
            // A matched shortcut fully owns the event: block the browser default AND
            // stop it reaching other JS handlers (equivalent to the old `return false`).
            e.preventDefault();
            e.stopPropagation();
            cand = live;
        }
        const exact = cand.find((r) => r.sequence.length === next.length) ?? null;
        const hasLonger = cand.some((r) => r.sequence.length > next.length);
        // exact with no possible extension → fire now (snappy single keys).
        if (exact && !hasLonger) {
            this.reset();
            this.fire(exact, muted);
            return;
        }
        // partial, or an exact that could still extend (F vs F+F) → wait; the
        // pending exact fires on timeout if no continuation arrives.
        this.progress = next;
        this.pending = exact;
        this.pendingMuted = muted;
        this.arm(cand);
        if (!muted) {
            this.onProgress?.(next);
        }
    }
}
/** Capture a sequence for the panel's Record button. Resolves on idle-pause or
 *  a bare Enter, rejects on Escape. Commits a chord (E+R) as one step when its
 *  keys are fully released; sequential taps become separate steps. Enter with
 *  a key still held (CTRL+ENTER) joins the chord instead of finishing. */
export function recordSequence(opts) {
    const idleMs = opts?.idleMs ?? 900;
    // Suspend the live engine so the keys being recorded don't fire their actions.
    suspendHotkeys();
    return new Promise((resolve, reject) => {
        const seq = [];
        const heldCodes = new Set(); // every physical key down (incl. modifiers)
        const modNames = new Set(); // peak modifiers seen this chord
        let pending = null; // max chord seen since last commit
        let idle = 0;
        // Build the current chord from the event's modifier state + all held keys.
        // Unlike the engine, a modifiers-only chord (e.g. Alt&Shift) is captured too.
        const currentCombo = (e) => {
            const mods = [];
            if (e.ctrlKey) {
                mods.push('Ctrl');
            }
            if (e.altKey) {
                mods.push('Alt');
            }
            if (e.shiftKey) {
                mods.push('Shift');
            }
            if (e.metaKey) {
                mods.push('Meta');
            }
            for (const m of modNames) {
                if (!mods.includes(m)) {
                    mods.push(m); // event flags can lag
                }
            }
            const keys = [...heldCodes].filter((c) => !isBareModifier(c));
            if (mods.length === 0 && keys.length === 0) {
                return null;
            }
            return makeCombo(mods, keys);
        };
        const commit = () => {
            if (pending) {
                seq.push(pending);
                pending = null;
            }
        };
        const finish = () => {
            commit();
            cleanup();
            seq.length ? resolve(seq) : reject(new Error('empty'));
        };
        const onDown = (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (e.code === 'Escape') {
                cleanup();
                return reject(new Error('cancelled'));
            }
            if (e.code === 'Enter' && heldCodes.size === 0 && (seq.length || pending)) {
                return finish();
            }
            if (e.repeat) {
                return;
            }
            heldCodes.add(e.code);
            const name = modifierName(e.code);
            if (name) {
                modNames.add(name);
            }
            const c = currentCombo(e);
            if (c) {
                pending = c; // grows as more keys/modifiers join the chord
            }
            clearTimeout(idle);
        };
        const onUp = (e) => {
            heldCodes.delete(e.code);
            // Whole chord released → commit it as a step, then wait for the next one.
            if (heldCodes.size === 0 && pending) {
                commit();
                modNames.clear();
                clearTimeout(idle);
                idle = window.setTimeout(finish, idleMs);
            }
        };
        const cleanup = () => {
            clearTimeout(idle);
            resumeHotkeys();
            window.removeEventListener('keydown', onDown, true);
            window.removeEventListener('keyup', onUp, true);
        };
        window.addEventListener('keydown', onDown, true);
        window.addEventListener('keyup', onUp, true);
    });
}
/** Validate a binding table: every default parses & round-trips, ids unique,
 *  and no two bindings share the exact same keys. Prefixes ARE allowed (a
 *  shorter match fires on timeout, e.g. F alongside F+F). Returns a list of
 *  problems (empty = OK). Pure — used by the boot assertion + unit test. */
export function validateBindings(defs) {
    const errors = [];
    const seen = new Set();
    const parsed = [];
    for (const d of defs) {
        if (seen.has(d.id)) {
            errors.push(`duplicate id: ${d.id}`);
        }
        seen.add(d.id);
        try {
            const seq = parseSequence(d.defaultKeys);
            const round = parseSequence(formatSequence(seq));
            if (round.join(' ') !== seq.join(' ')) {
                errors.push(`${d.id}: "${d.defaultKeys}" does not round-trip (-> "${formatSequence(seq)}")`);
            }
            parsed.push({ id: d.id, seq });
        }
        catch (e) {
            errors.push(`${d.id}: cannot parse "${d.defaultKeys}" — ${e instanceof Error ? e.message : String(e)}`);
        }
    }
    // only EXACT duplicates are errors now (prefixes coexist via timeout-fire)
    for (let i = 0; i < parsed.length; i++) {
        for (let j = i + 1; j < parsed.length; j++) {
            if (parsed[i].seq.join(' ') === parsed[j].seq.join(' ')) {
                errors.push(`${parsed[i].id} and ${parsed[j].id} share the same keys "${formatSequence(parsed[i].seq)}"`);
            }
        }
    }
    return errors;
}
