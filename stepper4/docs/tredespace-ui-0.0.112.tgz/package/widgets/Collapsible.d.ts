import { type ReactNode } from 'react';
export interface CollapsibleProps {
    title: ReactNode;
    /** Optional right-aligned note in the header (count, badge…). */
    aside?: ReactNode;
    /** Explanation shown behind an info icon in the header — the compact
     *  replacement for an always-visible InfoBox inside the section. */
    info?: ReactNode;
    defaultOpen?: boolean;
    children: ReactNode;
    className?: string;
    /** Fill the remaining panel height while open; the BODY scrolls, not the panel. */
    fill?: boolean;
    /** Height floor for a `fill` section (Tailwind class, e.g. "min-h-64").
     *  Without it a filled section shrinks to nothing when several of them share
     *  a panel; with it the section stops shrinking and the PANEL scrolls. */
    fillMinClass?: string;
}
/** A titled section that collapses. Same header look as the Shortcuts panel
 *  groups; used to organise long settings tabs. */
export declare function Collapsible({ title, aside, info, defaultOpen, children, className, fill, fillMinClass, }: CollapsibleProps): import("react").JSX.Element;
