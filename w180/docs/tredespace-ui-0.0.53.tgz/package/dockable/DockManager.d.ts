import * as L from './layout';
import type { DockManagerOptions, DockState, FloatingWindow, LayoutNode, PanelDefinition, Rect, Size } from './types';
/**
 * The dock. Framework-free: owns a layout tree plus a list of floating windows,
 * renders chrome with lit-html, and hands each panel a plain HTMLElement to
 * fill however it likes.
 *
 * All interaction is Pointer Events, so mouse, pen and touch take the same path.
 */
export declare class DockManager {
    root: LayoutNode;
    windows: FloatingWindow[];
    /** Bumped on every layout change. Useful as a `useSyncExternalStore` snapshot. */
    version: number;
    private defs;
    private hosts;
    private runtimeMin;
    private titleOverrides;
    /** Where each panel lived when last closed — reopened there if it still exists. */
    private lastLocation;
    /** The layout passed at construction, for resetLayout(). */
    private initialLayout;
    private listeners;
    private container;
    private drag;
    private frame;
    private zTop;
    readonly coarse: boolean;
    readonly headerHeight: number;
    readonly tabMinWidth: number;
    readonly splitterSize: number;
    readonly windowBarHeight: number;
    readonly defaultWindowSize: Size;
    constructor(options: DockManagerOptions);
    mount(container: HTMLElement): void;
    unmount(): void;
    /** Subscribe to layout changes (open/close/move/resize/float). Returns an unsubscribe. */
    subscribe(fn: () => void): () => void;
    registerPanel(def: PanelDefinition): void;
    getPanel(id: string): PanelDefinition | undefined;
    /** Every panel currently in the dock or in a window. */
    openPanels(): string[];
    /** Registered but not placed anywhere — build a View menu from this. */
    closedPanels(): PanelDefinition[];
    isOpen(panelId: string): boolean;
    isFloating(panelId: string): boolean;
    title(panelId: string): string;
    /** Open (or focus) a panel. Docks into `targetNodeId`, else the first unlocked tabs node. */
    openPanel(panelId: string, targetNodeId?: string): void;
    /** Open `panelId` split on `zone` of the panel `siblingId` lives in (falls
     *  back to openPanel when the sibling isn't docked or a remembered spot
     *  exists). */
    openPanelBeside(panelId: string, siblingId: string, zone: L.SplitZone): void;
    /** Open `panelId` split BELOW the panel `siblingId` lives in. */
    openPanelBelow(panelId: string, siblingId: string): void;
    closePanel(panelId: string): void;
    /** Every registered panel definition (drives a Panels toggle bar). */
    allDefs(): PanelDefinition[];
    /** Open (restoring the last location) if closed, else close. */
    togglePanel(panelId: string): void;
    /** Restore the layout the manager was constructed with. */
    /** Solo mode: close every unlocked panel except the main (central) one;
     *  a second call restores the exact layout from before. */
    toggleSolo(): void;
    private soloSnapshot;
    /** True while solo mode is on (a pre-solo layout is waiting to be restored). */
    isSolo(): boolean;
    resetLayout(): void;
    /** Collapse a node to its strip, or open it back up. */
    setCollapsed(nodeId: string, collapsed: boolean): void;
    /** Toggle the tab-strip padlock. Locking captures the group's CURRENT size
     *  as its new minimum: divider drags push it as a block and never shrink it
     *  below the size it was locked at. */
    toggleSizeLock(nodeId: string): void;
    toggleCollapse(nodeId: string): void;
    isCollapsed(nodeId: string): boolean;
    /** The node a panel lives in — handy for collapsing it by panel id. */
    nodeOf(panelId: string): string | null;
    focusPanel(panelId: string): void;
    private framePoll;
    private lastFrameEl;
    private readonly onWindowBlur;
    private readonly onWindowFocus;
    private raiseActiveIframeWindow;
    /** Lift a panel out of the dock into a floating dialog. */
    floatPanel(panelId: string, rect?: Partial<Rect>): FloatingWindow | null;
    /** Send a whole window back into the dock — each panel returns to where it
     *  was docked before floating, when that node still exists. */
    dockWindow(windowId: string, targetNodeId?: string): void;
    closeWindow(windowId: string): void;
    saveLayout(): DockState;
    loadLayout(state: DockState | LayoutNode): void;
    private trees;
    private findNodeAnywhere;
    /** Rewrite whichever tree (dock or window) contains `nodeId`. */
    private editTreeWith;
    /** Pull a panel out of the dock and every window, dropping windows left empty. */
    private detach;
    /** Return the soft-home node id, recreating a well-known side node
     *  ('left' / 'right' / 'bottom') when it was pruned after its last panel
     *  closed. Sides rejoin the outermost row split (or wrap the root). */
    private ensureHomeNode;
    private insertInto;
    private isNodeLocked;
    private defaultDropTarget;
    private env;
    private panelMin;
    private minOf;
    private clampWindow;
    private commit;
    requestRender(): void;
    private renderNow;
    private template;
    /**
     * `axis` is the direction along which this node would free up space if it
     * collapsed — its parent's direction, except inside a fully collapsed subtree,
     * where the whole subtree collapses as one and the axis passes straight
     * through. That's what turns a column of two collapsed panels into a single
     * narrow rail of two vertical labels, rather than a wide stack of strips.
     */
    private nodeTpl;
    private slotStyle;
    private splitTpl;
    private tabsTpl;
    private tabTpl;
    private windowTpl;
    /** Collapse a floating window to its title bar, or restore it. */
    minimizeWindow(windowId: string, minimized?: boolean): void;
    /** Nodes this panel is pinned to, if any. */
    private homeOf;
    /** May this panel be dropped into this node? */
    canDockInto(panelId: string, nodeId: string): boolean;
    /** A pinned panel never leaves its node, so it can never float or split out. */
    canLeaveHome(panelId: string): boolean;
    canFloat(panelId: string): boolean;
    /** Minimum width of a panel's tab button. */
    private tabMin;
    private sourceOf;
    /** Already alone in its own window — floating it again would do nothing. */
    private isSoleFloating;
    /** Compass zones that would be a no-op for this panel. */
    private deadZones;
    /** Tabbing into a strip — same strip, same slot? */
    private tabIsNoop;
    /** The dockable area (everything but locked furniture) and its live rect. */
    private regionRect;
    /** The biggest leaf in the dock — what "center" means on the compass. */
    private centralLeaf;
    /**
     * Where an outer-ring compass button would dock: beside the dock region's
     * TOP-LEVEL child containing the anchored panel — a full-band "in between"
     * drop (e.g. a new column between the center and the right column) — falling
     * back to the region edge when the region isn't a split along that axis.
     * Null when the drop would change nothing: the anchored panel already spans
     * that whole child (an inner split gives the same layout), or the dragged
     * panel already sits alone on that side.
     */
    private outerSpot;
    /** Does the anchor's slot touch the region's `zone` edge? True when the
     *  anchor is the outermost child of every same-axis split on the way down. */
    private touchesRegionEdge;
    /** The strip a compass edge button would claim. */
    private edgeBox;
    /**
     * The dock compass. Anchored to the panel under the pointer when there is
     * one: center = add as a tab THERE, the four directions split THAT panel.
     * Over empty furniture it anchors to the whole dock area instead (edge
     * docking, center = tab into the main panel). Dropping outside everything
     * still pops the panel out into a floating dialog.
     */
    private compassTpl;
    /** Blue rectangle for the resolved target, plus the compass and the stack hint. */
    private dropIndicator;
    /** The persistent element a panel renders into. Created once, reparented forever. */
    private hostFor;
    private contextFor;
    /** True when a child never resizes during a divider drag: structural lock,
     *  collapsed, or a fixed-size child not adjacent to the dragged divider.
     *  (Size-LOCKED groups are not rigid — they yield as a last resort.) */
    private rigidInDrag;
    private startResize;
    /** Distribute `amount` of shrink across `order`, strictly nearest-the-
     *  divider first, each child down to its minimum. A size-locked group needs
     *  no special case: its floor IS its current size, so it has no room and
     *  the cascade flows straight through it. Returns px taken per index. */
    private distributeShrink;
    private moveResize;
    /** Apply a size delta entering a captured nested split from its divider-
     *  touching end: growth goes to the nearest resizable child (unlocked
     *  preferred); shrink cascades inward with per-child min clamps. */
    private cascadeInner;
    /** Escape / pointercancel: put every captured size back exactly. */
    private restoreResize;
    private startWindowDrag;
    private moveWindowDrag;
    /** Start dragging a panel from OUTSIDE the dock — e.g. a Panels-ribbon
     *  button — reusing the exact tab-drag/drop flow. If the panel is closed it
     *  is placed wherever dropped; if open it moves. Pair with consumeDragClick()
     *  so the button's click doesn't also toggle after a real drag. */
    dragPanelFrom(e: PointerEvent, panelId: string): void;
    /** True (once) if the last panel drag actually moved — the caller uses this
     *  to skip the click that a browser fires after a drag. */
    consumeDragClick(): boolean;
    private panelDragActivated;
    private startPanelDrag;
    private movePanelDrag;
    private hitTest;
    private dropPanel;
    private onMove;
    private onUp;
    private onCancel;
    private onKey;
    private bindDragListeners;
    private unbindDragListeners;
}
