import type { DropHint, TimelineItem, TimelineSnap, TimelineView } from './timelineTypes';
/** Zoom limits (px per second). */
export declare const MIN_PX_PER_SEC = 4;
export declare const MAX_PX_PER_SEC = 2000;
/** How close (px) an edge must come to snap or to propose a link. */
export declare const SNAP_PX = 8;
/** px inside a strip's edge where a held drag starts panning the view. */
export declare const EDGE_PAN_ZONE_PX = 8;
/** The fastest edge pan, px per frame. */
export declare const EDGE_PAN_MAX_PX = 30;
export declare function timeToX(t: number, view: TimelineView): number;
export declare function xToTime(x: number, view: TimelineView): number;
/** Major tick step (s) so labels sit ~80 px apart: 1-2-5 progression. */
export declare function tickStep(pxPerSec: number, targetPx?: number): number;
/** Ticks inside [from, to]: { t, major } with 5 minors per major. */
export declare function ticks(from: number, to: number, pxPerSec: number): {
    t: number;
    major: boolean;
}[];
/** Zoom by `factor`, keeping the time at `anchorX` (px from the lanes' left
 *  edge; 0 = the left edge) in place; pxPerSec is clamped to 4–2000 and the
 *  offset to ≥ 0. Exported as `zoomTimelineView`. */
export declare function zoomAt(view: TimelineView, factor: number, anchorX: number): TimelineView;
/** How far (px, this frame) a drag held at client x pans a strip spanning
 *  [left, right]: 0 inside, then more the further it is into the edge zone
 *  or past the edge (up to EDGE_PAN_MAX_PX); negative on the left. */
export declare function edgePanStep(x: number, left: number, right: number): number;
/** The view panned the least so `t` sits inside a strip `width` px wide, at
 *  least `margin` px from either edge — the same object when it already does
 *  (or cannot move: the offset stays ≥ 0). */
export declare function keepInView(view: TimelineView, t: number, width: number, margin: number): TimelineView;
/** Snap a time to the nearest grid step or target within SNAP_PX. */
export declare function snapTime(t: number, snap: TimelineSnap | undefined, view: TimelineView): number;
/** Shift dt so the dragged span [s, e] snaps by its start or end. */
export declare function snapSpanDelta(s: number, e: number, dt: number, snap: TimelineSnap | undefined, view: TimelineView): number;
/** The link a dropped span would make with any other item (any row; never a
 *  locked or fixed one): its start near another's end → after; starts
 *  together → with; ends together → endsWith. The nearest within SNAP_PX wins. */
export declare function dropHintFor(moved: {
    id: string;
    start: number;
    end: number;
}, others: readonly TimelineItem[], view: TimelineView): DropHint | null;
/** Bucket entries by their row id, so each lane gets its own list without
 *  filtering the whole array once per row. */
export declare function groupByRow<T extends {
    row: string;
}>(list: readonly T[]): Map<string, T[]>;
