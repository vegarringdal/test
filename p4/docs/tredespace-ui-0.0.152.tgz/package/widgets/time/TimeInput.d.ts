import type { LabelledProps } from '../fieldChrome';
export interface TimeInputProps extends LabelledProps {
    /** Seconds. */
    value: number;
    /** Receives seconds, clamped to [min, max]. */
    onChange: (value: number) => void;
    /** Lower bound in seconds (default 0). */
    min?: number;
    /** Upper bound in seconds (default: none). */
    max?: number;
    /** seconds = a stepper in s (default); frames = a stepper in whole frames
     *  at `fps`; mmss = a typed "m:ss.s" field (plain seconds parse too) that
     *  commits on Enter or blur. */
    format?: 'seconds' | 'mmss' | 'frames';
    /** Frames per second for `frames` (default 30). */
    fps?: number;
    /** Stepper step in seconds (default 0.1); `frames` always steps one frame. */
    step?: number;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
}
/**
 * A time field: seconds or frames on a stepper (wheel / drag / type), or a
 * typed m:ss.s clock. The value is always seconds, clamped to [min, max].
 */
export declare function TimeInput({ value, onChange, min, max, format, fps, step, tooltip, shortcut, ...labelled }: TimeInputProps): import("react").JSX.Element;
