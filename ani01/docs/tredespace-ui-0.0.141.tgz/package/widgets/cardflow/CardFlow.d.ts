import { type ReactNode } from 'react';
export interface CardFlowConnector {
    from: string;
    to: string;
    /** chip text, e.g. "then", "together", "then +1s" */
    label: string;
    /** a branch (runs together with `from`) — drawn as a dashed chip */
    branch?: boolean;
}
export interface CardFlowProps<T> {
    cards: readonly T[];
    getId: (card: T) => string;
    renderCard: (card: T, state: {
        selected: boolean;
        dragging: boolean;
    }) => ReactNode;
    /** chips between consecutive cards (looked up by from → to) */
    connectors: readonly CardFlowConnector[];
    selected: string | null;
    onSelect: (id: string) => void;
    /** double-click */
    onOpen: (id: string) => void;
    /** a card dragged to position `toIndex` */
    onReorder: (id: string, toIndex: number) => void;
    /** the + between cards (index = where the new card goes) */
    onInsert: (index: number) => void;
    /** a card dropped on another card's lower edge ("together") */
    onDropOnto?: (id: string, target: string, zone: 'bottom') => void;
    /** a connector chip was clicked (open a link popover) */
    onConnectorClick?: (from: string, to: string, at: {
        x: number;
        y: number;
    }) => void;
    className?: string;
}
/**
 * A flow of cards — a storyboard: cards left to right, wrapping to rows,
 * with a chip between consecutive cards naming how they connect. Drag a card
 * to reorder, drop it on another card's lower edge to join it, + inserts.
 */
export declare function CardFlow<T>({ cards, getId, renderCard, connectors, selected, onSelect, onOpen, onReorder, onInsert, onDropOnto, onConnectorClick, className, }: CardFlowProps<T>): import("react").JSX.Element;
