import { type LabelledProps } from '../fieldChrome';
export interface NumberInputProps extends LabelledProps {
    value: number;
    onChange: (value: number) => void;
    min?: number;
    max?: number;
    step?: number;
    /** Decimals shown/kept; derived from step when omitted. */
    precision?: number;
    /** Suffix rendered after the value, e.g. "px", "×" — hidden while typing. */
    unit?: string;
    /** Styled tooltip (data-tooltip) for the field as a whole. */
    tooltip?: string;
    /** Hotkey id (data-shortcut) for the field — the tooltip gets a combo footer. */
    shortcut?: string;
    /** Hotkey ids for the − / + steppers (renders data-shortcut for the footer). */
    decShortcut?: string;
    incShortcut?: string;
}
/**
 * A stepper in the studio look: − and + on either side, and a "rolling"
 * middle — scroll the wheel over it, or press and drag horizontally like a
 * Blender field. A plain click still focuses it for typing.
 */
export declare function NumberInput({ value, onChange, min, max, step, precision, unit, tooltip, shortcut, decShortcut, incShortcut, disabled, className, ...labelled }: NumberInputProps): import("react").JSX.Element;
