import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { cn } from '../lib/cn';
import { NumberInput } from './number/NumberInput';
const AXES = [0, 1, 2];
/** Three steppers on one row for a 3-component value — a clip shape's centre,
 *  size or axis. The label column keeps stacked rows aligned. */
export function Vec3Input({ value, onChange, label, labelWidth = 48, step = 0.5, min, max, precision, unit, tooltips, disabled = false, className = '', }) {
    const setAxis = (axis, x) => [
        axis === 0 ? x : value[0],
        axis === 1 ? x : value[1],
        axis === 2 ? x : value[2],
    ];
    return (_jsxs("div", { className: cn('grid items-center gap-1 text-[11px] text-slate-400', className), style: { gridTemplateColumns: `${label != null ? `${labelWidth}px ` : ''}repeat(3, minmax(0, 1fr))` }, children: [label != null && _jsx("span", { className: "truncate", children: label }), AXES.map((ax) => (_jsx(NumberInput, { value: value[ax], step: step, min: min, max: max, precision: precision, unit: unit, tooltip: tooltips?.[ax], disabled: disabled, onChange: (x) => onChange(setAxis(ax, x)) }, ax)))] }));
}
