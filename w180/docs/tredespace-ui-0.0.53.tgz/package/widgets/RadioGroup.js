import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { InfoButton } from './InfoButton';
/** Mutually-exclusive options rendered as square checkboxes (only one true) —
 *  same visual language as the settings checkboxes, and each option carries a
 *  data-shortcut so it can be bound to a hotkey. */
export function RadioGroup({ value, options, onChange, disabled = false, className = '' }) {
    return (_jsx("div", { className: `flex flex-col gap-1.5 ${className}`, children: options.map((o) => (_jsxs("div", { className: "flex items-center gap-2", children: [_jsxs("label", { className: `flex items-center gap-2 text-slate-300 text-xs ${disabled ? 'opacity-50' : 'cursor-pointer'}`, "data-shortcut": o.shortcut, children: [_jsx("input", { type: "checkbox", checked: value === o.value, disabled: disabled, onChange: () => onChange(o.value) }), o.label, o.info == null && o.hint && _jsxs("span", { className: "text-slate-500", children: ["\u2014 ", o.hint] })] }), o.info != null && _jsx(InfoButton, { children: o.info })] }, o.value))) }));
}
