import { jsx as _jsx } from "react/jsx-runtime";
/**
 * Optional wrapper for panel content. Pass `className` to style it however you
 * like (Tailwind utilities work here — panels are plain DOM in your document,
 * no shadow root).
 */
export function PanelBody({ children, className = 'panel-body', ref, }) {
    return (_jsx("div", { ref: ref, className: className, children: children }));
}
