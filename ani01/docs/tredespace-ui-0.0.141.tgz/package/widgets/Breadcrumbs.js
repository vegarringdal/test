import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconChevronRight } from '@tabler/icons-react';
import { Fragment } from 'react';
import { cn } from '../lib/cn';
/** A clickable path — Assembly › Step 3 › Motor. The last crumb is where you
 *  are; the others go up. */
export function Breadcrumbs({ items, onSelect, className = '' }) {
    return (_jsx("nav", { "aria-label": "Breadcrumbs", className: cn('flex min-w-0 items-center gap-0.5 text-[11px]', className), children: items.map((it, i) => {
            const last = i === items.length - 1;
            return (_jsxs(Fragment, { children: [i > 0 && _jsx(IconChevronRight, { size: 11, className: "shrink-0 text-slate-600" }), last ? (_jsx("span", { className: "min-w-0 truncate text-slate-100", "aria-current": "page", children: it.label })) : (_jsx("button", { type: "button", className: "min-w-0 cursor-pointer truncate text-slate-400 hover:text-sky-300", onClick: () => onSelect(it.id), children: it.label }))] }, it.id));
        }) }));
}
