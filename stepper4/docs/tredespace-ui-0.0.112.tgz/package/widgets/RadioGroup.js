import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useId } from 'react';
import { InfoButton } from './InfoButton';
/** Mutually-exclusive options as native radio buttons — the round indicator
 *  people expect for an exclusive choice, next to the square settings
 *  checkboxes. The options share one generated `name`, so the keyboard
 *  behaves like a real radio group (arrows move within it, Tab lands on the
 *  checked one). Each option carries a data-shortcut so it can be bound to a
 *  hotkey. */
export function RadioGroup({ value, options, onChange, disabled = false, className = '' }) {
    const name = useId();
    return (_jsx("div", { className: `flex flex-col gap-1.5 ${className}`, children: options.map((o) => (_jsxs("div", { className: "flex items-center gap-2", children: [_jsxs("label", { className: `flex items-center gap-2 text-slate-300 text-xs ${disabled ? 'opacity-50' : 'cursor-pointer'}`, "data-shortcut": o.shortcut, children: [_jsx("input", { type: "radio", name: name, checked: value === o.value, disabled: disabled, onChange: () => onChange(o.value) }), o.label, o.info == null && o.hint && _jsxs("span", { className: "text-slate-500", children: ["\u2014 ", o.hint] })] }), o.info != null && _jsx(InfoButton, { children: o.info })] }, o.value))) }));
}
