import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { ClearButton, fieldCls, Labelled } from '../fieldChrome';
/** Multi-line text field in the studio look, label on top or to the left. */
export function TextArea({ value, onChange, onCommit, placeholder, rows = 3, maxLength, spellCheck = false, resizable = true, minHeight, tooltip, shortcut, clearable = true, onClear, disabled = false, ...labelled }) {
    const showClear = clearable && !disabled && (onClear != null || value.length > 0);
    return (_jsx(Labelled, { ...labelled, disabled: disabled, multiline: true, children: _jsxs("div", { className: "relative", "data-tooltip": tooltip, "data-shortcut": shortcut, children: [_jsx("textarea", { value: value, placeholder: placeholder, rows: rows, maxLength: maxLength, spellCheck: spellCheck, disabled: disabled, style: minHeight != null ? { minHeight } : undefined, className: `${fieldCls} block leading-relaxed ${showClear ? 'pr-6' : ''} ${resizable ? 'resize-y' : 'resize-none'}`, onChange: (e) => onChange(e.target.value), onBlur: (e) => onCommit?.(e.target.value) }), showClear && _jsx(ClearButton, { className: "top-1 right-0.5", onClick: () => (onClear ? onClear() : onChange('')) })] }) }));
}
