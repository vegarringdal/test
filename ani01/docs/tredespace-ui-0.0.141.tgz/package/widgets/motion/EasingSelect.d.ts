import type { LabelledProps } from '../fieldChrome';
export interface EasingOption<E extends string> {
    value: E;
    label: string;
    /** The curve for the preview glyph: progress 0..1 → eased 0..1. */
    curve: (u: number) => number;
}
export interface EasingSelectProps<E extends string> extends Pick<LabelledProps, 'disabled' | 'className'> {
    value: E;
    options: readonly EasingOption<E>[];
    onChange: (value: E) => void;
    /** Show the label next to each glyph (default: glyph only + tooltip). */
    showLabels?: boolean;
}
/**
 * Pick an easing curve: a segmented row of curve glyphs (linear, ease in, …)
 * so the choice is visible, not just named. Generic over the value union —
 * the caller supplies the curves.
 */
export declare function EasingSelect<E extends string>({ value, options, onChange, showLabels, disabled, className, }: EasingSelectProps<E>): import("react").JSX.Element;
