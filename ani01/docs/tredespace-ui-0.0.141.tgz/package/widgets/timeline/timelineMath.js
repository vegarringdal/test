// Pure timeline geometry: time ↔ px, ruler ticks, snapping and the
// magnetic-link hint (drop near an end → after, near a start → with, end on
// end → ends with). No DOM, so it unit-tests directly.
/** Zoom limits (px per second). */
export const MIN_PX_PER_SEC = 4;
export const MAX_PX_PER_SEC = 2000;
/** How close (px) an edge must come to snap or to propose a link. */
export const SNAP_PX = 8;
export function timeToX(t, view) {
    return (t - view.offset) * view.pxPerSec;
}
export function xToTime(x, view) {
    return view.offset + x / view.pxPerSec;
}
/** Major tick step (s) so labels sit ~80 px apart: 1-2-5 progression. */
export function tickStep(pxPerSec, targetPx = 80) {
    const raw = targetPx / Math.max(1e-6, pxPerSec);
    const pow = 10 ** Math.floor(Math.log10(raw));
    for (const m of [1, 2, 5, 10]) {
        if (m * pow >= raw) {
            return m * pow;
        }
    }
    return 10 * pow;
}
/** Ticks inside [from, to]: { t, major } with 5 minors per major. */
export function ticks(from, to, pxPerSec) {
    const major = tickStep(pxPerSec);
    const minor = major / 5;
    const out = [];
    const first = Math.floor(from / minor) * minor;
    for (let i = 0, t = first; t <= to + 1e-9 && i < 2000; i++, t = first + i * minor) {
        out.push({ t: Math.round(t * 1e6) / 1e6, major: Math.abs(t / major - Math.round(t / major)) < 1e-6 });
    }
    return out;
}
/** Zoom about a screen x (wheel), clamped. */
export function zoomAt(view, factor, anchorX) {
    const t = xToTime(anchorX, view);
    const pxPerSec = Math.min(MAX_PX_PER_SEC, Math.max(MIN_PX_PER_SEC, view.pxPerSec * factor));
    return { pxPerSec, offset: Math.max(0, t - anchorX / pxPerSec) };
}
/** Snap a time to the nearest grid step or target within SNAP_PX. */
export function snapTime(t, snap, view) {
    if (!snap?.enabled) {
        return t;
    }
    const tol = SNAP_PX / view.pxPerSec;
    let best = t;
    let bestD = tol;
    for (const s of snap.targets) {
        const d = Math.abs(s - t);
        if (d < bestD) {
            best = s;
            bestD = d;
        }
    }
    if (bestD < tol) {
        return best;
    }
    if (snap.step > 0) {
        const g = Math.round(t / snap.step) * snap.step;
        if (Math.abs(g - t) < tol) {
            return g;
        }
    }
    return t;
}
/** Shift dt so the dragged span [s, e] snaps by its start or end. */
export function snapSpanDelta(s, e, dt, snap, view) {
    if (!snap?.enabled) {
        return dt;
    }
    const s1 = snapTime(s + dt, snap, view);
    if (s1 !== s + dt) {
        return s1 - s;
    }
    const e1 = snapTime(e + dt, snap, view);
    return e1 !== e + dt ? e1 - e : dt;
}
/** The link a dropped span would make with a sibling (same row group):
 *  its start near another's end → after; starts together → with; ends
 *  together → endsWith. */
export function dropHintFor(moved, others, view) {
    const tol = SNAP_PX / view.pxPerSec;
    const candidates = [];
    for (const o of others) {
        if (o.id === moved.id || o.locked || o.fixed) {
            continue;
        }
        candidates.push({ hint: { kind: 'after', target: o.id }, d: Math.abs(moved.start - o.end) }, { hint: { kind: 'with', target: o.id }, d: Math.abs(moved.start - o.start) }, { hint: { kind: 'endsWith', target: o.id }, d: Math.abs(moved.end - o.end) });
    }
    const near = candidates.filter((c) => c.d < tol).sort((a, b) => a.d - b.d);
    return near[0]?.hint ?? null;
}
/** Bucket entries by their row id, so each lane gets its own list without
 *  filtering the whole array once per row. */
export function groupByRow(list) {
    const out = new Map();
    for (const e of list) {
        const bucket = out.get(e.row);
        if (bucket) {
            bucket.push(e);
        }
        else {
            out.set(e.row, [e]);
        }
    }
    return out;
}
