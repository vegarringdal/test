import { type LabelledProps } from '../fieldChrome';
export interface TextAreaProps extends LabelledProps {
    value: string;
    onChange: (value: string) => void;
    /** Fires on blur — for commit-style handling on top of onChange. */
    onCommit?: (value: string) => void;
    placeholder?: string;
    rows?: number;
    maxLength?: number;
    spellCheck?: boolean;
    /** Allow the user to resize vertically (default true). */
    resizable?: boolean;
    /** Lower bound for the field height in px — also the floor while resizing. */
    minHeight?: number;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    /** Show the in-field clear (✕) button (default true). */
    clearable?: boolean;
    /** What ✕ does. Default clears the content; provide this to override. */
    onClear?: () => void;
}
/** Multi-line text field in the studio look, label on top or to the left. */
export declare function TextArea({ value, onChange, onCommit, placeholder, rows, maxLength, spellCheck, resizable, minHeight, tooltip, shortcut, clearable, onClear, disabled, ...labelled }: TextAreaProps): import("react").JSX.Element;
