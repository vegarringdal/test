import { createStore } from '../lib/createStore';
import { formatSequence, HotkeyEngine, parseSequence } from './engine';
// Optional host hook: called with a display line every time a shortcut fires
// (this app routes it to the Console). Module-level for the same reason as the
// other widget injection points — dockable panels live in separate React roots.
let announce = null;
/** Host app: receive a "⌨ label · combo" line whenever a shortcut fires. */
export function setHotkeyAnnouncer(fn) {
    announce = fn;
}
const KEY = 'hotkeys'; // localStorage: Record<id, Override>
const engine = new HotkeyEngine();
function loadOverrides() {
    try {
        return JSON.parse(localStorage.getItem(KEY) ?? '{}');
    }
    catch {
        return {};
    }
}
export const hotkeysState = createStore({ defs: {}, order: [], overrides: loadOverrides() });
/** Effective sequence: user override, else the def's parsed defaultKeys. */
function effective(d, ov) {
    return ov?.keys ?? parseSequence(d.defaultKeys);
}
function persist() {
    localStorage.setItem(KEY, JSON.stringify(hotkeysState.get().overrides));
}
function rebuild() {
    const { defs, overrides } = hotkeysState.get();
    const list = Object.values(defs).map((d) => {
        const sequence = effective(d, overrides[d.id]);
        return {
            id: d.id,
            sequence,
            // announce the shortcut (Console in this app) when it fires, then run
            run: () => {
                announce?.(`⌨ ${d.label} · ${formatSequence(sequence)}`);
                d.run();
            },
            timeout: overrides[d.id]?.timeout ?? d.timeout,
            allowInInput: overrides[d.id]?.allowInInput ?? d.allowInInput,
            context: d.context,
        };
    });
    engine.setBindings(list);
}
export const hotkeysActions = {
    /** Register the whole table once at boot; also starts the engine. */
    register(defs) {
        const map = {};
        const order = [];
        for (const d of defs) {
            if (map[d.id]) {
                console.warn(`duplicate hotkey id: ${d.id}`);
            }
            else {
                order.push(d.id);
            }
            map[d.id] = d;
        }
        hotkeysState.set({ defs: map, order });
        rebuild();
        engine.start();
    },
    /** Effective (override or default) sequence for one id. */
    sequenceFor(id) {
        const { defs, overrides } = hotkeysState.get();
        return defs[id] ? effective(defs[id], overrides[id]) : null;
    },
    /** Description text for an id — reused as a tooltip when a control has a
     *  shortcut but no explicit tooltip of its own. */
    describe(id) {
        return hotkeysState.get().defs[id]?.description ?? null;
    },
    /** True when the shortcut has any user override (drives the Reset button). */
    isCustom(id) {
        return id in hotkeysState.get().overrides;
    },
    /** Conflict check: every OTHER id whose effective sequence is EXACTLY `seq`
     *  (prefixes are allowed to coexist — a shorter match fires on timeout). */
    conflictsFor(seq, excludeId) {
        const { defs, overrides } = hotkeysState.get();
        const target = seq.join(' ');
        return Object.values(defs)
            .filter((d) => d.id !== excludeId)
            .filter((d) => effective(d, overrides[d.id]).join(' ') === target)
            .map((d) => d.id);
    },
    setOverride(id, keys) {
        const ov = hotkeysState.get().overrides;
        hotkeysState.set({ overrides: { ...ov, [id]: { ...ov[id], keys } } });
        persist();
        rebuild();
    },
    setAllowInInput(id, allow) {
        const ov = hotkeysState.get().overrides;
        hotkeysState.set({ overrides: { ...ov, [id]: { ...ov[id], allowInInput: allow } } });
        persist();
        rebuild();
    },
    setTimeout(id, ms) {
        const ov = hotkeysState.get().overrides;
        hotkeysState.set({ overrides: { ...ov, [id]: { ...ov[id], timeout: ms } } });
        persist();
        rebuild();
    },
    resetOne(id) {
        const overrides = { ...hotkeysState.get().overrides };
        delete overrides[id];
        hotkeysState.set({ overrides });
        persist();
        rebuild();
    },
    resetAll() {
        hotkeysState.set({ overrides: {} });
        localStorage.removeItem(KEY);
        rebuild();
    },
    // -----------------------------------------------------------------------------
    // share: export / import a keymap as JSON
    // -----------------------------------------------------------------------------
    /** Only the deltas from default, keyed by stable id; keys are display strings
     *  so the file is human-readable and portable across versions. */
    exportJson() {
        const { defs, overrides } = hotkeysState.get();
        const out = {};
        for (const [id, ov] of Object.entries(overrides)) {
            if (!defs[id]) {
                continue;
            }
            out[id] = {
                ...(ov.keys ? { keys: formatSequence(ov.keys) } : {}),
                ...(ov.allowInInput != null ? { allowInInput: ov.allowInInput } : {}),
                ...(ov.timeout != null ? { timeout: ov.timeout } : {}),
            };
        }
        return JSON.stringify({ version: 1, bindings: out }, null, 2);
    },
    /** Load a keymap. Defensive: unknown ids, unparseable keys and conflicts are
     *  skipped; returns a report so the panel can show what happened. */
    importJson(text) {
        const report = { applied: [], skipped: [], conflicts: [] };
        let parsed;
        try {
            parsed = JSON.parse(text);
        }
        catch {
            throw new Error('not valid JSON');
        }
        const { defs } = hotkeysState.get();
        const next = { ...hotkeysState.get().overrides };
        for (const [id, entry] of Object.entries(parsed.bindings ?? {})) {
            if (!defs[id]) {
                report.skipped.push(id);
                continue;
            }
            let keys;
            if (entry.keys) {
                try {
                    keys = parseSequence(entry.keys);
                }
                catch {
                    report.skipped.push(id);
                    continue;
                }
                if (hotkeysActions.conflictsFor(keys, id).length) {
                    report.conflicts.push(id);
                    continue;
                }
            }
            next[id] = {
                ...(keys ? { keys } : {}),
                ...(entry.allowInInput != null ? { allowInInput: entry.allowInInput } : {}),
                ...(entry.timeout != null ? { timeout: entry.timeout } : {}),
            };
            report.applied.push(id);
        }
        hotkeysState.set({ overrides: next });
        persist();
        rebuild();
        return report;
    },
};
export { formatSequence };
