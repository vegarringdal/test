import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconAlertTriangle, IconCircleCheck, IconInfoCircle } from '@tabler/icons-react';
import { cn } from '../lib/cn';
import { TONE_ACCENT, TONE_BLOCK } from './tone';
const DEFAULT_ICON = {
    neutral: _jsx(IconInfoCircle, { size: 15 }),
    info: _jsx(IconInfoCircle, { size: 15 }),
    success: _jsx(IconCircleCheck, { size: 15 }),
    warning: _jsx(IconInfoCircle, { size: 15 }),
    danger: _jsx(IconAlertTriangle, { size: 15 }),
};
/** A padded, tinted note — for hints, warnings and inline failures. */
export function InfoBox({ children, tone = 'warning', icon, className = '' }) {
    const glyph = icon === undefined ? DEFAULT_ICON[tone] : icon;
    return (_jsxs("div", { className: cn('flex items-start gap-2 border px-2 py-1.5 text-[11px] text-slate-300 leading-relaxed', TONE_BLOCK[tone], className), children: [glyph != null && _jsx("span", { className: cn('mt-px shrink-0', TONE_ACCENT[tone]), children: glyph }), _jsx("div", { className: "min-w-0 flex-1", children: children })] }));
}
