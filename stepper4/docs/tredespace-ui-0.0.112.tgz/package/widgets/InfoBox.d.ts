import type { ReactNode } from 'react';
export interface InfoBoxProps {
    children: ReactNode;
    className?: string;
}
/** A padded, tinted note with a circled info icon — for hints/explanations. */
export declare function InfoBox({ children, className }: InfoBoxProps): import("react").JSX.Element;
