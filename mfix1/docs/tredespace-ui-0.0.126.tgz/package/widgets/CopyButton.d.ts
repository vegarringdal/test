import { type ReactNode } from 'react';
import type { ButtonSize } from './buttonStyles';
export interface CopyButtonProps {
    /** The text put on the clipboard — a string, or a getter for something
     *  expensive to build (a whole grid as TSV). */
    value: string | (() => string);
    /** Label while idle (default "Copy"); omit with `iconOnly`. */
    children?: ReactNode;
    /** Label while the confirmation shows (default "Copied"). */
    copiedLabel?: string;
    size?: ButtonSize;
    iconOnly?: boolean;
    disabled?: boolean;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    className?: string;
}
/** Copy-to-clipboard with its own "Copied" confirmation — so no panel has to
 *  hand-roll the timer, and a failed copy simply never confirms. */
export declare function CopyButton({ value, children, copiedLabel, size, iconOnly, disabled, tooltip, shortcut, className, }: CopyButtonProps): import("react").JSX.Element;
