import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { IconPencil } from '@tabler/icons-react';
import { Button } from './Button';
import { DialogFrame } from './DialogFrame';
import { TextInput } from './text/TextField';
/** Pure one-line text-input dialog — props only, no store coupling; the caller
 *  owns the controlled input value. */
export function PromptDialogCore({ title, message, value, okLabel, cancelLabel = 'Cancel', onChange, onResult, z = 2000, }) {
    return (_jsxs(DialogFrame, { z: z, icon: _jsx(IconPencil, { size: 16, className: "shrink-0 text-blue-400" }), title: title, onClose: () => onResult(false), bodyClassName: "flex min-h-0 flex-1 flex-col gap-2 overflow-y-auto px-3 py-4 text-xs leading-relaxed", footer: _jsxs(_Fragment, { children: [_jsx(Button, { variant: "ghost", className: "px-4", onClick: () => onResult(false), children: cancelLabel }), _jsx(Button, { variant: "primary", className: "px-4", onClick: () => onResult(true), children: okLabel })] }), children: [_jsx("span", { children: message }), _jsx(TextInput, { autoFocus: true, clearable: false, value: value, onChange: onChange, onCommit: () => onResult(true) })] }));
}
