import type { LabelledProps } from '../fieldChrome';
export interface TimeInputProps extends LabelledProps {
    /** Seconds. */
    value: number;
    onChange: (value: number) => void;
    min?: number;
    max?: number;
    /** seconds = a stepper in s; frames = a stepper in frames at `fps`;
     *  mmss = a typed "m:ss.s" field. */
    format?: 'seconds' | 'mmss' | 'frames';
    /** Frames per second for `frames` (default 30). */
    fps?: number;
    /** Stepper step in seconds (default 0.1). */
    step?: number;
    tooltip?: string;
    shortcut?: string;
}
/** "m:ss.s" ↔ seconds. Accepts "75", "1:15", "1:15.5". */
export declare function parseClock(text: string): number | null;
export declare function formatClock(seconds: number): string;
/**
 * A time field: seconds or frames on a stepper (wheel / drag / type), or a
 * typed m:ss.s clock. The value is always seconds, clamped to [min, max].
 */
export declare function TimeInput({ value, onChange, min, max, format, fps, step, tooltip, shortcut, ...labelled }: TimeInputProps): import("react").JSX.Element;
