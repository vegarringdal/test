import type { ReactNode } from 'react';
/** The in-field clear button (shared by TextInput/TextArea). Floats over the
 *  right edge; clears content by default, or runs `onClear` when given. */
export declare function ClearButton({ onClick, className }: {
    onClick: () => void;
    className?: string;
}): import("react").JSX.Element;
/** The label props every field widget shares — laid out by {@link Labelled}. */
export interface LabelledProps {
    /** Caption; omit it and the field renders bare. */
    label?: ReactNode;
    /**
     * Where the label sits relative to the field (default `top`). `left` gives
     * the LABEL a fixed column (`labelWidth`) and lets the field fill — stacked
     * form fields line up. `split` is the settings-row inverse: the label takes
     * the free space and the FIELD keeps a fixed width (`fieldWidth`).
     */
    labelPosition?: 'top' | 'left' | 'split';
    /** Label column width in px for `left` (default 60) — share one value across stacked fields so they align. */
    labelWidth?: number;
    /** Field column width in px for `split` (default 112). */
    fieldWidth?: number;
    /** Grey the field out and block input. */
    disabled?: boolean;
    /** Extra classes on the outermost element: the labelled row (label included), or the wrapper of a bare field. */
    className?: string;
}
export declare const fieldCls = "w-full min-w-0 border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-200 placeholder-slate-500 outline-none transition-colors hover:border-slate-600 focus:border-blue-400 disabled:cursor-not-allowed disabled:opacity-50";
/** Select-style popover trigger chrome shared by the picker fields. */
export declare function pickerTriggerCls(open: boolean, disabled: boolean): string;
/** Body-portaled popover container shared by the picker fields (matches the
 *  Select list's box). */
export declare const pickerPopCls = "fixed z-[2500] border border-slate-700 bg-slate-900 text-slate-200 text-xs shadow-black/40 shadow-lg";
/** Optional label wrapper shared by every field widget — the single place a
 *  labelled row is laid out, so Select, NumberInput, ColorSelect and the text
 *  fields all align in the same form. */
export declare function Labelled({ label, labelPosition, labelWidth, fieldWidth, multiline, className, children, }: LabelledProps & {
    multiline?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
