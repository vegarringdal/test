export { type ColorSelectSwatchesStore, DEFAULT_PICKER_SWATCHES, setColorSelectSwatchesStore, } from './colorSelectSwatches';
export interface ColorSelectProps {
    value: string;
    onChange: (color: string) => void;
    /** Quick-pick row at the bottom of the popover. */
    swatches?: string[];
    disabled?: boolean;
    className?: string;
    /** Fill the parent height exactly (ribbon slots) instead of the h-6 floor. */
    flush?: boolean;
}
/**
 * The one colour picker: saturation/value area + hue bar, with hex and RGB
 * entry, quick swatches, popover portaled to body. HSV lives locally while
 * open so hue survives passing through black/white/grey.
 */
export declare function ColorSelect({ value, onChange, swatches, disabled, className, flush, }: ColorSelectProps): import("react").JSX.Element;
