import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconPlus } from '@tabler/icons-react';
import { Fragment, useRef, useState } from 'react';
import { cn } from '../../lib/cn';
import { CardFlowLink } from './CardFlowLink';
/**
 * A flow of cards — a storyboard: cards left to right, wrapping to rows,
 * with a chip between consecutive cards naming how they connect. Drag a card
 * to reorder, drop it on another card's lower edge to join it, + inserts.
 */
export function CardFlow({ cards, getId, renderCard, connectors, selected, onSelect, onOpen, onReorder, onInsert, onDropOnto, onConnectorClick, className = '', }) {
    const dragId = useRef(null);
    const [dragging, setDragging] = useState(null);
    const [over, setOver] = useState(null);
    const conn = (from, to) => connectors.find((c) => c.from === from && c.to === to);
    const handleDrop = (targetIndex, target, zone) => {
        const id = dragId.current;
        dragId.current = null;
        setDragging(null);
        setOver(null);
        if (!id || id === target) {
            return;
        }
        if (zone === 'bottom' && onDropOnto) {
            onDropOnto(id, target, 'bottom');
            return;
        }
        onReorder(id, targetIndex);
    };
    return (_jsxs("div", { className: cn('flex flex-wrap items-center gap-y-3 p-2', className), children: [cards.map((card, i) => {
                const id = getId(card);
                const prev = i > 0 ? getId(cards[i - 1]) : null;
                const c = prev ? conn(prev, id) : undefined;
                return (_jsxs(Fragment, { children: [prev && (_jsx(CardFlowLink, { label: c?.label ?? 'then', branch: c?.branch ?? false, onClick: (at) => onConnectorClick?.(prev, id, at), onInsert: () => onInsert(i) })), _jsx("div", { role: "button", tabIndex: 0, draggable: true, className: cn('relative cursor-pointer outline-none', over?.id === id && over.zone === 'before' && 'border-sky-400 border-l-2', over?.id === id && over.zone === 'bottom' && 'border-sky-400 border-b-2'), onClick: () => onSelect(id), onDoubleClick: () => onOpen(id), onKeyDown: (e) => e.key === 'Enter' && onOpen(id), onDragStart: () => {
                                dragId.current = id;
                                setDragging(id);
                            }, onDragEnd: () => {
                                setDragging(null);
                                setOver(null);
                            }, onDragOver: (e) => {
                                e.preventDefault();
                                const r = e.currentTarget.getBoundingClientRect();
                                setOver({ id, zone: onDropOnto && e.clientY > r.top + r.height * 0.7 ? 'bottom' : 'before' });
                            }, onDrop: (e) => {
                                const r = e.currentTarget.getBoundingClientRect();
                                handleDrop(i, id, onDropOnto && e.clientY > r.top + r.height * 0.7 ? 'bottom' : 'before');
                            }, children: renderCard(card, { selected: selected === id, dragging: dragging === id }) })] }, id));
            }), _jsx("button", { type: "button", className: "ml-2 flex h-10 w-10 cursor-pointer items-center justify-center border border-slate-700 border-dashed text-slate-500 hover:border-sky-400 hover:text-sky-300", "data-tooltip": "Add a card at the end", onClick: () => onInsert(cards.length), onDragOver: (e) => e.preventDefault(), onDrop: () => {
                    const id = dragId.current;
                    dragId.current = null;
                    if (id) {
                        onReorder(id, cards.length);
                    }
                }, children: _jsx(IconPlus, { size: 16 }) })] }));
}
