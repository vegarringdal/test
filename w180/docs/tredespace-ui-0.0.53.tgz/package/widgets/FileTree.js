import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
// A file-tree picker. Multi-select like a desktop file manager: click =
// select one, Ctrl+click = toggle, Shift+click = range over the VISIBLE rows,
// folder chevron = toggle expansion, folder Ctrl/plain click selects/deselects
// everything under it. Optional drag-and-drop moves and a right-click folder
// menu — see FileTreeProps.
import { IconFile3d } from '@tabler/icons-react';
import { useMemo, useState } from 'react';
import { cn } from '../lib/cn';
import { FileTreeMenu } from './FileTreeMenu';
import { FileTreeRow } from './FileTreeRow';
import { visibleRows } from './fileTreeModel';
import { useFileTreeSelection } from './useFileTreeSelection';
/** Controlled tree: `selected` is a set of file paths owned by the parent.
 *  Optional extras: `onMove` enables dragging the selected files onto a folder
 *  (or the root gap) and `onAddFolder` adds a right-click → New folder menu. */
export function FileTree({ root, selected, onSelect, onMove, onAddFolder, onRenameFolder, onDeleteFolder, onMoveFolder, emptyText = 'No files found.', fileIcon = _jsx(IconFile3d, { size: 13, className: "shrink-0 text-slate-400" }), className, }) {
    const [collapsed, setCollapsed] = useState(new Set());
    const [dropDir, setDropDir] = useState(null);
    const [menu, setMenu] = useState(null);
    /** Paths that travel in a drag: the whole selection when dragging a selected
     *  row, else just the dragged row. */
    const dragPaths = (path) => (selected.has(path) ? [...selected] : [path]);
    const rows = useMemo(() => visibleRows(root, collapsed), [root, collapsed]);
    const visibleFiles = rows.filter((r) => r.node.kind === 'file').map((r) => r.node.path);
    const { click } = useFileTreeSelection(selected, onSelect, visibleFiles);
    const toggleExpand = (path) => {
        setCollapsed((c) => {
            const next = new Set(c);
            if (next.has(path)) {
                next.delete(path);
            }
            else {
                next.add(path);
            }
            return next;
        });
    };
    return (_jsxs("div", { className: cn('relative select-none overflow-y-auto border border-slate-800', className ?? 'max-h-64'), onContextMenu: (e) => {
            if (!onAddFolder) {
                return;
            }
            e.preventDefault();
            const rowEl = e.target.closest('[data-dir]');
            setMenu({ x: e.clientX, y: e.clientY, dirPath: rowEl?.getAttribute('data-dir') ?? null });
        }, onDragOver: (e) => {
            if (onMove || onMoveFolder) {
                e.preventDefault();
                setDropDir('');
            }
        }, onDrop: (e) => {
            e.preventDefault();
            const paths = e.dataTransfer.getData('text/x-asset-paths');
            const dir = e.dataTransfer.getData('text/x-asset-dir');
            if (paths && onMove && dropDir != null) {
                onMove(JSON.parse(paths), dropDir === '' ? '' : dropDir);
            }
            else if (dir && onMoveFolder) {
                onMoveFolder(dir, '');
            }
            setDropDir(null);
        }, onDragLeave: () => setDropDir(null), children: [menu && onAddFolder && (_jsx(FileTreeMenu, { menu: menu, onClose: () => setMenu(null), onAddFolder: onAddFolder, onRenameFolder: onRenameFolder, onDeleteFolder: onDeleteFolder })), rows.map((r) => (_jsx(FileTreeRow, { r: r, selected: selected, collapsed: collapsed, dropDir: dropDir, setDropDir: setDropDir, toggleExpand: toggleExpand, onRowClick: (row, e) => {
                    setMenu(null);
                    click(row, e);
                }, dragPaths: dragPaths, onMove: onMove, onMoveFolder: onMoveFolder, fileIcon: fileIcon }, r.node.path || r.node.name))), rows.length === 0 && _jsx("p", { className: "mt-3.5 mb-0 p-2 text-slate-400 text-xs", children: emptyText })] }));
}
