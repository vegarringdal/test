export interface DateTimePickerProps {
    /** Selected moment as ISO local `"yyyy-mm-ddTHH:MM"` (no timezone), or
     *  null when empty. Sorts correctly as a plain string. */
    value: string | null;
    /** Receives the picked moment, or null when cleared. */
    onChange: (value: string | null) => void;
    /** Earliest / latest pickable day (ISO `yyyy-mm-dd`, inclusive) — bounds
     *  the calendar only, not the time of day. */
    min?: string;
    max?: string;
    /** Snap picked minutes to this step (default 1 = exact minute). */
    minuteStep?: number;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    /** Styled tooltip (data-tooltip) on the field. */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
}
/**
 * Date + time in one field: the calendar picks the day, then the popover
 * advances to the clock (hour → minute → done); the header re-enters either
 * part. Composed from DatePicker's CalendarGrid and TimePicker's ClockDial,
 * value as ISO local `"yyyy-mm-ddTHH:MM"`.
 */
export declare function DateTimePicker({ value, onChange, min, max, minuteStep, placeholder, disabled, className, tooltip, shortcut, }: DateTimePickerProps): import("react").JSX.Element;
