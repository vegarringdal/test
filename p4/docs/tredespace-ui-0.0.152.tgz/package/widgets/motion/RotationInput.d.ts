import type { ReactNode } from 'react';
/** x y z w */
export type Quaternion = [number, number, number, number];
export interface RotationInputProps {
    /** The rotation as a quaternion [x, y, z, w] (need not be normalised). */
    value: Quaternion;
    /** Receives a unit quaternion. */
    onChange: (q: Quaternion) => void;
    /** euler = X/Y/Z degrees, rotate X, then Y, then Z (default); axisAngle =
     *  an axis and degrees about it. */
    mode?: 'euler' | 'axisAngle';
    /** Row caption in a fixed column before the fields. */
    label?: ReactNode;
    /** Label column width in px (default 48) — share one value down a form. */
    labelWidth?: number;
    /** Stepper step in degrees (default 5). */
    step?: number;
    /** Grey out every field. */
    disabled?: boolean;
    /** Extra classes on the outer element. */
    className?: string;
}
/** Quaternion ↔ XYZ Euler degrees (R = Rz·Ry·Rx). */
export declare function quatToEuler(q: Quaternion): [number, number, number];
/** XYZ Euler degrees → quaternion [x, y, z, w] (R = Rz·Ry·Rx — the inverse of quatToEuler). */
export declare function eulerToQuat(e: readonly number[]): Quaternion;
/** Quaternion → unit axis + degrees (0..180; identity reads as +Z, 0°). */
export declare function quatToAxisAngle(q: Quaternion): {
    axis: [number, number, number];
    degrees: number;
};
/**
 * A rotation editor over a quaternion value: three Euler-degree steppers, or
 * an axis + an angle. Storage stays a quaternion; the fields are a view.
 */
export declare function RotationInput({ value, onChange, mode, label, labelWidth, step, disabled, className, }: RotationInputProps): import("react").JSX.Element;
