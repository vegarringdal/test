import { type RefObject } from 'react';
import type { SelectOption } from './Select';
export type SelectDropdown = Readonly<{
    open: boolean;
    setOpen: (o: boolean | ((o: boolean) => boolean)) => void;
    query: string;
    setQuery: (q: string) => void;
    hot: number;
    setHot: (h: number | ((h: number) => number)) => void;
    filtered: SelectOption[];
    asyncState: {
        options: SelectOption[];
        loading: boolean;
        error: string | null;
    };
    pos: {
        left: number;
        top: number;
        width: number;
        up: boolean;
    };
    rootRef: RefObject<HTMLDivElement | null>;
    popRef: RefObject<HTMLDivElement | null>;
    searchRef: RefObject<HTMLInputElement | null>;
    listRef: RefObject<HTMLDivElement | null>;
    known: (v: string) => SelectOption;
}>;
/** Open/filter/anchor state for the Select popover: debounced async search,
 *  local filtering, outside-close, and viewport-anchored placement. */
export declare function useSelectDropdown(options: SelectOption[], loadOptions: ((query: string) => Promise<SelectOption[]>) | undefined, searchable: boolean, selected: ReadonlySet<string>): SelectDropdown;
