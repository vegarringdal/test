import { type ReactNode } from 'react';
export interface RadioOption {
    value: string;
    label: string;
    /** Small dimmed note after the label. */
    hint?: string;
    /** Longer explanation, shown behind an info icon after the label (replaces
     *  the inline hint when set) — keeps the row short. */
    info?: ReactNode;
    /** Hotkey id (data-shortcut) for this option. */
    shortcut?: string;
}
export interface RadioGroupProps {
    value: string;
    options: RadioOption[];
    onChange: (value: string) => void;
    disabled?: boolean;
    className?: string;
}
/** Mutually-exclusive options as native radio buttons — the round indicator
 *  people expect for an exclusive choice, next to the square settings
 *  checkboxes. The options share one generated `name`, so the keyboard
 *  behaves like a real radio group (arrows move within it, Tab lands on the
 *  checked one). Each option carries a data-shortcut so it can be bound to a
 *  hotkey. */
export declare function RadioGroup({ value, options, onChange, disabled, className }: RadioGroupProps): import("react").JSX.Element;
