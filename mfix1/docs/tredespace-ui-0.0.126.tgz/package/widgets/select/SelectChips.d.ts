import type { SelectOption } from './Select';
/** Multi-select trigger summary: one chip per selected option with remove ×. */
export declare function SelectChips<T extends string = string>({ values, known, onRemove, }: {
    values: readonly T[];
    known: (v: T) => SelectOption<T>;
    onRemove: (v: T) => void;
}): import("react").JSX.Element;
