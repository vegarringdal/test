import type { DropHint, TimelineItem, TimelineSnap, TimelineView } from './timelineTypes';
/** Zoom limits (px per second). */
export declare const MIN_PX_PER_SEC = 4;
export declare const MAX_PX_PER_SEC = 2000;
/** How close (px) an edge must come to snap or to propose a link. */
export declare const SNAP_PX = 8;
export declare function timeToX(t: number, view: TimelineView): number;
export declare function xToTime(x: number, view: TimelineView): number;
/** Major tick step (s) so labels sit ~80 px apart: 1-2-5 progression. */
export declare function tickStep(pxPerSec: number, targetPx?: number): number;
/** Ticks inside [from, to]: { t, major } with 5 minors per major. */
export declare function ticks(from: number, to: number, pxPerSec: number): {
    t: number;
    major: boolean;
}[];
/** Zoom about a screen x (wheel), clamped. */
export declare function zoomAt(view: TimelineView, factor: number, anchorX: number): TimelineView;
/** Snap a time to the nearest grid step or target within SNAP_PX. */
export declare function snapTime(t: number, snap: TimelineSnap | undefined, view: TimelineView): number;
/** Shift dt so the dragged span [s, e] snaps by its start or end. */
export declare function snapSpanDelta(s: number, e: number, dt: number, snap: TimelineSnap | undefined, view: TimelineView): number;
/** The link a dropped span would make with a sibling (same row group):
 *  its start near another's end → after; starts together → with; ends
 *  together → endsWith. */
export declare function dropHintFor(moved: {
    id: string;
    start: number;
    end: number;
}, others: readonly TimelineItem[], view: TimelineView): DropHint | null;
/** Bucket entries by their row id, so each lane gets its own list without
 *  filtering the whole array once per row. */
export declare function groupByRow<T extends {
    row: string;
}>(list: readonly T[]): Map<string, T[]>;
