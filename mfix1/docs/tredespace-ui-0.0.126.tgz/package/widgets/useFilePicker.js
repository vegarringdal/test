import { jsx as _jsx } from "react/jsx-runtime";
import { useRef } from 'react';
/** A hidden `<input type=file>` + an `open()` trigger — the shared piece of
 *  every panel's Load… button. Render `element` anywhere in the tree. */
export function useFilePicker(accept, onFile) {
    const ref = useRef(null);
    const element = (_jsx("input", { ref: ref, type: "file", accept: accept, className: "hidden", onChange: (e) => {
            const f = e.target.files?.[0];
            if (f) {
                onFile(f);
            }
            e.target.value = '';
        } }));
    return { element, open: () => ref.current?.click(), ref };
}
/** Same as useFilePicker, but the user can pick SEVERAL files at once (SQL
 *  Assets → Import Database). `onFiles` never gets an empty list. */
export function useMultiFilePicker(accept, onFiles) {
    const ref = useRef(null);
    const element = (_jsx("input", { ref: ref, type: "file", accept: accept, multiple: true, className: "hidden", onChange: (e) => {
            const files = Array.from(e.target.files ?? []);
            if (files.length) {
                onFiles(files);
            }
            e.target.value = '';
        } }));
    return { element, open: () => ref.current?.click(), ref };
}
/** Read a picked file as text and hand it to `onText`; parse errors are the
 *  caller's job (they usually show a dialog). */
export function readFileText(file, onText) {
    const reader = new FileReader();
    reader.onload = () => onText(String(reader.result));
    reader.readAsText(file);
}
