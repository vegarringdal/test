import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { cn } from '../lib/cn';
import { BUTTON_ACTIVE, BUTTON_BASE, BUTTON_ICON_SIZE, BUTTON_SIZE, BUTTON_VARIANT, } from './buttonStyles';
/**
 * A run of joined buttons for one exclusive choice — the horizontal sibling of
 * RadioGroup, for a mode switch that belongs in a toolbar rather than a form.
 * Segments share their borders, so the group reads as one control.
 */
export function SegmentedControl({ value, options, onChange, size = 'md', grow = false, fill = false, disabled = false, className = '', }) {
    return (_jsx("div", { role: "group", className: cn('inline-flex min-w-0 items-stretch', grow && 'flex w-full', className), children: options.map((o, i) => {
            const on = o.value === value;
            const iconOnly = o.label == null;
            return (_jsxs("button", { type: "button", "aria-pressed": on, disabled: disabled || o.disabled, "data-tooltip": o.tooltip, "data-shortcut": o.shortcut, className: cn(BUTTON_BASE, iconOnly ? BUTTON_ICON_SIZE[size] : BUTTON_SIZE[size], fill && 'h-full min-h-0', grow && 'min-w-0 flex-1', 
                // the shared edge: every segment but the first pulls onto its
                // neighbour's border, and the active one lifts above both
                i > 0 && '-ml-px', on ? cn(BUTTON_ACTIVE, 'z-10') : BUTTON_VARIANT.default, 'cursor-pointer disabled:cursor-not-allowed disabled:opacity-40'), onClick: () => onChange(o.value), children: [o.icon != null && (_jsx("span", { className: "flex h-3.5 w-3.5 shrink-0 items-center justify-center [&>svg]:h-3.5 [&>svg]:w-3.5", children: o.icon })), o.label != null && _jsx("span", { className: "truncate", children: o.label })] }, o.value));
        }) }));
}
