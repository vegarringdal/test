import type { ReactNode } from 'react';
import type { MenuEntry } from '../menu/Menu';
export type TransportStatus = 'stopped' | 'playing' | 'paused' | 'waiting';
export interface TransportControlsProps {
    /** Drives the main button: Play (stopped), Pause (playing), Continue
     *  (paused, or waiting at a stop point). */
    status: TransportStatus;
    /** The main button: play, pause or continue — `status` is yours to update. */
    onPlayPause: () => void;
    /** Omitted = no stop button. Disabled while `status` is 'stopped'. */
    onStop?: () => void;
    /** Previous part / step; omitted = no button. */
    onPrev?: () => void;
    /** Next part / step; omitted = no button. */
    onNext?: () => void;
    /** Hotkey ids per button (tooltip combo footers). */
    shortcuts?: {
        playPause?: string;
        stop?: string;
        prev?: string;
        next?: string;
    };
    /** Alternatives under the main button's chevron (e.g. how Continue treats
     *  the camera); the chevron's tooltip is "Continue options". Without it
     *  the main button is a plain button. */
    playMenu?: readonly MenuEntry[];
    /** Tooltips per button (defaults describe the action). */
    tooltips?: {
        playPause?: string;
        stop?: string;
        prev?: string;
        next?: string;
    };
    /** 'md' for panels; 'lg' gives 40 px touch targets (mini-players on tablets). */
    size?: 'md' | 'lg';
    /** Disables every transport button (not `children`). */
    disabled?: boolean;
    /** Extra controls after the transport (speed, loop…). */
    children?: ReactNode;
    className?: string;
}
/**
 * Media transport: previous · play/pause/continue · next · stop. Pure
 * presentation — the caller owns the status and the actions. The main
 * button's label follows `status`, and `playMenu` turns it into a
 * SplitButton for "continue how?" choices.
 */
export declare function TransportControls({ status, onPlayPause, onStop, onPrev, onNext, shortcuts, playMenu, tooltips, size, disabled, children, className, }: TransportControlsProps): import("react").JSX.Element;
