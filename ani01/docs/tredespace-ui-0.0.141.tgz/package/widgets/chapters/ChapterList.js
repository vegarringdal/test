import { jsx as _jsx } from "react/jsx-runtime";
import { useRef } from 'react';
import { cn } from '../../lib/cn';
import { ChapterRow } from './ChapterRow';
/**
 * An ordered list of chapters — the parts of a sequence, the steps of a
 * walkthrough: number, title, length, a done / current / upcoming state with
 * an optional progress bar, and hover actions. Arrow keys move between rows,
 * Enter activates; drag-to-reorder when `onReorder` is given.
 */
export function ChapterList({ rows, expanded = null, renderActions, renderDetail, onActivate, onReorder, emptyText = 'Nothing here yet.', className = '', }) {
    const listRef = useRef(null);
    const dragId = useRef(null);
    const handleKeyDown = (e) => {
        if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') {
            return;
        }
        const items = [...(listRef.current?.querySelectorAll('[data-chapter]') ?? [])];
        const at = items.indexOf(document.activeElement instanceof HTMLElement ? document.activeElement : items[0]);
        const next = items[Math.min(items.length - 1, Math.max(0, at + (e.key === 'ArrowDown' ? 1 : -1)))];
        next?.focus();
        e.preventDefault();
    };
    if (rows.length === 0) {
        return _jsx("div", { className: cn('px-2 py-3 text-slate-500 text-xs italic', className), children: emptyText });
    }
    // each row's number among the rows of its depth so far (one pass)
    const counts = new Map();
    const numbers = rows.map((row) => {
        const n = (counts.get(row.depth) ?? 0) + 1;
        counts.set(row.depth, n);
        return n;
    });
    return (_jsx("div", { ref: listRef, role: "list", className: cn('flex flex-col', className), onKeyDown: handleKeyDown, children: rows.map((row, i) => (_jsx(ChapterRow, { row: row, number: numbers[i], expanded: expanded === row.id, actions: renderActions?.(row), detail: expanded === row.id ? renderDetail?.(row) : undefined, onActivate: onActivate, drag: onReorder
                ? {
                    start: () => {
                        dragId.current = row.id;
                    },
                    drop: () => {
                        const from = dragId.current;
                        dragId.current = null;
                        if (from && from !== row.id) {
                            onReorder(from, { beforeId: row.id });
                        }
                    },
                }
                : undefined }, row.id))) }));
}
