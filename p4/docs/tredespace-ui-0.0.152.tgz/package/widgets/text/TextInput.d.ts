import { type KeyboardEvent as ReactKeyboardEvent } from 'react';
import { type LabelledProps } from '../fieldChrome';
export interface TextInputProps extends LabelledProps {
    /** The text. */
    value: string;
    /** Receives the text on every keystroke. */
    onChange: (value: string) => void;
    /** Fires on Enter and blur — for commit-style handling on top of onChange. */
    onCommit?: (value: string) => void;
    /** Runs before the field's own Enter handling — for Escape, arrows, Tab;
     *  call preventDefault() to skip the Enter commit. */
    onKeyDown?: (e: ReactKeyboardEvent<HTMLInputElement>) => void;
    /** Dimmed text while empty. */
    placeholder?: string;
    /** The native input type (default `text`). */
    type?: 'text' | 'password' | 'email' | 'url' | 'search';
    /** Character limit (native maxLength). */
    maxLength?: number;
    /** Browser spell-check (default false). */
    spellCheck?: boolean;
    /** Take focus on mount — for the single field of a dialog. */
    autoFocus?: boolean;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    /** Show the in-field clear (✕) button (default true). */
    clearable?: boolean;
    /** What ✕ does. Default clears the content; provide this to override (e.g.
     *  reset-to-default). When given, the button shows even when empty. */
    onClear?: () => void;
}
/** Single-line text field in the studio look; label on top, to the left, or split (see LabelledProps). */
export declare function TextInput({ value, onChange, onCommit, onKeyDown, placeholder, type, maxLength, spellCheck, autoFocus, tooltip, shortcut, clearable, onClear, disabled, ...labelled }: TextInputProps): import("react").JSX.Element;
