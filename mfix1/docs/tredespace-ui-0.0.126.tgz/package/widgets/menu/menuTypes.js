export const isSeparator = (e) => e != null && e !== false && 'separator' in e;
