import { type ReactNode } from 'react';
import { type TreeDir } from './fileTreeModel';
export type { TreeDir, TreeFile, TreeNode } from './fileTreeModel';
export interface FileTreeProps {
    root: TreeDir;
    selected: Set<string>;
    onSelect: (next: Set<string>) => void;
    onMove?: (paths: string[], dirPath: string) => void;
    onAddFolder?: (parentDirPath: string | null) => void;
    /** Right-click a folder → Rename (dirPath is the row's path). */
    onRenameFolder?: (dirPath: string) => void;
    /** Right-click a folder → Delete (empty folders vanish; files get ungrouped). */
    onDeleteFolder?: (dirPath: string) => void;
    /** Drag a folder row onto another folder (or the root gap). */
    onMoveFolder?: (dirPath: string, targetDirPath: string) => void;
    /** Shown when the tree has no rows. */
    emptyText?: string;
    /** Per-row file icon (locked to 13px by the caller's choice of icon). */
    fileIcon?: ReactNode;
    /** Overrides the default max-h-64 scroll box (e.g. `min-h-0 flex-1` to fill). */
    className?: string;
}
/** Controlled tree: `selected` is a set of file paths owned by the parent.
 *  Optional extras: `onMove` enables dragging the selected files onto a folder
 *  (or the root gap) and `onAddFolder` adds a right-click → New folder menu. */
export declare function FileTree({ root, selected, onSelect, onMove, onAddFolder, onRenameFolder, onDeleteFolder, onMoveFolder, emptyText, fileIcon, className, }: FileTreeProps): import("react").JSX.Element;
