/** The number typed into a field ("1,5" reads as 1.5), or NaN. */
export declare function parseTyped(text: string): number;
/**
 * One step (↑ / ↓, the wheel, − / +) from what the field shows: the typed
 * number while it is being edited, else `value`. While editing, the text
 * follows the step — left alone, the old text would be committed again on
 * blur and undo the step.
 */
export declare function stepField(text: string | null, value: number, delta: number, clamp: (v: number) => number, decimals: number): {
    value: number;
    text: string | null;
};
