import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { cn } from '../lib/cn';
import { Badge } from './Badge';
import { BUTTON_ACTIVE, BUTTON_BASE, BUTTON_ICON_SIZE, BUTTON_MIN_H, BUTTON_SIZE, BUTTON_VARIANT, } from './buttonStyles';
import { Spinner } from './Spinner';
/** The app's button. Read-only mode renders a non-interactive chip that keeps
 *  the same box so buttons and displayed values line up. */
export function Button({ children, icon, onClick, disabled = false, active = false, variant = 'default', size = 'md', readOnly = false, iconOnly = false, wrap = false, grow = false, loading = false, badge, title, tooltip, shortcut, className = '', }) {
    const leading = loading ? _jsx(Spinner, { size: 14 }) : icon;
    const inert = disabled || readOnly || loading;
    // In the ribbon, RibbonButton/RibbonNumber size themselves — this widget is
    // for the rest of the app.
    return (_jsxs("button", { type: "button", disabled: inert, tabIndex: readOnly ? -1 : undefined, "aria-busy": loading || undefined, title: title, "data-tooltip": tooltip, "data-shortcut": shortcut, className: cn(BUTTON_BASE, iconOnly ? BUTTON_ICON_SIZE[size] : BUTTON_SIZE[size], wrap && !iconOnly && cn('h-auto whitespace-normal py-1 text-center leading-tight', BUTTON_MIN_H[size]), grow && 'flex-1', readOnly
            ? 'cursor-default border-slate-700 bg-slate-800 text-slate-300'
            : cn('cursor-pointer', active ? BUTTON_ACTIVE : BUTTON_VARIANT[variant]), 'disabled:cursor-not-allowed', !readOnly && 'disabled:opacity-40', className), onClick: readOnly ? undefined : onClick, children: [leading != null && (_jsx("span", { className: "flex h-3.5 w-3.5 shrink-0 items-center justify-center [&>svg]:h-3.5 [&>svg]:w-3.5", children: leading })), children, badge != null && _jsx(Badge, { className: "ml-0.5", children: badge })] }));
}
