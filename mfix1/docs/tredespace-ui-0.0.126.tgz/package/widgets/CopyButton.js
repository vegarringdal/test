import { jsx as _jsx } from "react/jsx-runtime";
import { IconCheck, IconCopy } from '@tabler/icons-react';
import { useEffect, useRef, useState } from 'react';
import { Button } from './Button';
const CONFIRM_MS = 1200;
/** Copy-to-clipboard with its own "Copied" confirmation — so no panel has to
 *  hand-roll the timer, and a failed copy simply never confirms. */
export function CopyButton({ value, children = 'Copy', copiedLabel = 'Copied', size = 'md', iconOnly = false, disabled = false, tooltip, shortcut, className = '', }) {
    const [copied, setCopied] = useState(false);
    const timer = useRef(null);
    useEffect(() => () => {
        if (timer.current != null) {
            clearTimeout(timer.current);
        }
    }, []);
    const handleClick = () => {
        const text = typeof value === 'function' ? value() : value;
        void navigator.clipboard?.writeText(text).then(() => {
            setCopied(true);
            if (timer.current != null) {
                clearTimeout(timer.current);
            }
            timer.current = setTimeout(() => setCopied(false), CONFIRM_MS);
        });
    };
    return (_jsx(Button, { size: size, iconOnly: iconOnly, disabled: disabled, tooltip: tooltip, shortcut: shortcut, className: className, icon: copied ? _jsx(IconCheck, {}) : _jsx(IconCopy, {}), onClick: handleClick, children: iconOnly ? undefined : copied ? copiedLabel : children }));
}
