/**
 * Where a tooltip bubble sits relative to the element it describes.
 *
 * Pure geometry, no DOM — `Tooltip.ts` measures the rects and applies the
 * result.
 */
/** Which side of the anchor the BUBBLE sits on; the arrow pokes out of the
 *  opposite edge. */
export type TooltipSide = 'top' | 'bottom' | 'left' | 'right';
export type TooltipRect = Readonly<{
    top: number;
    left: number;
    width: number;
    height: number;
}>;
export type TooltipSize = Readonly<{
    width: number;
    height: number;
}>;
export type TooltipPlacement = Readonly<{
    side: TooltipSide;
    left: number;
    top: number;
    /** Arrow offset along the bubble edge facing the anchor, px from the bubble's
     *  top-left corner — down that edge for `left` / `right`, across it otherwise. */
    arrow: number;
}>;
/**
 * Place a bubble of `tip` size against `anchor`.
 *
 * A free-standing anchor gets the bubble below it, flipped above when there is
 * no room, aligned to its left edge and clamped to the viewport.
 *
 * An anchor inside an open menu or listbox passes that container as `container`
 * and the bubble goes BESIDE the whole container instead — right if it fits,
 * else left — vertically centred on the anchor. A bubble laid over the list
 * would hide the entries the pointer is heading for, which is the one thing a
 * menu cannot afford. With no room on either side it falls back to the
 * free-standing behaviour.
 */
export declare function computeTooltipPlacement(anchor: TooltipRect, container: TooltipRect | null, tip: TooltipSize, viewport: TooltipSize): TooltipPlacement;
