export interface ConfirmDialogCoreProps {
    title: string;
    message: string;
    okLabel: string;
    cancelLabel: string;
    /** Called with true for OK, false for Cancel/Escape. */
    onResult: (ok: boolean) => void;
    z?: number;
}
/** Pure OK/Cancel dialog — props only, no store coupling. */
export declare function ConfirmDialogCore({ title, message, okLabel, cancelLabel, onResult, z, }: ConfirmDialogCoreProps): import("react").JSX.Element;
