import { type LabelledProps } from '../fieldChrome';
export interface TextInputProps extends LabelledProps {
    value: string;
    onChange: (value: string) => void;
    /** Fires on Enter and blur — for commit-style handling on top of onChange. */
    onCommit?: (value: string) => void;
    placeholder?: string;
    type?: 'text' | 'password' | 'email' | 'url' | 'search';
    maxLength?: number;
    spellCheck?: boolean;
    /** Show the in-field clear (✕) button (default true). */
    clearable?: boolean;
    /** What ✕ does. Default clears the content; provide this to override (e.g.
     *  reset-to-default). When given, the button shows even when empty. */
    onClear?: () => void;
}
/** Single-line text field in the studio look, label on top or to the left. */
export declare function TextInput({ value, onChange, onCommit, placeholder, type, maxLength, spellCheck, clearable, onClear, disabled, ...labelled }: TextInputProps): import("react").JSX.Element;
