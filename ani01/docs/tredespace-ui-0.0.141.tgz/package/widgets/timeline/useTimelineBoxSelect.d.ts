import { type PointerEvent as ReactPointerEvent } from 'react';
import type { TimelineProps } from './timelineTypes';
export type SelectBox = {
    x0: number;
    y0: number;
    x1: number;
    y1: number;
};
type Deps = Pick<TimelineProps, 'rows' | 'items' | 'points' | 'view' | 'onSeek' | 'onSelect'> & {
    labelWidth: number;
    /** row pitch in px (row height + its 1 px rule) */
    pitch: number;
};
/** Empty lane space: a click seeks (and clears the selection unless Shift /
 *  Ctrl), a drag rubber-band selects items and points. */
export declare function useTimelineBoxSelect(d: Deps): {
    box: SelectBox | null;
    handleLaneDown: (e: ReactPointerEvent<HTMLDivElement>) => void;
};
export {};
