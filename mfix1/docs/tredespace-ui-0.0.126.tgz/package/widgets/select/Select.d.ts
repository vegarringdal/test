import { type LabelledProps } from '../fieldChrome';
export interface SelectOption<T extends string = string> {
    value: T;
    label: string;
    /** Dimmed text after the label — a unit, a path, a shortcut. */
    hint?: string;
    disabled?: boolean;
}
interface BaseProps<T extends string> extends LabelledProps {
    options?: readonly SelectOption<T>[];
    placeholder?: string;
    /** Show a filter box at the top of the list. Implied by loadOptions. */
    searchable?: boolean;
    /**
     * Async search: called (debounced) with the current query; resolve with the
     * matching options or throw/reject to show the error in the list. Replaces
     * local filtering of `options`.
     */
    loadOptions?: (query: string) => Promise<SelectOption<T>[]>;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
}
export interface SingleSelectProps<T extends string = string> extends BaseProps<T> {
    multiple?: false;
    value: T | null;
    /** Receives null when the user clears the selection. */
    onChange: (value: T | null) => void;
}
export interface MultiSelectProps<T extends string = string> extends BaseProps<T> {
    multiple: true;
    value: readonly T[];
    onChange: (value: T[]) => void;
}
export type SelectProps<T extends string = string> = SingleSelectProps<T> | MultiSelectProps<T>;
/**
 * A dropdown in the dock's visual language. Single or multi select, optional
 * search, full keyboard support (arrows / Enter / Escape / type-to-filter).
 * Multi-select keeps the list open and shows checkmarks; the trigger sums up.
 * Generic over the value union, so `onChange` hands back the caller's own
 * string-literal type instead of a bare string.
 */
export declare function Select<T extends string = string>(props: SelectProps<T>): import("react").JSX.Element;
export {};
