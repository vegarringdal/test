/** The minimum a parameter row needs: a key, a label and a type. */
export interface ParamLike {
    key: string;
    label: string;
    type: string;
}
export interface ParamListEditorProps<P extends ParamLike> {
    value: readonly P[];
    onChange: (value: P[]) => void;
    /** the types a parameter can have */
    types: readonly {
        value: P['type'];
        label: string;
    }[];
    /** a fresh parameter of a type (its default value) */
    make: (type: P['type'], key: string) => P;
    disabled?: boolean;
    className?: string;
}
/** An editable list of named, typed parameters: key, label, type; reorder,
 *  remove, add. Keys stay unique (a clash gets a number). */
export declare function ParamListEditor<P extends ParamLike>({ value, onChange, types, make, disabled, className, }: ParamListEditorProps<P>): import("react").JSX.Element;
