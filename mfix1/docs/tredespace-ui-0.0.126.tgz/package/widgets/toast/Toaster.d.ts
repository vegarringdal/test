export interface ToasterProps {
    /** Stacking layer — above the modal layer by default, so a toast raised by a
     *  dialog's own action is still readable. */
    z?: number;
    className?: string;
}
/** The toast stack. Mount once at the app root; everything else calls
 *  {@link toast}. Bottom-right, newest at the bottom, hover to hold. */
export declare function Toaster({ z, className }: ToasterProps): import("react").ReactPortal | null;
