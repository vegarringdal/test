import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconAlertTriangle, IconCircleCheck, IconInfoCircle, IconX } from '@tabler/icons-react';
import { createPortal } from 'react-dom';
import { cn } from '../../lib/cn';
import { TONE_ACCENT, TONE_BLOCK } from '../tone';
import { toast } from './toast.actions';
import { toastState } from './toast.state';
const ICON = {
    neutral: _jsx(IconInfoCircle, { size: 15 }),
    info: _jsx(IconInfoCircle, { size: 15 }),
    success: _jsx(IconCircleCheck, { size: 15 }),
    warning: _jsx(IconAlertTriangle, { size: 15 }),
    danger: _jsx(IconAlertTriangle, { size: 15 }),
};
const DEFAULT_Z = 2600;
function ToastRow({ item }) {
    return (_jsxs("output", { className: cn('pointer-events-auto flex w-72 items-start gap-2 border px-2.5 py-2 text-slate-200 text-xs shadow-black/50 shadow-lg backdrop-blur-sm', TONE_BLOCK[item.tone]), onPointerEnter: () => toast.hold(item.id), onPointerLeave: () => toast.resume(item.id, item.duration), children: [_jsx("span", { className: cn('mt-px shrink-0', TONE_ACCENT[item.tone]), children: ICON[item.tone] }), _jsxs("div", { className: "min-w-0 flex-1 leading-relaxed", children: [item.title != null && _jsx("div", { className: "font-semibold", children: item.title }), _jsx("div", { className: "whitespace-pre-line break-words text-slate-300", children: item.message })] }), _jsx("button", { type: "button", "aria-label": "Dismiss", className: "-mr-1 shrink-0 cursor-pointer text-slate-500 hover:text-slate-200", onClick: () => toast.dismiss(item.id), children: _jsx(IconX, { size: 13 }) })] }));
}
/** The toast stack. Mount once at the app root; everything else calls
 *  {@link toast}. Bottom-right, newest at the bottom, hover to hold. */
export function Toaster({ z = DEFAULT_Z, className = '' }) {
    const { items } = toastState.use();
    if (items.length === 0) {
        return null;
    }
    return createPortal(_jsx("div", { className: cn('pointer-events-none fixed right-3 bottom-3 flex flex-col items-end gap-1.5', className), style: { zIndex: z }, children: items.map((t) => (_jsx(ToastRow, { item: t }, t.id))) }), document.body);
}
