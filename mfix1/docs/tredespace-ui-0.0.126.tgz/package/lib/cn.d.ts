import { type ClassValue } from 'clsx';
/** Merge conditional class lists and resolve conflicting Tailwind utilities
 *  (the later class wins, e.g. `cn('px-2', cond && 'px-4')` → `px-4`).
 *  Biome's `useSortedClasses` sorts the literals inside `cn(...)`. */
export declare function cn(...inputs: ClassValue[]): string;
