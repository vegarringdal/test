import { edgePanStep, xToTime } from './timelineMath';
/**
 * Edge auto-pan for a drag over a time strip: while the pointer is held at or
 * past the strip's left / right edge, the view scrolls every frame — faster
 * the further past (edgePanStep), never left of time 0 — and `onPan` runs, so
 * the drag can follow the time that moved under the pointer. Works in the view
 * the drag started in, panned by this; `onViewChange` gets every step.
 */
export function edgePan(strip, start, onViewChange, onPan) {
    let view = start;
    let x = 0;
    let frame = 0;
    const step = () => {
        const s = strip();
        return edgePanStep(x, s.left, s.right);
    };
    const tick = () => {
        frame = 0;
        const offset = Math.max(0, view.offset + step() / view.pxPerSec);
        if (offset === view.offset) {
            return;
        }
        view = { ...view, offset };
        onViewChange(view);
        onPan();
        frame = requestAnimationFrame(tick);
    };
    return {
        timeAt: (clientX) => {
            const s = strip();
            return Math.max(0, xToTime(Math.min(s.right, Math.max(s.left, clientX)) - s.left, view));
        },
        update: (clientX) => {
            x = clientX;
            if (frame === 0 && step() !== 0) {
                frame = requestAnimationFrame(tick);
            }
        },
        stop: () => {
            cancelAnimationFrame(frame);
            frame = 0;
        },
    };
}
