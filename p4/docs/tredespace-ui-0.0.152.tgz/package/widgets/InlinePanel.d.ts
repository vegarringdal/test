import { type ReactNode } from 'react';
export interface InlinePanelProps {
    /** Header text (uppercased unless `titleUppercase` is false). */
    title: ReactNode;
    /** Uncontrolled initial state (default true). */
    defaultOpen?: boolean;
    /** Controlled state — pair with onToggle. */
    open?: boolean;
    /** The header was clicked: the state it asks for. */
    onToggle?: (open: boolean) => void;
    /** Extra controls rendered at the right end of the header. */
    actions?: ReactNode;
    /** The header text is UPPERCASED by default (the dock-panel look); set
     *  false to show the title exactly as written. */
    titleUppercase?: boolean;
    /** Classes for the header text — merged over the default styling, so
     *  `titleClassName="text-sm normal-case text-sky-300"` restyles it without
     *  replacing the widget. Pass a node as `title` for full control. */
    titleClassName?: string;
    /** Tight header and body padding for stacks of many small sections (a
     *  list of filter editors); pair with `size="sm"` icon-only Buttons in
     *  `actions`. */
    dense?: boolean;
    /** The body — stays mounted while closed (it animates shut). */
    children: ReactNode;
    className?: string;
}
/**
 * A collapsible section for stacking inside panels — the inline cousin of a
 * dock panel. The body animates shut via the grid-rows trick, so no measuring.
 */
export declare function InlinePanel({ title, defaultOpen, open, onToggle, actions, titleUppercase, titleClassName, dense, children, className, }: InlinePanelProps): import("react").JSX.Element;
