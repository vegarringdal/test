import type { PointerEvent as ReactPointerEvent } from 'react';
export type PointerDragDelta = Readonly<{
    /** Movement since the press, in px. */
    dx: number;
    dy: number;
    /** Current pointer position. */
    x: number;
    y: number;
}>;
export interface PointerDragOptions {
    /** Every pointer move once the drag has started. */
    onMove: (d: PointerDragDelta, e: PointerEvent) => void;
    /** Fired once the pointer first passes `threshold` — never when it is 0
     *  (the drag counts as started on the press). */
    onStart?: (d: PointerDragDelta) => void;
    /** `moved` is false for a press that never passed the threshold — a click.
     *  Always true when `threshold` is 0. */
    onEnd?: (moved: boolean) => void;
    /** px of travel before the drag counts as a drag (default 0). */
    threshold?: number;
}
export type PointerDrag = Readonly<{
    /** Attach to onPointerDown of the grab handle. */
    start: (e: ReactPointerEvent<HTMLElement>) => void;
    /** True between `start` and the release. */
    isDragging: () => boolean;
}>;
/**
 * One press-and-drag gesture, on pointer CAPTURE: every later event retargets
 * to the handle, so the drag survives the pointer crossing an iframe, another
 * panel or the window edge — which window-level listeners do not.
 */
export declare function usePointerDrag({ onMove, onStart, onEnd, threshold }: PointerDragOptions): PointerDrag;
