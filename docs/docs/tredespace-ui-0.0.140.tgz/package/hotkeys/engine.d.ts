export type Combo = string;
export type Sequence = Combo[];
export declare const DEFAULT_TIMEOUT = 1500;
export declare class HotkeyParseError extends Error {
}
export declare function suspendHotkeys(): void;
export declare function resumeHotkeys(): void;
/** mods + keys -> canonical combo (mods fixed order, keys sorted). */
export declare function makeCombo(mods: string[], keys: string[]): Combo;
/** Build the combo for the current keydown from the held-set (mods + keys). */
export declare function comboFromHeld(e: KeyboardEvent, held: Set<string>): Combo | null;
/** Prettify one combo: "Alt&F1" -> "ALT&F1", "Digit1" -> "1", "KeyZ" -> "Z".
 *  Display order: modifiers, then multi-char keys (F-keys/named — usually the
 *  held leader), then single chars — so "1&F1" reads "F1&1". */
export declare function formatCombo(c: Combo): string;
/** Whole sequence for display. Steps join " + "; a run of bare lone digits is
 *  concatenated so ["Alt&F1","Digit1","Digit0","Digit1"] -> "ALT&F1 + 101". */
export declare function formatSequence(seq: Sequence): string;
/** Parse the display grammar into a Sequence. Whitespace is insignificant.
 *  Brackets [X]/[A&B] mark held keys that persist into every following combo. */
export declare function parseSequence(str: string): Sequence;
/** Does this string parse? (validation test + record guard.) */
export declare function isValidKeys(str: string): boolean;
export interface Registered {
    id: string;
    sequence: Sequence;
    run: () => void;
    timeout?: number;
    allowInInput?: boolean;
    context?: () => boolean;
}
/** True when every step is F1–F12 (with any modifiers). Pressing such a
 *  sequence inside a text field types nothing, so the field has no claim on
 *  it — the registry uses this as the default for `allowInInput`. */
export declare function isFunctionKeySequence(seq: Sequence): boolean;
/** True when some step carries Ctrl, Alt or Meta, so the sequence cannot be
 *  ordinary typing. Bare letters and digits, Shift chords and the named
 *  editing keys (Tab, Escape, PageUp…) all mean something to a text field
 *  itself; a muted hit on those is the user typing, not a missed shortcut. */
export declare function hasCommandModifier(seq: Sequence): boolean;
export declare class HotkeyEngine {
    private registered;
    private held;
    private modCodes;
    private modChord;
    private pureModHold;
    private progress;
    private pending;
    private pendingMuted;
    private timer;
    private onProgress;
    private onMuted;
    private running;
    setBindings(list: Registered[]): void;
    setProgressListener(fn: (p: Combo[]) => void): void;
    /** Hear about a shortcut the user completed inside a text field where it is
     *  muted (not `allowInInput`): the keys typed as usual and nothing ran. Only
     *  sequences with a command modifier ({@link hasCommandModifier}) are
     *  reported, so ordinary typing never triggers it. */
    setMutedListener(fn: ((r: Registered) => void) | null): void;
    start(): void;
    stop(): void;
    /** A mouse press CONSUMES a pure modifier hold (alt+click camera pivot etc.)
     *  — releasing the modifier afterwards must not emit it as a leader step. */
    private onPointerDown;
    /** Clear in-flight state WITHOUT firing a pending match (blur/stop/rebind). */
    private reset;
    /** Timeout elapsed: a pending shorter match (a prefix of a longer binding,
     *  e.g. F when F+F also exists) now commits since no continuation arrived. */
    private fireTimeout;
    /** Commit the pending exact match (if any) and clear the in-flight state. */
    private commitPending;
    /** Run a completed match — or, when it completed in shadow mode inside a
     *  text field, report it to the muted listener instead. */
    private fire;
    private arm;
    private onBlur;
    private onKeyUp;
    private onKeyDown;
    /** True if `combo` starts, or continues, some registered binding — used to
     *  gate modifier-chord emission so stray taps are ignored. */
    private modChordUsable;
    /** Advance the sequence with one committed combo (from a keydown or a released
     *  modifier chord): match, fire, or arm the pending timeout.
     *
     *  Inside a text field, bindings that are not `allowInInput` still take part
     *  in the matching — as a *shadow*: the key is never claimed (it types as
     *  usual) and a completed sequence goes to the muted listener instead of
     *  running, so the host can tell the user why nothing happened. When any
     *  candidate is live in the field, the step is handled exactly as outside
     *  one and the muted candidates drop out. */
    private feed;
}
/** Capture a sequence for the panel's Record button. Resolves on idle-pause or
 *  Enter, rejects on Escape. Commits a chord (E&R) as one step when its keys
 *  are fully released; sequential taps become separate steps. */
export declare function recordSequence(opts?: {
    idleMs?: number;
}): Promise<Sequence>;
export interface ValidatableDef {
    id: string;
    defaultKeys: string;
}
/** Validate a binding table: every default parses & round-trips, ids unique,
 *  and no two bindings share the exact same keys. Prefixes ARE allowed (a
 *  shorter match fires on timeout, e.g. F alongside F+F). Returns a list of
 *  problems (empty = OK). Pure — used by the boot assertion + unit test. */
export declare function validateBindings(defs: ValidatableDef[]): string[];
