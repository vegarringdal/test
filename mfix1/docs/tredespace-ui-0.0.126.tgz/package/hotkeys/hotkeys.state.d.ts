import { formatSequence, type Sequence } from './engine';
/** Host app: receive a "⌨ label · combo" line whenever a shortcut fires. */
export declare function setHotkeyAnnouncer(fn: ((message: string) => void) | null): void;
/** A shortcut definition (metadata + default + action). Registered at boot. */
export interface HotkeyDef {
    id: string;
    category: string;
    label: string;
    description: string;
    defaultKeys: string;
    run: () => void;
    allowInInput?: boolean;
    timeout?: number;
    context?: () => boolean;
}
interface Override {
    keys?: Sequence;
    allowInInput?: boolean;
    timeout?: number;
}
export declare const hotkeysState: {
    get: () => {
        defs: Record<string, HotkeyDef>;
        order: string[];
        overrides: Record<string, Override>;
    };
    subscribe: (fn: () => void) => () => undefined;
    set(patch: Partial<{
        defs: Record<string, HotkeyDef>;
        order: string[];
        overrides: Record<string, Override>;
    }> | ((prev: {
        defs: Record<string, HotkeyDef>;
        order: string[];
        overrides: Record<string, Override>;
    }) => Partial<{
        defs: Record<string, HotkeyDef>;
        order: string[];
        overrides: Record<string, Override>;
    }>)): void;
    use(): {
        defs: Record<string, HotkeyDef>;
        order: string[];
        overrides: Record<string, Override>;
    };
};
export declare const hotkeysActions: {
    /** Register the whole table once at boot; also starts the engine. */
    register(defs: HotkeyDef[]): void;
    /** Effective (override or default) sequence for one id. */
    sequenceFor(id: string): Sequence | null;
    /** Description text for an id — reused as a tooltip when a control has a
     *  shortcut but no explicit tooltip of its own. */
    describe(id: string): string | null;
    /** True when the shortcut has any user override (drives the Reset button). */
    isCustom(id: string): boolean;
    /** Conflict check: every OTHER id whose effective sequence is EXACTLY `seq`
     *  (prefixes are allowed to coexist — a shorter match fires on timeout). */
    conflictsFor(seq: Sequence, excludeId?: string): string[];
    setOverride(id: string, keys: Sequence): void;
    setAllowInInput(id: string, allow: boolean): void;
    setTimeout(id: string, ms: number): void;
    resetOne(id: string): void;
    /** Persist the overrides under another localStorage key (an app that
     *  namespaces its storage) — the overrides are reloaded from it. */
    setStorageKey(key: string): void;
    resetAll(): void;
    /** Only the deltas from default, keyed by stable id; keys are display strings
     *  so the file is human-readable and portable across versions. */
    exportJson(): string;
    /** Load a keymap. Defensive: unknown ids, unparseable keys and conflicts are
     *  skipped; returns a report so the panel can show what happened. */
    importJson(text: string): {
        applied: string[];
        skipped: string[];
        conflicts: string[];
    };
};
export { formatSequence };
