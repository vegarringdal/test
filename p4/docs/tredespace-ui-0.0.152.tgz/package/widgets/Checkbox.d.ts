import { type ReactNode } from 'react';
export interface CheckboxProps {
    /** Ticked or not. */
    checked: boolean;
    /** Receives the new state on toggle. */
    onChange: (checked: boolean) => void;
    /** Label after the box — the whole label toggles. */
    label?: ReactNode;
    /** Small dimmed note after the label. */
    hint?: string;
    /** Longer explanation, shown behind an info icon after the label (replaces
     *  the inline hint when set) — keeps the row short. */
    info?: ReactNode;
    /** Neither on nor off: some of what this box covers is checked. Purely
     *  visual — `checked` still decides what a click reports. */
    indeterminate?: boolean;
    /** Grey out and block toggling. */
    disabled?: boolean;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    /** Extra classes on the outer row (box + label + info icon). */
    className?: string;
}
/** A single on/off checkbox in the settings-panel visual language — the
 *  standalone sibling of a RadioGroup row. */
export declare function Checkbox({ checked, onChange, label, hint, info, indeterminate, disabled, tooltip, shortcut, className, }: CheckboxProps): import("react").JSX.Element;
