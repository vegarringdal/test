import { type MenuEntry } from './menuTypes';
export type { MenuEntry, MenuItem, MenuSeparator } from './menuTypes';
export interface MenuProps {
    /** Viewport coordinates of the press that opened it; null renders nothing. */
    anchor: Readonly<{
        x: number;
        y: number;
    }> | null;
    items: readonly MenuEntry[];
    onClose: () => void;
    /** Width floor in px (default 160) — keeps a short menu from looking cramped. */
    minWidth?: number;
    className?: string;
}
/**
 * A right-click menu, portaled to the body so panel scroll clipping can never
 * cut it off. It opens at the press position and is then measured and nudged
 * back inside the viewport — no hard-coded size guesses. Closes on any outside
 * press, on Escape, and after a pick.
 */
export declare function Menu({ anchor, items, onClose, minWidth, className }: MenuProps): import("react").ReactPortal | null;
