/** Built-in quick-pick swatches at the bottom of every color picker — 4 rows
 *  of 8. A host app can replace them with setColorSelectSwatchesStore(). */
export declare const DEFAULT_PICKER_SWATCHES: string[];
/** Minimal live-store contract for the default swatch grid (createStore
 *  instances satisfy it structurally). */
export interface ColorSelectSwatchesStore {
    get(): {
        colors: string[];
    };
    /** Returns the unsubscriber. */
    subscribe(cb: () => void): () => void;
}
/** Host app: register a live store whose `colors` become every picker's
 *  default swatch grid (each `swatches` prop still wins). */
export declare function setColorSelectSwatchesStore(store: ColorSelectSwatchesStore | null): void;
export declare const subscribeSwatches: (cb: () => void) => () => void;
export declare const getSwatches: () => string[];
