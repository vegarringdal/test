import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useCallback } from 'react';
import { cn } from '../../lib/cn';
import { ClearButton, fieldCls, Labelled } from '../fieldChrome';
/** Single-line text field in the studio look, label on top or to the left. */
export function TextInput({ value, onChange, onCommit, onKeyDown, placeholder, type = 'text', maxLength, spellCheck = false, autoFocus = false, tooltip, shortcut, clearable = true, onClear, disabled = false, ...labelled }) {
    const showClear = clearable && !disabled && (onClear != null || value.length > 0);
    // A ref callback rather than the autoFocus attribute: it keeps the focus
    // decision out of the markup (and off the a11y lint) and still runs once.
    const focusOnMount = useCallback((el) => {
        if (el != null && autoFocus) {
            el.focus();
            el.select();
        }
    }, [autoFocus]);
    return (_jsx(Labelled, { ...labelled, disabled: disabled, children: _jsxs("div", { className: "relative", "data-tooltip": tooltip, "data-shortcut": shortcut, children: [_jsx("input", { ref: focusOnMount, type: type, value: value, placeholder: placeholder, maxLength: maxLength, spellCheck: spellCheck, disabled: disabled, className: cn(fieldCls, 'h-6 py-0', showClear && 'pr-6'), onChange: (e) => onChange(e.target.value), onBlur: (e) => onCommit?.(e.target.value), onKeyDown: (e) => {
                        onKeyDown?.(e);
                        if (!e.defaultPrevented && e.key === 'Enter') {
                            onCommit?.(e.currentTarget.value);
                        }
                    } }), showClear && (_jsx(ClearButton, { className: "top-1/2 right-0.5 -translate-y-1/2", onClick: () => (onClear ? onClear() : onChange('')) }))] }) }));
}
