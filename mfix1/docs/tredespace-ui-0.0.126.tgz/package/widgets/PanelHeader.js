import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { cn } from '../lib/cn';
const SHELL = {
    label: 'border-slate-800 border-b pb-1',
    title: 'border-slate-800 border-b p-1.5',
    band: 'border-slate-700 border-b bg-slate-800/60 px-2 py-1.5',
};
const TITLE = {
    label: 'text-slate-400',
    title: 'font-medium text-slate-200',
    band: 'text-slate-300',
};
/** The fixed top strip of a panel: title, dim asides, actions. Pinned by the
 *  caller (`shrink-0` is built in), so only the content below it scrolls. */
export function PanelHeader({ title, aside, actions, variant = 'label', className = '' }) {
    return (_jsxs("div", { className: cn('flex shrink-0 items-center gap-2 text-slate-400 text-xs', SHELL[variant], className), children: [_jsx("span", { className: cn('min-w-0 flex-1 truncate', TITLE[variant]), children: title }), aside, actions] }));
}
