import type { TimelineView } from './timelineTypes';
import type { SelectBox } from './useTimelineBoxSelect';
type Props = Readonly<{
    view: TimelineView;
    labelWidth: number;
    playhead: number;
    minHeight: number;
    dimOutside?: {
        from: number;
        to: number;
    } | null;
    endMark?: number | null;
    box: SelectBox | null;
}>;
/** Over the lanes: the dimmed outside of a focus window, the end mark, the
 *  playhead line and the rubber-band box. */
export declare function TimelineOverlays({ view, labelWidth, playhead, minHeight, dimOutside, endMark, box }: Props): import("react").JSX.Element;
export {};
