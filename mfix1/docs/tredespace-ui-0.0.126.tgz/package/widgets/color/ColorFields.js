import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { hexToRgb, isHex, rgbToHsv } from './colorConversions';
const inputCls = 'w-full min-w-0 border border-slate-700 bg-slate-950 px-1 py-0.5 text-center font-mono text-xs text-slate-200 outline-none focus:border-blue-400';
/** Hex + R/G/B entry row; text state stays local while a field is edited so
 *  half-typed values don't fight the live color. */
export function ColorFields({ hex, rgb, apply }) {
    const [hexText, setHexText] = useState(null); // non-null while editing
    const [rgbText, setRgbText] = useState({});
    const commitHex = () => {
        if (hexText != null) {
            const h = hexText.startsWith('#') ? hexText : `#${hexText}`;
            if (isHex(h)) {
                apply(rgbToHsv(hexToRgb(h)));
            }
        }
        setHexText(null);
    };
    const commitRgb = (k) => {
        const t = rgbText[k];
        if (t != null) {
            const n = parseInt(t, 10);
            if (!Number.isNaN(n)) {
                apply(rgbToHsv({ ...rgb, [k]: Math.min(255, Math.max(0, n)) }));
            }
        }
        setRgbText((s) => ({ ...s, [k]: undefined }));
    };
    return (_jsxs("div", { className: "mt-2 grid grid-cols-[1.4fr_1fr_1fr_1fr] gap-1", children: [_jsx("input", { value: hexText ?? hex, spellCheck: false, className: inputCls, onChange: (e) => setHexText(e.target.value), onBlur: commitHex, onKeyDown: (e) => e.key === 'Enter' && commitHex() }), ['r', 'g', 'b'].map((k) => (_jsx("input", { value: rgbText[k] ?? Math.round(rgb[k]), inputMode: "numeric", className: inputCls, onChange: (e) => setRgbText((s) => ({ ...s, [k]: e.target.value })), onBlur: () => commitRgb(k), onKeyDown: (e) => e.key === 'Enter' && commitRgb(k) }, k))), _jsx("span", { className: "text-center text-slate-400 text-xs", children: "Hex" }), _jsx("span", { className: "text-center text-slate-400 text-xs", children: "R" }), _jsx("span", { className: "text-center text-slate-400 text-xs", children: "G" }), _jsx("span", { className: "text-center text-slate-400 text-xs", children: "B" })] }));
}
