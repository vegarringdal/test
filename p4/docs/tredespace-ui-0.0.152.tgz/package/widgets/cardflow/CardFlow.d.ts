import { type ReactNode } from 'react';
export interface CardFlowConnector {
    /** id of the card on the left */
    from: string;
    /** id of the card right after it */
    to: string;
    /** chip text, e.g. "then", "together", "then +1s" */
    label: string;
    /** a branch (runs together with `from`) — drawn as a dashed chip */
    branch?: boolean;
}
export interface CardFlowProps<T> {
    /** the cards in order — left to right, wrapping */
    cards: readonly T[];
    /** a card's stable id — what the callbacks and `connectors` use */
    getId: (card: T) => string;
    /** draws one card; CardFlow wraps it in the focusable, draggable cell */
    renderCard: (card: T, state: {
        selected: boolean;
        dragging: boolean;
    }) => ReactNode;
    /** chips between consecutive cards (looked up by from → to); a pair
     *  without one shows a plain "then" */
    connectors: readonly CardFlowConnector[];
    /** id of the selected card, or null */
    selected: string | null;
    /** a card was clicked */
    onSelect: (id: string) => void;
    /** double-click or Enter on a card */
    onOpen: (id: string) => void;
    /** a card dropped before the card at `toIndex` — an index into `cards` as
     *  it is now, the dragged card included (moving right, it ends up at
     *  `toIndex - 1`) — or on the trailing + (`toIndex` = `cards.length`) */
    onReorder: (id: string, toIndex: number) => void;
    /** the + between two cards or the trailing + (index = where the new card goes) */
    onInsert: (index: number) => void;
    /** given: a card's lower 30 % is a drop zone — a card dropped there ("together") */
    onDropOnto?: (id: string, target: string, zone: 'bottom') => void;
    /** a connector chip was clicked; `at` = the click's viewport position (a
     *  Menu anchor for your link popover) */
    onConnectorClick?: (from: string, to: string, at: {
        x: number;
        y: number;
    }) => void;
    className?: string;
}
/**
 * A flow of cards — a storyboard: cards left to right, wrapping to rows,
 * with a chip between consecutive cards naming how they connect. Drag a card
 * to reorder, drop it on another card's lower edge to join it, + inserts.
 */
export declare function CardFlow<T>({ cards, getId, renderCard, connectors, selected, onSelect, onOpen, onReorder, onInsert, onDropOnto, onConnectorClick, className, }: CardFlowProps<T>): import("react").JSX.Element;
