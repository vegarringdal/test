/** Semantic colour of a feedback surface. `neutral` is the un-tinted default. */
export type Tone = 'neutral' | 'info' | 'success' | 'warning' | 'danger';
/** Filled chip palette (Badge, Button badge). */
export declare const TONE_CHIP: Readonly<Record<Tone, string>>;
/** Tinted block palette (InfoBox, Toast). */
export declare const TONE_BLOCK: Readonly<Record<Tone, string>>;
/** Icon / accent colour matching a block. */
export declare const TONE_ACCENT: Readonly<Record<Tone, string>>;
