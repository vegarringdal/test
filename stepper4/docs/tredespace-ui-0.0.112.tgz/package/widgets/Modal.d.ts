import type { ReactNode } from 'react';
export interface ModalProps {
    z: number;
    children: ReactNode;
    onKeyDown?: (e: React.KeyboardEvent) => void;
}
/** Shared modal shell: dimmed backdrop + centred window at the given layer. */
export declare function Modal({ z, children, onKeyDown }: ModalProps): import("react").ReactPortal;
export interface TitleBarProps {
    icon: ReactNode;
    children: ReactNode;
}
export declare function TitleBar({ icon, children }: TitleBarProps): import("react").JSX.Element;
