import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconPhotoPlus, IconX } from '@tabler/icons-react';
import { useState } from 'react';
import { cn } from '../../lib/cn';
import { Button } from '../Button';
import { Labelled } from '../fieldChrome';
import { useFilePicker } from '../useFilePicker';
const DEFAULT_ACCEPT = 'image/png,image/jpeg,image/webp,image/svg+xml';
/** Read a file as a data: URI. */
function readDataUrl(file) {
    return new Promise((resolve, reject) => {
        const fr = new FileReader();
        fr.onload = () => (typeof fr.result === 'string' ? resolve(fr.result) : reject(new Error('unreadable')));
        fr.onerror = () => reject(fr.error ?? new Error('unreadable'));
        fr.readAsDataURL(file);
    });
}
/**
 * Pick an image from disk into a `data:` URI (never a URL — the value stays
 * self-contained, so it can be saved in a file and drawn without network
 * access). Shows a thumbnail with a clear button; files over `maxBytes` are
 * refused with an inline note.
 */
export function ImagePicker({ value, onChange, maxBytes, accept = DEFAULT_ACCEPT, tooltip, disabled = false, className = '', ...labelled }) {
    const [error, setError] = useState(null);
    const picker = useFilePicker(accept, (file) => {
        if (file.size > maxBytes) {
            setError(`Too large (${Math.round(file.size / 1024)} KB; at most ${Math.round(maxBytes / 1024)} KB).`);
            return;
        }
        setError(null);
        readDataUrl(file).then(onChange, () => setError('Could not read that file.'));
    });
    return (_jsx(Labelled, { ...labelled, disabled: disabled, className: className, children: _jsxs("div", { className: "flex min-w-0 items-center gap-1.5", "data-tooltip": tooltip, children: [picker.element, _jsx("div", { className: cn('flex h-10 w-14 shrink-0 items-center justify-center border border-slate-700 bg-slate-900', !value && 'text-slate-600'), children: value ? (_jsx("img", { src: value, alt: "", className: "max-h-full max-w-full object-contain" })) : (_jsx(IconPhotoPlus, { size: 16 })) }), _jsx(Button, { size: "sm", disabled: disabled, onClick: picker.open, children: value ? 'Replace…' : 'Choose…' }), value && (_jsx(Button, { size: "sm", iconOnly: true, variant: "ghost", icon: _jsx(IconX, {}), tooltip: "No image", disabled: disabled, onClick: () => onChange(null) })), error && _jsx("span", { className: "min-w-0 truncate text-[11px] text-red-300", children: error })] }) }));
}
