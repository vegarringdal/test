import type { ReactNode } from 'react';
export interface TreeFile {
    kind: 'file';
    name: string;
    path: string;
    /** Present for scanned directories; virtual trees carry ids instead. */
    handle?: FileSystemFileHandle;
    /** Optional dim suffix (file size etc). */
    note?: string;
}
export interface TreeDir {
    kind: 'dir';
    name: string;
    path: string;
    children: TreeNode[];
    /** 'section' renders as a dimmed full-width category band (still
     *  collapsible) — grouping chrome rather than content, e.g. a store. */
    variant?: 'section';
    /** Replaces the default folder icon for this dir. */
    icon?: ReactNode;
}
export type TreeNode = TreeFile | TreeDir;
export interface TreeRow {
    node: TreeNode;
    depth: number;
}
/** All files in a subtree, depth-first. */
export declare function filesUnder(node: TreeNode): TreeFile[];
/** Flatten the visible rows (children of `root`, skipping collapsed dirs
 *  unless `expandAll` overrides — e.g. while a search filter is active). */
/** Every directory path under `root` (root itself excluded) — the set that
 *  "collapse all" stores. */
export declare function dirPaths(root: TreeDir): string[];
export declare function visibleRows(root: TreeDir, collapsed: ReadonlySet<string>, expandAll?: boolean): TreeRow[];
