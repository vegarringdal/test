/** The minimum a parameter row needs: a key, a label and a type. */
export interface ParamLike {
    /** Unique key — used as {{key}} in texts; typed keys are sanitised to letters, digits and `_`. */
    key: string;
    /** Caption shown in the value form. */
    label: string;
    /** One of the editor's `types` values. */
    type: string;
}
export interface ParamListEditorProps<P extends ParamLike> {
    /** The parameters, in order. */
    value: readonly P[];
    /** Receives the whole new list after any edit. */
    onChange: (value: P[]) => void;
    /** The types a parameter can have; Add uses the first (and is off while there are none). */
    types: readonly {
        value: P['type'];
        label: string;
    }[];
    /** A fresh parameter of a type (its default value) — for Add and on a retype, which keeps the label. */
    make: (type: P['type'], key: string) => P;
    /** Grey out every row and the Add button. */
    disabled?: boolean;
    /** Extra classes on the outer element. */
    className?: string;
}
/** An editable list of named, typed parameters: key, label, type; reorder,
 *  remove, add. Keys stay unique (a clash gets a number) and clean (anything
 *  but letters, digits and `_` becomes `_`). */
export declare function ParamListEditor<P extends ParamLike>({ value, onChange, types, make, disabled, className, }: ParamListEditorProps<P>): import("react").JSX.Element;
