import { type ReactNode } from 'react';
export interface TemplateTextInputProps {
    /** text with {{placeholders}} */
    value: string;
    onChange: (value: string) => void;
    /** placeholders offered by the {} menu and highlighted when known */
    placeholders: readonly {
        key: string;
        label: string;
    }[];
    /** a textarea instead of one line */
    multiline?: boolean;
    label?: ReactNode;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
}
/**
 * A text field for templates: {{key}} placeholders are highlighted (known
 * ones blue, unknown ones red) under a transparent editor, and the {} button
 * inserts one at the caret.
 */
export declare function TemplateTextInput({ value, onChange, placeholders, multiline, label, placeholder, disabled, className, }: TemplateTextInputProps): import("react").JSX.Element;
