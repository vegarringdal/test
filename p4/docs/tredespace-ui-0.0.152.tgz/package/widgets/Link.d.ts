import type { ReactNode } from 'react';
export interface LinkProps {
    /** Target URL. */
    href: string;
    /** Link text. */
    children: ReactNode;
    /** Open in a new tab (default true) — `rel` is set with it. */
    external?: boolean;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Extra classes on the anchor. */
    className?: string;
}
/** One look for every out-of-app link. External links (the default) open in a
 *  new tab with `noreferrer`, so a viewer window can never reach back. */
export declare function Link({ href, children, external, tooltip, className }: LinkProps): import("react").JSX.Element;
