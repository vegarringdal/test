/** The label column's right edge as a drag handle (Timeline's
 *  `onLabelWidthChange`): drag to widen or narrow the names; focused, ←/→
 *  step it. */
export declare function LabelWidthHandle({ width, onChange }: {
    width: number;
    onChange: (px: number) => void;
}): import("react").JSX.Element;
