import type { ReactNode } from 'react';
import { type ButtonSize } from './buttonStyles';
export interface SegmentedOption<T extends string = string> {
    value: T;
    /** Omit for an icon-only segment. */
    label?: ReactNode;
    /** Leading icon (locked to 14×14). */
    icon?: ReactNode;
    /** Styled tooltip (data-tooltip). */
    tooltip?: string;
    /** Hotkey id (data-shortcut) — the tooltip gets a combo footer. */
    shortcut?: string;
    disabled?: boolean;
}
export interface SegmentedControlProps<T extends string = string> {
    value: T;
    options: readonly SegmentedOption<T>[];
    onChange: (value: T) => void;
    /** Height/padding scale — matches {@link Button}. */
    size?: ButtonSize;
    /** Split the row evenly between the segments instead of hugging the labels. */
    grow?: boolean;
    /** Fill the parent's height exactly (a ribbon slot) instead of the size's
     *  fixed height. */
    fill?: boolean;
    disabled?: boolean;
    className?: string;
}
/**
 * A run of joined buttons for one exclusive choice — the horizontal sibling of
 * RadioGroup, for a mode switch that belongs in a toolbar rather than a form.
 * Segments share their borders, so the group reads as one control.
 */
export declare function SegmentedControl<T extends string = string>({ value, options, onChange, size, grow, fill, disabled, className, }: SegmentedControlProps<T>): import("react").JSX.Element;
