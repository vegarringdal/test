import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { cn } from '../lib/cn';
/** The one way a list or panel says it has nothing to show. Replaces the
 *  hand-rolled dim paragraphs so the wording sits in one visual language. */
export function EmptyState({ children, icon, layout = 'note', className = '' }) {
    if (layout === 'center') {
        return (_jsxs("div", { className: cn('flex h-full min-h-0 flex-1 flex-col items-center justify-center gap-2 p-4 text-center text-slate-500 text-xs', className), children: [icon != null && _jsx("span", { className: "text-slate-600", children: icon }), _jsx("span", { className: "max-w-[40ch] leading-relaxed", children: children })] }));
    }
    return _jsx("p", { className: cn('m-0 mt-3.5 text-slate-400 text-xs', className), children: children });
}
