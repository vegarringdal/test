export interface SqlCodeEditorProps {
    value: string;
    onChange: (v: string) => void;
    /** Ctrl/Cmd+Enter inside the editor. */
    onRun?: () => void;
    /** Current caret selection (start/end char offsets) — lets the host run only
     *  the highlighted text. */
    onSelect?: (start: number, end: number) => void;
    /** Show a drag handle so the user can resize the editor's height (the
     *  caller sets the starting height via className, e.g. "h-32"). */
    resizable?: boolean;
    className?: string;
}
/** The editor. Scroll position is mirrored from the textarea onto the
 *  highlight layer and the gutter, so all three stay glued together. */
export declare function SqlCodeEditor({ value, onChange, onRun, onSelect, resizable, className }: SqlCodeEditorProps): import("react").JSX.Element;
