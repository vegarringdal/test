import type { ReactNode } from 'react';
export interface BorderValue {
    width: number;
    color: string;
    style: 'solid' | 'dashed';
}
export interface BorderInputProps {
    /** null = no border */
    value: BorderValue | null;
    onChange: (value: BorderValue | null) => void;
    label?: ReactNode;
    /** colours picked here may be theme tokens ("$accent") — shown as text */
    disabled?: boolean;
    className?: string;
}
/** A border: on/off, width, colour, solid or dashed. */
export declare function BorderInput({ value, onChange, label, disabled, className }: BorderInputProps): import("react").JSX.Element;
