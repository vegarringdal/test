import { type ReactNode } from 'react';
export interface ChapterListRow {
    /** Stable identity (what the callbacks hand back). */
    id: string;
    /** Nesting level, 0 = top. */
    depth: number;
    title: string;
    /** Dim line under the title (shown for the expanded row). */
    subtitle?: string;
    /** Right-aligned length / note, e.g. "4.0s". */
    duration?: string;
    /** done = muted with a check, current = accent edge, upcoming = plain. */
    status: 'done' | 'current' | 'upcoming';
    /** 0..1 progress bar under the current row (null/absent = none). */
    progress?: number | null;
    /** Warning badge (continuity problems). */
    warning?: boolean;
    /** Small dim note after the duration (e.g. "paused"). */
    note?: string;
    /** A chapter title shown above this row (the first row of a group). */
    heading?: string;
}
export interface ChapterListProps {
    rows: readonly ChapterListRow[];
    /** The row that shows its subtitle + detail. */
    expanded?: string | null;
    /** Per-row action buttons, shown on hover / focus (play, loop…). */
    renderActions?: (row: ChapterListRow) => ReactNode;
    /** Extra content under the expanded row. */
    renderDetail?: (row: ChapterListRow) => ReactNode;
    /** Click or Enter on a row. */
    onActivate: (id: string) => void;
    /** Drag a row onto another to reorder (same parent); omit to disable. */
    onReorder?: (id: string, to: {
        beforeId: string;
    }) => void;
    /** Shown when there are no rows. */
    emptyText?: ReactNode;
    className?: string;
}
/**
 * An ordered list of chapters — the parts of a sequence, the steps of a
 * walkthrough: number, title, length, a done / current / upcoming state with
 * an optional progress bar, and hover actions. Arrow keys move between rows,
 * Enter activates; drag-to-reorder when `onReorder` is given.
 */
export declare function ChapterList({ rows, expanded, renderActions, renderDetail, onActivate, onReorder, emptyText, className, }: ChapterListProps): import("react").JSX.Element;
