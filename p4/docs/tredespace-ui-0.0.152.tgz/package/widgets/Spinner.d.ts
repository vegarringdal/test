export interface SpinnerProps {
    /** Diameter in px (default 14). */
    size?: number;
    /** Accessible label — also the hover tooltip (default "Loading"). */
    label?: string;
    /** Extra classes on the svg (e.g. a text colour — the arc uses currentColor). */
    className?: string;
}
/** The one indeterminate busy indicator: a spinning arc that inherits the
 *  current text colour, so it works inside a Button as well as on a panel. */
export declare function Spinner({ size, label, className }: SpinnerProps): import("react").JSX.Element;
export interface ProgressBarProps {
    /** 0..1; null/undefined renders an indeterminate sweep. */
    value?: number | null;
    /** Bar height in px (default 6). */
    height?: number;
    /** Extra classes on the track (full width by default). */
    className?: string;
}
/** A determinate (or indeterminate) progress bar — the LoadingDialog bar, made
 *  available on its own for inline progress inside a panel. */
export declare function ProgressBar({ value, height, className }: ProgressBarProps): import("react").JSX.Element;
