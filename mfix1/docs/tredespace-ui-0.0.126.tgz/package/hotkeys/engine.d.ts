export type Combo = string;
export type Sequence = Combo[];
export declare const DEFAULT_TIMEOUT = 1500;
export declare class HotkeyParseError extends Error {
}
export declare function suspendHotkeys(): void;
export declare function resumeHotkeys(): void;
/** mods + keys -> canonical combo (mods fixed order, keys sorted). */
export declare function makeCombo(mods: string[], keys: string[]): Combo;
/** Build the combo for the current keydown from the held-set (mods + keys). */
export declare function comboFromHeld(e: KeyboardEvent, held: Set<string>): Combo | null;
/** Prettify one combo: "Alt&F1" -> "ALT&F1", "Digit1" -> "1", "KeyZ" -> "Z".
 *  Display order: modifiers, then multi-char keys (F-keys/named — usually the
 *  held leader), then single chars — so "1&F1" reads "F1&1". */
export declare function formatCombo(c: Combo): string;
/** Whole sequence for display. Steps join " + "; a run of bare lone digits is
 *  concatenated so ["Alt&F1","Digit1","Digit0","Digit1"] -> "ALT&F1 + 101". */
export declare function formatSequence(seq: Sequence): string;
/** Parse the display grammar into a Sequence. Whitespace is insignificant.
 *  Brackets [X]/[A&B] mark held keys that persist into every following combo. */
export declare function parseSequence(str: string): Sequence;
/** Does this string parse? (validation test + record guard.) */
export declare function isValidKeys(str: string): boolean;
export interface Registered {
    id: string;
    sequence: Sequence;
    run: () => void;
    timeout?: number;
    allowInInput?: boolean;
    context?: () => boolean;
}
export declare class HotkeyEngine {
    private registered;
    private held;
    private modCodes;
    private modChord;
    private pureModHold;
    private progress;
    private pending;
    private timer;
    private onProgress;
    private running;
    setBindings(list: Registered[]): void;
    setProgressListener(fn: (p: Combo[]) => void): void;
    start(): void;
    stop(): void;
    /** A mouse press CONSUMES a pure modifier hold (alt+click camera pivot etc.)
     *  — releasing the modifier afterwards must not emit it as a leader step. */
    private onPointerDown;
    /** Clear in-flight state WITHOUT firing a pending match (blur/stop/rebind). */
    private reset;
    /** Timeout elapsed: a pending shorter match (a prefix of a longer binding,
     *  e.g. F when F+F also exists) now commits since no continuation arrived. */
    private fireTimeout;
    private arm;
    private onBlur;
    private onKeyUp;
    private onKeyDown;
    /** True if `combo` starts, or continues, some registered binding — used to
     *  gate modifier-chord emission so stray taps are ignored. */
    private modChordUsable;
    /** Advance the sequence with one committed combo (from a keydown or a released
     *  modifier chord): match, fire, or arm the pending timeout. */
    private feed;
}
/** Capture a sequence for the panel's Record button. Resolves on idle-pause or
 *  Enter, rejects on Escape. Commits a chord (E&R) as one step when its keys
 *  are fully released; sequential taps become separate steps. */
export declare function recordSequence(opts?: {
    idleMs?: number;
}): Promise<Sequence>;
export interface ValidatableDef {
    id: string;
    defaultKeys: string;
}
/** Validate a binding table: every default parses & round-trips, ids unique,
 *  and no two bindings share the exact same keys. Prefixes ARE allowed (a
 *  shorter match fires on timeout, e.g. F alongside F+F). Returns a list of
 *  problems (empty = OK). Pure — used by the boot assertion + unit test. */
export declare function validateBindings(defs: ValidatableDef[]): string[];
