export interface ErrorDialogCoreProps {
    /** Title-bar text. */
    title: string;
    /** What went wrong (newlines kept). */
    message: string;
    /** OK, Escape, the backdrop and the ✕ all call this. */
    onDismiss: () => void;
    /** Stacking layer (default 2010 — above a dialog that failed). */
    z?: number;
}
/** Pure error dialog — props only, no store coupling. */
export declare function ErrorDialogCore({ title, message, onDismiss, z }: ErrorDialogCoreProps): import("react").JSX.Element;
