import { type ReactNode } from 'react';
export interface VerticalTab {
    /** Tab id — what `value` / `onChange` use. */
    id: string;
    /** Omit for an icon-only tab — pair it with `tooltip`. */
    label?: string;
    /** Leading icon (16×16); the strip becomes an icon rail when no tab has a label. */
    icon?: ReactNode;
    /** Styled tooltip (data-tooltip); supports "\n" for multiple lines. */
    tooltip?: string;
    /** The tab's page — mounted only while the tab is active. */
    content: ReactNode;
}
export interface VerticalTabsProps {
    /** Tabs in strip order; only the active one's `content` is mounted. */
    tabs: VerticalTab[];
    /** Controlled active tab — pair with onChange. */
    value?: string;
    /** Uncontrolled initial tab (default: the first). */
    defaultValue?: string;
    /** A tab was clicked. */
    onChange?: (id: string) => void;
    /** Which side the strip sits on (default left). */
    side?: 'left' | 'right';
    className?: string;
}
/** A tab strip that runs down the side instead of across the top. */
export declare function VerticalTabs({ tabs, value, defaultValue, onChange, side, className, }: VerticalTabsProps): import("react").JSX.Element;
