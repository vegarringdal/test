import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconArrowDown, IconArrowUp, IconPlus, IconX } from '@tabler/icons-react';
import { Button } from '../Button';
import { Select } from '../select/Select';
import { TextInput } from '../text/TextField';
/** An editable list of named, typed parameters: key, label, type; reorder,
 *  remove, add. Keys stay unique (a clash gets a number). */
export function ParamListEditor({ value, onChange, types, make, disabled = false, className = '', }) {
    const set = (i, p) => onChange(value.map((x, k) => (k === i ? p : x)));
    const uniqueKey = (base, except = -1) => {
        let key = base.replace(/[^\w]/g, '_') || 'param';
        let n = 2;
        while (value.some((x, k) => k !== except && x.key === key)) {
            key = `${base}${n++}`;
        }
        return key;
    };
    const move = (i, d) => {
        const j = i + d;
        if (j < 0 || j >= value.length) {
            return;
        }
        const next = [...value];
        [next[i], next[j]] = [next[j], next[i]];
        onChange(next);
    };
    return (_jsxs("div", { className: className, children: [value.map((p, i) => (_jsxs("div", { className: "mb-1 grid grid-cols-[1fr_1fr_auto] items-center gap-1", children: [_jsx(TextInput, { value: p.key, clearable: false, disabled: disabled, tooltip: "Key \u2014 used as {{key}} in texts", onChange: (k) => set(i, { ...p, key: uniqueKey(k, i) }) }), _jsx(TextInput, { value: p.label, clearable: false, disabled: disabled, tooltip: "Label shown in the value form", onChange: (label) => set(i, { ...p, label }) }), _jsxs("div", { className: "flex items-center", children: [_jsx(Select, { className: "w-24", value: p.type, options: types, clearable: false, disabled: disabled, onChange: (t) => t && set(i, { ...make(t, p.key), label: p.label }) }), _jsx(Button, { iconOnly: true, size: "sm", variant: "ghost", icon: _jsx(IconArrowUp, {}), tooltip: "Up", disabled: disabled, onClick: () => move(i, -1) }), _jsx(Button, { iconOnly: true, size: "sm", variant: "ghost", icon: _jsx(IconArrowDown, {}), tooltip: "Down", disabled: disabled, onClick: () => move(i, 1) }), _jsx(Button, { iconOnly: true, size: "sm", variant: "ghost", icon: _jsx(IconX, {}), tooltip: "Remove", disabled: disabled, onClick: () => onChange(value.filter((_, k) => k !== i)) })] })] }, `${p.key}-${i}`))), _jsx(Button, { size: "sm", icon: _jsx(IconPlus, {}), disabled: disabled, onClick: () => onChange([...value, make(types[0].value, uniqueKey('param'))]), children: "Add parameter" })] }));
}
