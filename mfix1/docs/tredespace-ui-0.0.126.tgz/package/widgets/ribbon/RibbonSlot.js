import { jsx as _jsx } from "react/jsx-runtime";
import { RIBBON_HEIGHT } from './ribbonSizes';
/**
 * Puts any content into the ribbon's sizing system — the escape hatch for
 * inputs, selects, whatever. The content is vertically centred in its slot.
 */
export function RibbonSlot({ size = 'medium', children, className = '', }) {
    return _jsx("div", { className: `flex min-w-16 flex-col justify-center ${RIBBON_HEIGHT[size]} ${className}`, children: children });
}
