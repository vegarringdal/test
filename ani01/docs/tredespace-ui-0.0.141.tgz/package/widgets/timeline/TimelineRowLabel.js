import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconChevronDown, IconChevronRight } from '@tabler/icons-react';
/** The label cell of a row: twisty, tint swatch, name. */
export function TimelineRowLabel({ row, width, height, onToggle, onOpen, onMenu }) {
    return (_jsxs("div", { className: "flex shrink-0 items-center gap-1 truncate border-slate-700 border-r pr-1 text-[11px] text-slate-300", style: { width, height, paddingLeft: 4 + row.depth * 12 }, onDoubleClick: () => onOpen(row.id), onContextMenu: (e) => onMenu(e, row.id), onPointerDown: (e) => e.stopPropagation(), children: [row.collapsible ? (_jsx("button", { type: "button", className: "cursor-pointer text-slate-500 hover:text-sky-300", onClick: () => onToggle?.(row.id), children: row.collapsed ? _jsx(IconChevronRight, { size: 11 }) : _jsx(IconChevronDown, { size: 11 }) })) : (_jsx("span", { className: "w-[11px]" })), row.tint && _jsx("span", { className: "h-2.5 w-1 shrink-0", style: { background: row.tint } }), _jsx("span", { className: "min-w-0 truncate", children: row.label })] }));
}
