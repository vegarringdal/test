import type { ReactNode } from 'react';
export interface IconSelectProps {
    /** The picked icon's `name`. */
    value: string;
    /** The fixed icon set to choose from; `label` is the tooltip (default: `name`). */
    icons: readonly {
        name: string;
        label?: string;
        node: ReactNode;
    }[];
    /** Receives the clicked icon's `name`. */
    onChange: (value: string) => void;
    /** Grey out every icon. */
    disabled?: boolean;
    /** Extra classes on the wrapping row. */
    className?: string;
}
/** Pick one icon from a fixed set — a compact grid of glyph buttons. */
export declare function IconSelect({ value, icons, onChange, disabled, className }: IconSelectProps): import("react").JSX.Element;
