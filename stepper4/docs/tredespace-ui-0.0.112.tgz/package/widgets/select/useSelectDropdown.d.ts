import { type RefObject } from 'react';
import { type PopoverPos } from '../usePopoverAnchor';
import type { SelectOption } from './Select';
export type SelectDropdown = Readonly<{
    open: boolean;
    setOpen: (o: boolean | ((o: boolean) => boolean)) => void;
    query: string;
    setQuery: (q: string) => void;
    hot: number;
    setHot: (h: number | ((h: number) => number)) => void;
    filtered: SelectOption[];
    asyncState: {
        options: SelectOption[];
        loading: boolean;
        error: string | null;
    };
    pos: PopoverPos;
    rootRef: RefObject<HTMLDivElement | null>;
    popRef: RefObject<HTMLDivElement | null>;
    searchRef: RefObject<HTMLInputElement | null>;
    listRef: RefObject<HTMLDivElement | null>;
    known: (v: string) => SelectOption;
}>;
/** Open/filter/anchor state for the Select popover: debounced async search,
 *  local filtering, outside-close, and viewport-anchored placement (the
 *  anchoring itself lives in the shared usePopoverAnchor). */
export declare function useSelectDropdown(options: SelectOption[], loadOptions: ((query: string) => Promise<SelectOption[]>) | undefined, searchable: boolean, selected: ReadonlySet<string>): SelectDropdown;
