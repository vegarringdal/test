import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { IconAlertTriangle, IconCheck } from '@tabler/icons-react';
import { cn } from '../../lib/cn';
import { ProgressBar } from '../Spinner';
/** One chapter: number/check, title, duration, hover actions, and — when
 *  expanded — the subtitle, progress and detail underneath. */
export function ChapterRow({ row, number, expanded, actions, detail, onActivate, drag }) {
    const done = row.status === 'done';
    const current = row.status === 'current';
    return (_jsxs("div", { role: "listitem", className: cn('group border-transparent border-l-2', current && 'border-sky-400 bg-slate-800/60', drag && 'cursor-grab'), draggable: drag !== undefined, onDragStart: drag?.start, onDragOver: (e) => drag && e.preventDefault(), onDrop: drag?.drop, children: [row.heading && (_jsx("div", { className: "px-2 pt-2 pb-0.5 font-semibold text-[10px] text-slate-400 uppercase tracking-wide", children: row.heading })), _jsxs("div", { "data-chapter": row.id, role: "button", tabIndex: 0, className: "flex min-w-0 cursor-pointer select-none items-center gap-2 px-2 py-1 text-xs outline-none hover:bg-slate-800 focus-visible:bg-slate-800", style: { paddingLeft: 8 + row.depth * 14 }, onClick: () => onActivate(row.id), onKeyDown: (e) => {
                    if (e.key === 'Enter') {
                        onActivate(row.id);
                    }
                }, children: [_jsx("span", { className: cn('w-5 shrink-0 text-right tabular-nums', done ? 'text-emerald-400' : 'text-slate-500'), children: done ? _jsx(IconCheck, { size: 13, className: "ml-auto" }) : number }), _jsx("span", { className: cn('min-w-0 flex-1 truncate', done ? 'text-slate-500' : 'text-slate-200', current && 'font-medium text-slate-100'), children: row.title }), row.warning && _jsx(IconAlertTriangle, { size: 13, className: "shrink-0 text-amber-400" }), row.note && _jsx("span", { className: "shrink-0 text-[10px] text-slate-400", children: row.note }), row.duration && _jsx("span", { className: "shrink-0 text-slate-500 tabular-nums", children: row.duration }), actions != null && (_jsx("span", { className: "flex shrink-0 items-center gap-0.5 opacity-0 focus-within:opacity-100 group-hover:opacity-100", children: actions }))] }), current && row.progress != null && (_jsx("div", { className: "px-2 pb-1", style: { paddingLeft: 36 + row.depth * 14 }, children: _jsx(ProgressBar, { value: row.progress, height: 3 }) })), expanded && (row.subtitle || detail) && (_jsxs("div", { className: "px-2 pb-1.5 text-[11px] text-slate-400", style: { paddingLeft: 36 + row.depth * 14 }, children: [row.subtitle && _jsx("div", { className: "whitespace-pre-wrap", children: row.subtitle }), detail] }))] }));
}
