export interface ConfirmDialogCoreProps {
    /** Title-bar text. */
    title: string;
    /** The question (newlines kept). */
    message: string;
    /** OK button text. */
    okLabel: string;
    /** Cancel button text. */
    cancelLabel: string;
    /** Called with true for OK, false for Cancel, Escape, the backdrop or the ✕. */
    onResult: (ok: boolean) => void;
    /** Stacking layer (default 2000). */
    z?: number;
}
/** Pure OK/Cancel dialog — props only, no store coupling. */
export declare function ConfirmDialogCore({ title, message, okLabel, cancelLabel, onResult, z, }: ConfirmDialogCoreProps): import("react").JSX.Element;
