import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useMemo } from 'react';
import { createPortal } from 'react-dom';
import { SelectChips } from './SelectChips';
import { SelectList } from './SelectList';
import { useSelectDropdown } from './useSelectDropdown';
/**
 * A dropdown in the dock's visual language. Single or multi select, optional
 * search, full keyboard support (arrows / Enter / Escape / type-to-filter).
 * Multi-select keeps the list open and shows checkmarks; the trigger sums up.
 */
export function Select(props) {
    const { options = [], placeholder = 'Select…', loadOptions, disabled = false, className = '' } = props;
    const searchable = props.searchable || loadOptions != null;
    const selected = useMemo(() => new Set(props.multiple ? props.value : props.value != null ? [props.value] : []), [props.multiple, props.value]);
    const dd = useSelectDropdown(options, loadOptions, searchable, selected);
    const pick = (opt) => {
        if (opt.disabled) {
            return;
        }
        if (props.multiple) {
            const next = new Set(props.value);
            next.has(opt.value) ? next.delete(opt.value) : next.add(opt.value);
            props.onChange([...next]);
        }
        else {
            props.onChange(opt.value);
            dd.setOpen(false);
        }
    };
    const onKeyDown = (e) => {
        if (!dd.open && (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown')) {
            e.preventDefault();
            dd.setOpen(true);
            return;
        }
        if (!dd.open) {
            return;
        }
        if (e.key === 'Escape') {
            dd.setOpen(false);
        }
        else if (e.key === 'ArrowDown') {
            dd.setHot((h) => Math.min(h + 1, dd.filtered.length - 1));
        }
        else if (e.key === 'ArrowUp') {
            dd.setHot((h) => Math.max(h - 1, 0));
        }
        else if (e.key === 'Enter' && dd.filtered[dd.hot]) {
            pick(dd.filtered[dd.hot]);
        }
        else {
            return;
        }
        e.preventDefault();
    };
    const summary = props.multiple ? (props.value.length === 0 ? null : (_jsx(SelectChips, { values: props.value, known: dd.known, onRemove: (v) => props.onChange(props.value.filter((x) => x !== v)) }))) : props.value != null ? (dd.known(props.value).label) : null;
    return (_jsxs("div", { ref: dd.rootRef, className: `relative text-xs ${className}`, onKeyDown: onKeyDown, children: [_jsxs("button", { type: "button", disabled: disabled, "aria-haspopup": "listbox", "aria-expanded": dd.open, className: `group flex min-h-6 w-full cursor-pointer items-center gap-1.5 border px-2 py-0.5 text-left ${dd.open ? 'border-blue-400 bg-slate-900' : 'border-slate-700 bg-slate-900 hover:border-slate-600'} ${disabled ? 'cursor-not-allowed opacity-50' : ''} text-slate-200`, onClick: () => dd.setOpen((o) => !o), children: [summary == null ? (_jsx("span", { className: "min-w-0 flex-1 truncate text-slate-400", children: placeholder })) : props.multiple ? (summary) : (_jsx("span", { className: "min-w-0 flex-1 truncate", children: summary })), summary != null && !disabled && (_jsx("span", { role: "button", "aria-label": "Clear selection", title: "Clear", className: "shrink-0 cursor-pointer px-0.5 text-slate-400 leading-none opacity-0 transition-opacity hover:text-red-400 group-hover:opacity-100", onPointerDown: (e) => e.stopPropagation(), onClick: (e) => {
                            e.stopPropagation();
                            if (props.multiple) {
                                props.onChange([]);
                            }
                            else {
                                props.onChange(null);
                            }
                        }, children: "\u00D7" })), _jsx("svg", { viewBox: "0 0 8 8", className: `h-2 w-2 shrink-0 fill-slate-500 transition-transform ${dd.open ? 'rotate-180' : ''}`, children: _jsx("path", { d: "M0 2l4 4 4-4z" }) })] }), dd.open &&
                createPortal(_jsx(SelectList, { dd: dd, multiple: props.multiple === true, searchable: searchable, hasAsync: loadOptions != null, selected: selected, pick: pick, onKeyDown: onKeyDown }), document.body)] }));
}
