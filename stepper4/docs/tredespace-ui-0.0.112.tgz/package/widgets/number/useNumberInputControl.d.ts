import { type RefObject } from 'react';
export type NumberInputControl = Readonly<{
    /** Non-null while the field is being typed in. */
    text: string | null;
    setText: (t: string | null) => void;
    commitText: () => void;
    bump: (dir: 1 | -1) => void;
    inputRef: RefObject<HTMLInputElement | null>;
    isDragging: () => boolean;
    onPointerDown: (e: React.PointerEvent<HTMLInputElement>) => void;
    onPointerMove: (e: React.PointerEvent<HTMLInputElement>) => void;
    onPointerUp: (e: React.PointerEvent<HTMLInputElement>) => void;
}>;
/**
 * The stepper's interaction engine: clamped commits, non-passive wheel
 * stepping, and Blender-style horizontal "rolling" (press + drag while
 * unfocused; a plain click focuses for typing instead).
 */
export declare function useNumberInputControl(value: number, onChange: (value: number) => void, step: number, decimals: number, min: number | undefined, max: number | undefined, disabled: boolean): NumberInputControl;
